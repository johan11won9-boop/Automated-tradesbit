# Research protocol

The rules below were fixed in code (`lab/catalog.py: RULES`, `lab/search.py: FURTHER_PROTOCOL`) **before** any
result was looked at. Changing a threshold after seeing a result would make the verdict meaningless.

## 1. Discovery (data before 2022 only)
* 14 strategy families from published research (opening-range breakouts, noise-area breakouts, volatility
  breakouts, VWAP reversion, gap fade/follow, Asian-range breakouts, intraday and daily RSI(2), intraday
  periodicity, session drift, Donchian trend, IBS, turn-of-month).
* Each family runs over a small, fixed grid on every instrument cached - 217 instruments, 10,906 configurations.
* A numba kernel (tested to give exactly the full engine's trades) makes this take minutes, not days.
* Fixed selection rules pick finalists: enough trades, positive in most years, costs covered with headroom,
  parameter neighbours also positive (a plateau, not a spike). **490 finalists.**

## 2. Confirmation (2022 → the vault date, never seen in discovery)
* Every finalist runs through the full engine on data discovery never touched.
* Significance is judged with **false-discovery control across all 490 finalists** (Benjamini–Hochberg, q = 10%),
  so testing many ideas doesn't manufacture winners.
* Every trade is compared with 20 **random entries** in the same market, month and hour, same direction, same
  exits. A strategy that doesn't beat them is riding drift, not timing.
* Robustness: years, halves, decay, cost x1.5, worst-case order inside a bar, parameter neighbours, outliers.

## 3. Further tests (fixed before running)
* **A - second price source**: the same rules on independent exchange data (Alpaca), charged the broker's costs.
* **B - the vault**: the newest 12 months of every dataset, locked since the lab's first run, opened once.
* **C - breadth**: the rules on every comparable instrument, using only an ex-ante filter.

## 4. What survived
Two intraday momentum rules on one US stock: significant after FDR control, beat random entries (p ≤ 0.002),
held on the second price feed and in the vault year. The breadth test was negative - the effect is specific to that
instrument, which is reported as a limitation, not hidden.

## 5. From backtest to account
* A prop-firm lifecycle simulator turns the strategy's daily history into account outcomes (pass times, payouts,
  breaches, fees) by block bootstrap, next to a zero-edge twin.
* The live bot's decision code is replayed over the full history and must reproduce the backtest's trades exactly
  (2,080 / 2,080) before it is allowed to trade.

## Calibration of the lab itself (`lab.py selftest`)

| scenario (100 synthetic 3-year markets each) | called EDGE | called NO EDGE |
|---|---|---|
| random entries, flat market | 4% | 11% |
| random entries, rising market | 2% | 6% |
| planted edge, Sharpe ~2 | **93%** | **0%** |
| small planted edge, Sharpe ~1 | 33% | **0%** |
| strategy that reads the future | BROKEN 100% | - |
