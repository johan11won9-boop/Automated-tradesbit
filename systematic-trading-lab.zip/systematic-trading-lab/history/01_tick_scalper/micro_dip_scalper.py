"""
micro_dip_scalper.py - the tick-scalping generation (winter 2025-26 -> early 2026)

What it does
    Polls the latest quote for every market in the watchlist in ONE batched request, several
    times a second, and buys short micro-dips that happen inside a short-term uptrend. Each
    position exits at a fixed target or a fixed stop.

What this file shows (the engineering, not the settings)
    * one non-blocking asyncio / aiohttp event loop - no broker call waits on another
    * batched market data: a single request per scan covers the whole watchlist
    * orders and positions kept apart: an order only becomes a position once the broker
      reports the fill (fill confirmation, timeout + cancel, partial fills, orphaned fills
      recovered from the broker's own position list)
    * exits before entries on every scan - protecting open positions comes first
    * P&L booked only after the broker confirms the position is gone, never on submission
    * startup recovery: adopts whatever the account already holds in the watchlist
    * account-level risk limits from the first trade: daily-loss pause, max-drawdown stop
      (flattens), loss-streak breaker, per-symbol cool-down after a stop, re-entry delay
    * market hours from the broker's clock (DST and holidays handled by the broker)

Not published: the watchlist and every threshold, size and timer. Each one is REDACTED and the
bot refuses to start until all of them are set. Credentials come from environment variables only.

    APCA_API_KEY_ID / APCA_API_SECRET_KEY    your Alpaca keys (never put them in this file)
    APCA_API_BASE_URL                        optional, defaults to the paper-trading endpoint

    uv run python micro_dip_scalper.py           # paper
    uv run python micro_dip_scalper.py --live    # required for any non-paper endpoint
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import time
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from typing import Deque, Dict, List, Optional

import aiohttp

log = logging.getLogger("scalper")

PAPER_URL = "https://paper-api.alpaca.markets"
DATA_URL = "https://data.alpaca.markets"
REDACTED = None                     # live values are not published

FILL_POLLS = 4                      # times an exit order is polled before the next scan takes over
FILL_POLL_SECONDS = 0.25


# ----------------------------------------------------------------------------- settings

@dataclass
class Settings:
    markets: Optional[List[str]] = REDACTED        # symbols scanned
    dip_trigger: Optional[float] = REDACTED        # fall in mid price since the previous scan
    trend_min: Optional[float] = REDACTED          # minimum rise across the price-history window
    volatility_min: Optional[float] = REDACTED     # minimum high-low range across the window
    max_spread: Optional[float] = REDACTED         # widest bid/ask spread accepted, fraction of mid
    history_len: Optional[int] = REDACTED          # mid prices kept per symbol
    min_history: Optional[int] = REDACTED          # prices needed before a symbol can trade
    take_profit: Optional[float] = REDACTED        # fraction above the fill
    stop_loss: Optional[float] = REDACTED          # fraction below the fill
    limit_offset: Optional[float] = REDACTED       # entry limit = ask x (1 + offset)
    exposure: Optional[float] = REDACTED           # share of equity spread across all slots
    max_positions: Optional[int] = REDACTED
    scan_seconds: Optional[float] = REDACTED
    order_timeout: Optional[float] = REDACTED      # cancel an unfilled entry after this many seconds
    reentry_delay: Optional[float] = REDACTED      # seconds before a symbol can be re-entered after any exit
    cooldown_after_stop: Optional[float] = REDACTED
    loss_streak_limit: Optional[int] = REDACTED    # consecutive stops before a pause
    loss_streak_pause: Optional[float] = REDACTED  # seconds
    daily_loss_limit: Optional[float] = REDACTED   # pause entries for the day at this loss
    max_drawdown: Optional[float] = REDACTED       # flatten and stop at this drawdown from peak equity
    sync_every: Optional[int] = REDACTED           # scans between account / position syncs
    max_trades_day: Optional[int] = REDACTED
    closed_sleep: Optional[float] = REDACTED       # seconds between clock checks while the market is shut
    error_sleep: Optional[float] = REDACTED        # back-off after an unexpected error

    def check(self) -> None:
        missing = [k for k, v in asdict(self).items() if v is None]
        if missing:
            raise SystemExit("settings not published - set these before running: " + ", ".join(missing))


SETTINGS = Settings()


# ----------------------------------------------------------------------------- broker

@dataclass
class Quote:
    bid: float
    ask: float

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2

    @property
    def spread(self) -> float:
        return (self.ask - self.bid) / self.mid


class Alpaca:
    """The REST calls the scalper needs. Every method returns None on failure instead of raising,
    so one bad response never takes the loop down."""

    def __init__(self, http: aiohttp.ClientSession, key: str, secret: str,
                 trading_url: str = PAPER_URL, data_url: str = DATA_URL, feed: str = "iex"):
        self.http, self.trading, self.data, self.feed = http, trading_url.rstrip("/"), data_url, feed
        self._headers = {"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret}

    async def _call(self, method: str, url: str, **kw):
        try:
            async with self.http.request(method, url, headers=self._headers, **kw) as r:
                if r.status in (200, 201):
                    return await r.json()
                if r.status == 204:
                    return {}
                log.warning("%s %s -> HTTP %s: %s", method, url.split("?")[0], r.status,
                            (await r.text())[:200])
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            log.warning("%s %s failed: %s", method, url.split("?")[0], exc)
        return None

    async def clock(self) -> Optional[dict]:
        return await self._call("GET", f"{self.trading}/v2/clock")

    async def account(self) -> Optional[dict]:
        return await self._call("GET", f"{self.trading}/v2/account")

    async def positions(self) -> Optional[Dict[str, dict]]:
        data = await self._call("GET", f"{self.trading}/v2/positions")
        return None if data is None else {p["symbol"]: p for p in data}

    async def quotes(self, symbols: List[str]) -> Dict[str, Quote]:
        """Latest bid/ask for every symbol in one request."""
        data = await self._call("GET", f"{self.data}/v2/stocks/quotes/latest",
                                params={"symbols": ",".join(symbols), "feed": self.feed})
        out: Dict[str, Quote] = {}
        for sym, q in ((data or {}).get("quotes") or {}).items():
            bid, ask = float(q.get("bp") or 0), float(q.get("ap") or 0)
            if 0 < bid <= ask:
                out[sym] = Quote(bid, ask)
        return out

    async def order(self, order_id: str) -> Optional[dict]:
        return await self._call("GET", f"{self.trading}/v2/orders/{order_id}")

    async def cancel(self, order_id: str) -> bool:
        return await self._call("DELETE", f"{self.trading}/v2/orders/{order_id}") is not None

    async def submit(self, **order) -> Optional[str]:
        data = await self._call("POST", f"{self.trading}/v2/orders", json=order)
        return (data or {}).get("id")

    async def buy_limit(self, symbol: str, qty: float, limit: float) -> Optional[str]:
        return await self.submit(symbol=symbol, qty=_q(qty), side="buy", type="limit",
                                 limit_price=f"{limit:.2f}", time_in_force="day")

    async def sell_market(self, symbol: str, qty: float) -> Optional[str]:
        return await self.submit(symbol=symbol, qty=_q(qty), side="sell", type="market",
                                 time_in_force="day")


def _q(qty: float) -> str:
    return f"{qty:.9g}"


# ----------------------------------------------------------------------------- the signal

def micro_dip(prev_mid: Optional[float], q: Quote, hist: Deque[float], s: Settings) -> bool:
    """A short dip since the last scan, inside a rising and moving window, at a tight spread."""
    if prev_mid is None or prev_mid <= 0 or len(hist) < s.min_history:
        return False
    first, lo, hi = hist[0], min(hist), max(hist)
    dip = (prev_mid - q.mid) / prev_mid
    trend = (hist[-1] - first) / first
    swing = (hi - lo) / lo
    return (dip >= s.dip_trigger and trend >= s.trend_min
            and swing >= s.volatility_min and q.spread <= s.max_spread)


# ----------------------------------------------------------------------------- state

@dataclass
class Pending:
    order_id: str
    submitted: float
    qty: float


@dataclass
class Position:
    entry: float
    qty: float
    target: float
    stop: float
    exit_order: Optional[str] = None
    exit_reason: str = ""


@dataclass
class Book:
    pending: Dict[str, Pending] = field(default_factory=dict)
    positions: Dict[str, Position] = field(default_factory=dict)
    cooldown_until: Dict[str, float] = field(default_factory=dict)
    no_reentry_until: Dict[str, float] = field(default_factory=dict)


# ----------------------------------------------------------------------------- the bot

class Scalper:
    def __init__(self, settings: Settings, broker: Alpaca, clock=time.time):
        settings.check()
        self.s, self.b, self.now = settings, broker, clock
        self.book = Book()
        self.history: Dict[str, Deque[float]] = defaultdict(lambda: deque(maxlen=self.s.history_len))
        self.last_mid: Dict[str, float] = {}
        self.equity: Optional[float] = None
        self.buying_power = 0.0
        self.day: Optional[str] = None
        self.day_start_equity: Optional[float] = None
        self.peak_equity: Optional[float] = None
        self.halted_for_day = False
        self.stopped = False
        self.paused_until = 0.0
        self.loss_streak = 0
        self.trades_today = 0
        self.realised = 0.0
        self.scans = 0
        self.market_open = False

    # -- helpers ---------------------------------------------------------------------

    def _position(self, entry: float, qty: float) -> Position:
        return Position(entry, qty, entry * (1 + self.s.take_profit), entry * (1 - self.s.stop_loss))

    def _adopt(self, sym: str, p: dict) -> None:
        self.book.positions[sym] = self._position(float(p["avg_entry_price"]), float(p["qty"]))

    def _can_enter(self) -> bool:
        return (not self.stopped and not self.halted_for_day and self.now() >= self.paused_until
                and self.trades_today < self.s.max_trades_day)

    # -- startup ---------------------------------------------------------------------

    async def recover(self) -> None:
        """Adopt open positions in the watchlist so a restart never loses track of one."""
        held = await self.b.positions()
        for sym, p in (held or {}).items():
            if sym in self.s.markets and float(p.get("qty") or 0) > 0:
                self._adopt(sym, p)
        if self.book.positions:
            log.info("recovered %d open position(s): %s", len(self.book.positions),
                     ", ".join(sorted(self.book.positions)))

    # -- account sync and risk -------------------------------------------------------

    def _new_day(self, day: str) -> None:
        self.day, self.day_start_equity = day, None
        self.halted_for_day, self.trades_today = False, 0

    def _check_risk(self, equity: float) -> None:
        if self.day_start_equity is None:
            self.day_start_equity = equity
        self.peak_equity = max(self.peak_equity or equity, equity)
        drawdown = (self.peak_equity - equity) / self.peak_equity
        day_pnl = (equity - self.day_start_equity) / self.day_start_equity
        if drawdown >= self.s.max_drawdown and not self.stopped:
            log.error("max drawdown reached (%.2f%%) - flattening and stopping", drawdown * 100)
            self.stopped = True
        elif day_pnl <= -self.s.daily_loss_limit and not self.halted_for_day:
            log.warning("daily loss limit reached (%.2f%%) - no new entries today", day_pnl * 100)
            self.halted_for_day = True

    async def sync(self) -> None:
        acct = await self.b.account()
        if acct:
            equity = float(acct.get("equity") or 0)
            self.buying_power = float(acct.get("buying_power") or 0)
            if equity > 0:
                self.equity = equity
                self._check_risk(equity)
        held = await self.b.positions()
        if held is not None:                                   # None = the call failed: change nothing
            for sym in list(self.book.positions):
                if sym not in held and not self.book.positions[sym].exit_order:
                    log.warning("%s: no longer held at the broker - dropped", sym)
                    del self.book.positions[sym]
                    self.book.no_reentry_until[sym] = self.now() + self.s.reentry_delay
        if self.equity is not None:
            log.info("equity %.2f | realised %+.2f | open %d | pending %d | trades today %d",
                     self.equity, self.realised, len(self.book.positions), len(self.book.pending),
                     self.trades_today)

    # -- entries waiting for a fill --------------------------------------------------

    async def check_pending(self) -> None:
        now = self.now()
        for sym, p in list(self.book.pending.items()):
            info = await self.b.order(p.order_id)
            if not info:
                continue
            status = info.get("status")
            price = float(info.get("filled_avg_price") or 0)
            filled = float(info.get("filled_qty") or 0)
            age = now - p.submitted
            if status == "filled" and price > 0:
                self.book.positions[sym] = self._position(price, filled)
                del self.book.pending[sym]
                pos = self.book.positions[sym]
                log.info("FILLED %s %g @ %.4f | target %.4f | stop %.4f",
                         sym, filled, price, pos.target, pos.stop)
            elif status in ("canceled", "expired", "rejected"):
                del self.book.pending[sym]
                self.book.no_reentry_until[sym] = now + self.s.reentry_delay
            elif age > self.s.order_timeout * (2 if status == "partially_filled" else 1):
                await self.b.cancel(p.order_id)
                del self.book.pending[sym]
                self.book.no_reentry_until[sym] = now + self.s.reentry_delay
                held = await self.b.positions() or {}
                if sym in held:                                # (part-)filled before the cancel landed
                    self._adopt(sym, held[sym])
                    log.warning("%s: adopted a fill found at the broker after cancelling", sym)
                else:
                    log.info("%s: entry not filled in time - cancelled", sym)

    # -- exits -----------------------------------------------------------------------

    async def _finish_exit(self, sym: str, pos: Position, fallback_price: float) -> bool:
        """Book the exit only once the broker shows the position gone."""
        price = 0.0
        for _ in range(FILL_POLLS):
            info = await self.b.order(pos.exit_order)
            status = (info or {}).get("status")
            if status == "filled":
                price = float(info.get("filled_avg_price") or 0)
                break
            if status in ("canceled", "expired", "rejected"):
                log.warning("%s: exit order %s - will retry", sym, status)
                pos.exit_order = None
                return False
            await asyncio.sleep(FILL_POLL_SECONDS)
        held = await self.b.positions()
        if held is None or sym in held:
            return False                                       # not confirmed yet: next scan re-checks
        price = price or fallback_price
        pnl = (price - pos.entry) * pos.qty
        self.realised += pnl
        self.trades_today += 1
        del self.book.positions[sym]
        now = self.now()
        self.book.no_reentry_until[sym] = now + self.s.reentry_delay
        if pos.exit_reason == "stop":
            self.loss_streak += 1
            self.book.cooldown_until[sym] = now + self.s.cooldown_after_stop
            if self.loss_streak >= self.s.loss_streak_limit:
                self.paused_until = now + self.s.loss_streak_pause
                self.loss_streak = 0
                log.warning("loss streak limit hit - entries paused")
        elif pos.exit_reason == "target":
            self.loss_streak = 0
        log.info("%s %s @ %.4f | %+.2f | realised %+.2f",
                 pos.exit_reason.upper(), sym, price, pnl, self.realised)
        return True

    async def _exit(self, sym: str, pos: Position, reason: str, q: Optional[Quote]) -> None:
        if pos.exit_order is None:
            pos.exit_order = await self.b.sell_market(sym, pos.qty)
            pos.exit_reason = reason
            if pos.exit_order is None:
                log.warning("%s: exit order refused - will retry", sym)
                return
        await self._finish_exit(sym, pos, q.bid if q else pos.entry)

    async def exits(self, quotes: Dict[str, Quote]) -> None:
        for sym, pos in list(self.book.positions.items()):
            q = quotes.get(sym)
            if pos.exit_order is not None:                     # already exiting: just confirm it
                await self._exit(sym, pos, pos.exit_reason, q)
            elif q is not None and q.bid >= pos.target:
                await self._exit(sym, pos, "target", q)
            elif q is not None and q.bid <= pos.stop:
                await self._exit(sym, pos, "stop", q)

    async def flatten(self, quotes: Dict[str, Quote], reason: str) -> None:
        for sym, pos in list(self.book.positions.items()):
            await self._exit(sym, pos, pos.exit_reason or reason, quotes.get(sym))
        for sym, p in list(self.book.pending.items()):
            await self.b.cancel(p.order_id)
            del self.book.pending[sym]

    # -- entries ---------------------------------------------------------------------

    async def entries(self, quotes: Dict[str, Quote]) -> None:
        s, now = self.s, self.now()
        slots = s.max_positions - len(self.book.positions) - len(self.book.pending)
        if slots <= 0 or self.equity is None:
            return
        slot_cash = self.equity * s.exposure / s.max_positions
        for sym in s.markets:
            if slots <= 0 or self.buying_power < slot_cash:
                break
            q = quotes.get(sym)
            if (q is None or sym in self.book.positions or sym in self.book.pending
                    or now < self.book.cooldown_until.get(sym, 0)
                    or now < self.book.no_reentry_until.get(sym, 0)):
                continue
            if not micro_dip(self.last_mid.get(sym), q, self.history[sym], s):
                continue
            qty = int(slot_cash // q.ask)
            if qty < 1:
                continue
            order_id = await self.b.buy_limit(sym, qty, q.ask * (1 + s.limit_offset))
            if order_id:
                self.book.pending[sym] = Pending(order_id, now, qty)
                self.buying_power -= qty * q.ask
                slots -= 1
                log.info("ORDER %s %d @ limit %.2f", sym, qty, q.ask * (1 + s.limit_offset))

    # -- one scan --------------------------------------------------------------------

    async def step(self) -> float:
        """One scan. Returns how long to sleep before the next."""
        clock = await self.b.clock()
        if not clock or not clock.get("is_open"):
            if self.market_open:
                log.info("market closed")
            self.market_open = False
            return self.s.closed_sleep
        if not self.market_open:
            log.info("market open - scanning %d markets", len(self.s.markets))
            self.market_open = True
        day = str(clock.get("timestamp", ""))[:10]               # the exchange's local date
        if day != self.day:
            self._new_day(day)

        if self.scans % self.s.sync_every == 0 or self.equity is None:
            await self.sync()
        self.scans += 1

        quotes = await self.b.quotes(self.s.markets)
        if not quotes:
            return self.s.scan_seconds
        for sym, q in quotes.items():
            self.history[sym].append(q.mid)

        await self.check_pending()
        if self.stopped:
            await self.flatten(quotes, "stop-out")
        else:
            await self.exits(quotes)                           # priority 1: protect what is open
            if self._can_enter():
                await self.entries(quotes)                     # priority 2: look for new trades
        self.last_mid.update({sym: q.mid for sym, q in quotes.items()})
        return self.s.scan_seconds

    async def run(self) -> None:
        await self.recover()
        while not (self.stopped and not self.book.positions and not self.book.pending):
            try:
                delay = await self.step()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("scan failed")
                delay = self.s.error_sleep
            await asyncio.sleep(delay)
        log.info("stopped | trades today %d | realised %+.2f", self.trades_today, self.realised)


# ----------------------------------------------------------------------------- entry point

async def main(live: bool) -> None:
    key, secret = os.environ.get("APCA_API_KEY_ID"), os.environ.get("APCA_API_SECRET_KEY")
    if not key or not secret:
        raise SystemExit("set APCA_API_KEY_ID and APCA_API_SECRET_KEY in the environment")
    url = os.environ.get("APCA_API_BASE_URL", PAPER_URL)
    if url.rstrip("/") != PAPER_URL and not live:
        raise SystemExit(f"{url} is not the paper endpoint - pass --live to trade it")
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as http:
        bot = Scalper(SETTINGS, Alpaca(http, key, secret, url))
        await bot.run()


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="micro-dip tick scalper")
    ap.add_argument("--live", action="store_true", help="allow a non-paper endpoint")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(message)s")
    try:
        asyncio.run(main(args.live))
    except KeyboardInterrupt:
        log.info("stopped by hand")
