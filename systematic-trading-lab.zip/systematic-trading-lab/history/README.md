# Earlier generations

Three bots from before the research lab, kept as code examples of how the execution side evolved. The
strategy that trades today is in [`strategies/`](../strategies/) and [`live/`](../live/). These folders show the
engineering.

| folder | generation | what the code shows |
|---|---|---|
| [`01_tick_scalper/`](01_tick_scalper/) | HFT / tick scalping, winter 2025–26 → early 2026 | a sub-second asyncio / aiohttp loop with one batched quote request per scan. Orders and positions are tracked separately: fills are confirmed with the broker, partial and orphaned fills are handled, and P&L is booked only once the broker confirms the exit. Exits run before entries on every scan. Account-level risk limits apply from the first trade |
| [`02_tradingview_webhook/`](02_tradingview_webhook/) | TradingView connector, summer 2026 | a Pine Script v5 indicator that classifies regime, VWAP side and volume into a 0–100 context score and sends it as JSON through `alert()`. A Flask receiver checks a shared secret, validates the alert, suppresses duplicates, gates on the score and sends a position-aware Alpaca order. It waits for the fill before logging it |
| [`03_golden_ratio/`](03_golden_ratio/) | Golden Ratio, MetaTrader 5, Sep – Oct 2026 | confluence entry rules (trend, momentum band, volume, an optional liquidity-sweep filter) held across consecutive bars, then a periodic re-rank that decides which instruments are traded. A runner on the published MT5 layer handles lot sizing from the broker, server-side stops and targets, and max-hold exits counted in session bars |

## What is not here

Every watchlist, threshold, weight, size, timer, risk level and magic number is `REDACTED`. Each bot refuses to
start until all of them are set, and the Pine Script stops with an error until every input is filled in. Nothing in
this folder reflects the values these bots actually ran with.

Credentials never appear in code. Each bot reads them from environment variables, or from a local, git-ignored
`.env` for MT5:

| variable | used by |
|---|---|
| `APCA_API_KEY_ID`, `APCA_API_SECRET_KEY` | tick scalper, webhook receiver |
| `APCA_API_BASE_URL` (optional, defaults to paper trading) | tick scalper, webhook receiver - any other endpoint needs `--live` |
| `WEBHOOK_PASSPHRASE` | webhook receiver (and typed into the indicator's inputs, never its code) |
| `MT5_PATH` / terminal login in `03_golden_ratio/.env` | Golden Ratio runner, via [`live/broker.py`](../live/broker.py) |

## Run

```bash
pip install -r requirements.txt

cd history/01_tick_scalper && uv run python micro_dip_scalper.py         # paper by default
cd history/02_tradingview_webhook && python webhook_receiver.py --port 5000
cd history/03_golden_ratio && python runner.py                            # dry run: reads MT5, sends nothing
```

For the webhook, add `market_context.pine` to a TradingView chart, fill in its inputs, then create an alert:
**Condition:** the indicator, *Any alert() function call*. **Webhook URL:** your receiver's public `/webhook`
address, through a tunnel such as ngrok.
