"""
strategy.py - Golden Ratio: the entry rules and how a trade plays out (September - October 2026)

Entry: three confluence conditions on closed bars, all required, and all held for a run of
consecutive bars (no single-bar flickers):
    trend      close on the trade's side of an EMA
    momentum   RSI inside a band - moving, but not stretched either way
    volume     bar volume above its rolling average
plus an optional liquidity-sweep filter: the bar must run a recent swing level and close back
on the other side of it (stops taken, level reclaimed). Whether the sweep filter is on is decided
per instrument by the re-rank in selection.py, not by hand.

Session series: the rules run on session bars only - bars outside the session window are removed
and the rest glued end to end - and the max-hold clock counts session bars.

evaluate_live() replays exactly what the bot does with each signal (first touch of stop or target,
stop first if both inside one bar, otherwise out at the close of the last held bar, one position
at a time), so the re-rank ranks the same strategy the bot trades.

Not published: every number. PARAMS is REDACTED and need() refuses to run until it is filled in.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Optional

import numpy as np
import pandas as pd

REDACTED = None


@dataclass(frozen=True)
class Params:
    ema_len: Optional[int] = REDACTED         # trend filter
    rsi_len: Optional[int] = REDACTED
    rsi_lo: Optional[float] = REDACTED        # momentum band
    rsi_hi: Optional[float] = REDACTED
    vol_len: Optional[int] = REDACTED         # volume average
    confirm_bars: Optional[int] = REDACTED    # consecutive bars the conditions must hold
    sweep_lookback: Optional[int] = REDACTED  # bars searched for the swing level
    sweep_gap: Optional[int] = REDACTED       # most recent bars excluded from that search
    min_bars: Optional[int] = REDACTED        # session bars needed before a signal can fire
    take_profit: Optional[float] = REDACTED   # fraction of the entry price
    stop_loss: Optional[float] = REDACTED     # fraction of the entry price
    max_hold: Optional[int] = REDACTED        # session bars, counting the signal bar
    session_start: Optional[str] = REDACTED   # "HH:MM", UTC, weekdays
    session_end: Optional[str] = REDACTED
    direction: Optional[str] = REDACTED       # "LONG" or "SHORT"

    def need(self) -> "Params":
        missing = [k for k, v in asdict(self).items() if v is None]
        if missing:
            raise ValueError("parameters not published - set: " + ", ".join(missing))
        if self.direction not in ("LONG", "SHORT"):
            raise ValueError("direction must be 'LONG' or 'SHORT'")
        return self

    def with_(self, **kw) -> "Params":
        return replace(self, **kw)


PARAMS = Params()


# ----------------------------------------------------------------------------- indicators

def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def rsi(s: pd.Series, n: int) -> pd.Series:
    d = s.diff()
    gain = d.clip(lower=0).rolling(n).mean()
    loss = (-d.clip(upper=0)).rolling(n).mean()
    return 100 - 100 / (1 + gain / loss.replace(0, np.nan))


def sweep_mask(df: pd.DataFrame, direction: str, lookback: int, gap: int) -> pd.Series:
    """Swing level = the extreme of the (lookback - gap) bars that end `gap` bars before the current
    one. The current bar must break through it and close back on the other side."""
    win = lookback - gap
    if direction == "LONG":
        swing = df["low"].rolling(win).min().shift(gap)
        return (df["low"] < swing) & (df["close"] > swing)
    swing = df["high"].rolling(win).max().shift(gap)
    return (df["high"] > swing) & (df["close"] < swing)


# ----------------------------------------------------------------------------- signals

def signals(df: pd.DataFrame, p: Params, sweep: bool) -> pd.Series:
    """True on bars whose close fires an entry. Uses closed bars only."""
    p.need()
    c, v = df["close"], df["volume"]
    e, r = ema(c, p.ema_len), rsi(c, p.rsi_len)
    trend = (c > e) if p.direction == "LONG" else (c < e)
    base = trend & (r >= p.rsi_lo) & (r <= p.rsi_hi) & (v > v.rolling(p.vol_len).mean())
    ok = base.copy()
    for k in range(1, p.confirm_bars):
        ok &= base.shift(k, fill_value=False)
    if sweep:
        ok &= sweep_mask(df, p.direction, p.sweep_lookback, p.sweep_gap)
    return ok.fillna(False).astype(bool)


def signal_now(sess: pd.DataFrame, p: Params, sweep: bool) -> bool:
    """Does the newest session bar fire?"""
    if len(sess) < p.need().min_bars:
        return False
    return bool(signals(sess, p, sweep).iloc[-1])


def brackets(entry: float, p: Params) -> tuple[float, float]:
    """(stop, target) prices for an entry."""
    d = 1 if p.direction == "LONG" else -1
    return entry * (1 - d * p.stop_loss), entry * (1 + d * p.take_profit)


# ----------------------------------------------------------------------------- what a trade does

def evaluate_live(df: pd.DataFrame, entries: pd.Series, p: Params, cost_bp: float) -> Optional[dict]:
    """Replay the bot on every signal: enter at the signal bar's close, first touch of stop or
    target wins (stop first when both are inside one bar), otherwise close at the last held bar.
    One position at a time. Results in R, net of a round-trip cost in basis points."""
    p.need()
    d = 1 if p.direction == "LONG" else -1
    c, h, l = df["close"].to_numpy(), df["high"].to_numpy(), df["low"].to_numpy()
    rs, open_until = [], -1
    for i in np.flatnonzero(entries.to_numpy()):
        if i <= open_until or i + 1 >= len(c):
            continue
        entry = c[i]
        stop, target = brackets(entry, p)
        last = i + p.max_hold - 1
        r, j_exit = None, last
        for j in range(i + 1, min(last, len(c) - 1) + 1):
            hit_stop = l[j] <= stop if d > 0 else h[j] >= stop
            hit_target = h[j] >= target if d > 0 else l[j] <= target
            if hit_stop:
                r, j_exit = -1.0, j
                break
            if hit_target:
                r, j_exit = p.take_profit / p.stop_loss, j
                break
        if r is None:
            if last >= len(c):
                break                                   # still open when the data ends: unknown
            r = d * (c[last] - entry) / entry / p.stop_loss
        rs.append(r - cost_bp / 1e4 / p.stop_loss)
        open_until = j_exit
    if not rs:
        return None
    rs = np.asarray(rs)
    gross_win, gross_loss = rs[rs > 0].sum(), -rs[rs < 0].sum()
    return {"trades": len(rs), "win_rate": float((rs > 0).mean()),
            "pf": float(gross_win / gross_loss) if gross_loss else float("inf"),
            "exp_r": float(rs.mean())}


# ----------------------------------------------------------------------------- session layer

def _hm(s: str) -> pd.Timedelta:
    h, m = (int(x) for x in s.split(":"))
    return pd.Timedelta(hours=h, minutes=m)


def session_mask(index: pd.DatetimeIndex, p: Params) -> np.ndarray:
    """True for bars (by UTC open time) inside the session window, Monday to Friday."""
    tod = index - index.normalize()
    return np.asarray((index.dayofweek < 5) & (tod >= _hm(p.session_start)) & (tod < _hm(p.session_end)))


def session_bars(df: pd.DataFrame, p: Params) -> pd.DataFrame:
    """The series the rules run on: session bars only, glued end to end across days."""
    p.need()
    return df if df.empty else df[session_mask(pd.DatetimeIndex(df.index), p)]


def in_session(ts, p: Params) -> bool:
    ts = pd.Timestamp(ts)
    tod = ts - ts.normalize()
    return ts.dayofweek < 5 and _hm(p.session_start) <= tod < _hm(p.session_end)
