"""
selection.py - Golden Ratio: the periodic re-rank (the part that decides WHAT gets traded)

The entry rules on their own were not the edge. The method that measured best was to re-rank
the whole candidate pool on a fixed schedule and trade only the top few until the next re-rank:

  1  Fold each candidate's latest broker history into a local archive (brokers serve a limited
     window; the archive keeps growing, so later re-ranks see more history).
  2  Keep session bars only - the same series the rules run on.
  3  Score every (instrument, sweep on / off) pair on a trailing window with evaluate_live(),
     i.e. exactly the way the bot trades, at a fixed ranking cost. Each exposure keeps its
     better sweep mode.
  4  Drop anything whose real round-trip cost (median session spread + commission) is over
     budget, then take the top N by profit factor.

The result is saved with the date it was made and the date it expires, so a restart never
re-ranks in the middle of a holding window.

Not published: the candidate pool, N, the window lengths, the trade minimum and the cost
budget. SELECT is REDACTED and need() refuses to run until it is filled in.
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import strategy

log = logging.getLogger("selection")

REDACTED = None
COLS = ["open", "high", "low", "close", "volume", "spread_bp"]


@dataclass(frozen=True)
class SelectConfig:
    top_n: Optional[int] = REDACTED                 # instruments traded per holding window
    lookback_months: Optional[float] = REDACTED     # trailing window ranked on
    min_lookback_months: Optional[float] = REDACTED # rank on less while the archive builds up
    hold_months: Optional[int] = REDACTED           # how long a selection holds
    min_trades: Optional[int] = REDACTED            # a candidate needs this many trades in the window
    min_session_bars: Optional[int] = REDACTED      # history needed to be considered at all
    rank_cost_bp: Optional[float] = REDACTED        # round-trip cost used inside the ranking
    max_cost_bp: Optional[float] = REDACTED         # real cost budget; above it = not a candidate
    spread_days: Optional[int] = REDACTED           # recent days the median session spread is taken over
    commission_bp: Dict[str, float] = field(default_factory=dict)   # per-symbol, round trip

    def need(self) -> "SelectConfig":
        missing = [k for k, v in asdict(self).items() if v is None]
        if missing:
            raise ValueError("selection settings not published - set: " + ", ".join(missing))
        return self


SELECT = SelectConfig()


# ----------------------------------------------------------------------------- archive

class Archive:
    """One parquet file of 5-minute bars per symbol; each pull from the broker is merged in."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, symbol: str) -> Path:
        safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in symbol)
        return self.root / f"{safe}_M5.parquet"

    def read(self, symbol: str) -> Optional[pd.DataFrame]:
        p = self._path(symbol)
        if not p.exists():
            return None
        try:
            return pd.read_parquet(p)
        except Exception as exc:                    # a corrupt file must not stop the bot
            log.warning("%s: archive unreadable (%s) - starting fresh", symbol, exc)
            return None

    def merge(self, symbol: str, fresh: pd.DataFrame) -> pd.DataFrame:
        old = self.read(symbol)
        fresh = fresh.reindex(columns=COLS)
        if old is not None and not old.empty:
            old = old.reindex(columns=COLS)
            fresh = pd.concat([old, fresh[~fresh.index.isin(old.index)]])
        fresh = fresh[~fresh.index.duplicated(keep="first")].sort_index()
        try:
            fresh.to_parquet(self._path(symbol))
        except OSError as exc:
            log.warning("%s: could not write archive (%s)", symbol, exc)
        return fresh


# ----------------------------------------------------------------------------- the selection

@dataclass
class Pick:
    exposure: str
    symbol: str
    sweep: bool
    pf: float
    win_rate: float
    trades: int
    cost_bp: float          # median session spread + commission, round trip (-1 = unknown)


@dataclass
class Selection:
    made_on: str
    rerank_on: str
    months_used: float
    picks: List[Pick]
    standings: List[Pick] = field(default_factory=list)

    def due(self, now) -> bool:
        return pd.Timestamp(now).normalize() >= pd.Timestamp(self.rerank_on)

    def book(self) -> Dict[str, bool]:
        """symbol -> sweep flag for the instruments to trade."""
        return {p.symbol: p.sweep for p in self.picks}


def load(path: str | Path) -> Optional[Selection]:
    p = Path(path)
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return Selection(d["made_on"], d["rerank_on"], float(d["months_used"]),
                         [Pick(**x) for x in d["picks"]], [Pick(**x) for x in d.get("standings", [])])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        log.warning("%s unreadable (%s) - will re-rank", path, exc)
        return None


def save(sel: Selection, path: str | Path) -> None:
    Path(path).write_text(json.dumps(asdict(sel), indent=2), encoding="utf-8")


def median_spread_bp(sess: pd.DataFrame, days: int) -> float:
    if sess.empty or "spread_bp" not in sess:
        return float("nan")
    recent = sess[sess.index >= sess.index[-1] - pd.Timedelta(days=days)]
    s = recent["spread_bp"].replace([np.inf, -np.inf], np.nan).dropna()
    s = s[s > 0]
    return float(s.median()) if len(s) else float("nan")


def rank(data: Dict[str, pd.DataFrame], exposure_of: Dict[str, str], as_of: datetime,
         p: strategy.Params, cfg: SelectConfig) -> Tuple[List[Pick], List[Pick], float]:
    """Returns (picks, full standings, months of history used)."""
    p.need(), cfg.need()
    end = pd.Timestamp(as_of)
    sessions, spans = {}, {}
    for sym, df in data.items():
        sess = strategy.session_bars(df[df.index < end], p)
        if len(sess) < cfg.min_session_bars:
            log.warning("  %-12s only %d session bars - left out", sym, len(sess))
            continue
        sessions[sym], spans[sym] = sess, (end - sess.index[0]).days / 30.44
    usable = {s: m for s, m in spans.items() if m >= cfg.min_lookback_months}
    if not usable:
        raise RuntimeError("no instrument has enough history to rank yet")
    months = min(cfg.lookback_months, min(usable.values()))
    start = end - pd.Timedelta(days=months * 30.44)

    best: Dict[str, Pick] = {}
    standings: List[Pick] = []
    for sym in usable:
        win = sessions[sym][sessions[sym].index >= start]
        spread = median_spread_bp(win, cfg.spread_days)
        cost = spread + cfg.commission_bp.get(sym, 0.0) if spread == spread else float("nan")
        for sweep in (False, True):
            r = strategy.evaluate_live(win, strategy.signals(win, p, sweep), p, cfg.rank_cost_bp)
            if not r or r["trades"] < cfg.min_trades:
                continue
            pick = Pick(exposure_of.get(sym, sym), sym, sweep, r["pf"], r["win_rate"], r["trades"],
                        float(cost) if cost == cost else -1.0)
            standings.append(pick)
            if cost == cost and cost > cfg.max_cost_bp:
                continue
            cur = best.get(pick.exposure)
            if cur is None or pick.pf > cur.pf:
                best[pick.exposure] = pick
    standings.sort(key=lambda x: -x.pf)
    picks = sorted(best.values(), key=lambda x: -x.pf)[:cfg.top_n]
    return picks, standings, float(months)


def choose(data, exposure_of, as_of: datetime, p: strategy.Params, cfg: SelectConfig) -> Selection:
    picks, standings, months = rank(data, exposure_of, as_of, p, cfg)
    made = pd.Timestamp(as_of).normalize()
    return Selection(made.strftime("%Y-%m-%d"),
                     (made + pd.DateOffset(months=cfg.hold_months)).strftime("%Y-%m-%d"),
                     round(months, 1), picks, standings)


def describe(sel: Selection) -> str:
    lines = [f"selection made {sel.made_on} on {sel.months_used} months, re-ranks {sel.rerank_on}",
             f"  {'exposure':<12}{'symbol':<14}{'sweep':>6}{'PF':>7}{'win':>7}{'trades':>8}{'cost':>9}"]
    for p in sel.picks:
        cost = f"{p.cost_bp:.1f}bp" if p.cost_bp >= 0 else "n/a"
        lines.append(f"  {p.exposure:<12}{p.symbol:<14}{'on' if p.sweep else 'off':>6}"
                     f"{p.pf:>7.3f}{p.win_rate:>7.1%}{p.trades:>8,}{cost:>9}")
    return "\n".join(lines)
