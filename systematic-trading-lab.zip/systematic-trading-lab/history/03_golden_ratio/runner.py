"""
runner.py - Golden Ratio: the loop that turns the selection and the rules into MetaTrader 5 orders

Every 5-minute close (plus a short delay so slow symbols have printed their bar):
  1  re-rank if the holding window has ended (never during the session)
  2  exits first: close any position that has reached its max hold, counted in session bars
  3  entries: for each selected instrument with no position, if the newest closed session bar
     fires, size the trade from the risk budget and what one lot loses at the stop (asked from
     MT5 itself), send a market order with the stop attached, then put the target on the server

All broker access goes through the published MT5 layer in live/broker.py: measured server clock,
closed-bar logic, lot sizing via order_calc_profit, stops on the server from the first moment,
retries on requotes, dry-run mode. The prop-firm loss-floor checks the live bot runs before every
entry are in live/risk.py and are not repeated here.

Not published: the universe, risk, magic number and timers (RUN is REDACTED), plus everything in
strategy.PARAMS and selection.SELECT. Terminal login details are read from a local, git-ignored
.env by live/broker.py - never from code.

    python runner.py            # dry run: reads everything for real, sends nothing
    python runner.py --live     # trades
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))                             # this folder's strategy.py first ...
sys.path.append(str(HERE.parents[1] / "live"))            # ... then the published MT5 layer

import selection                                          # noqa: E402
import strategy                                           # noqa: E402
import broker as mt5_layer                                # noqa: E402  (live/broker.py)

log = logging.getLogger("golden_ratio")

REDACTED = None
BAR = timedelta(minutes=5)


@dataclass(frozen=True)
class RunConfig:
    universe: Optional[Dict[str, List[str]]] = REDACTED   # exposure -> broker symbol(s)
    risk_pct: Optional[float] = REDACTED                  # of the reference balance, per trade
    magic: Optional[int] = REDACTED                       # tags this bot's positions in MT5
    signal_bars: Optional[int] = REDACTED                 # M5 bars pulled per signal check
    rank_bars: Optional[int] = REDACTED                   # M5 bars pulled per re-rank
    bar_delay_s: Optional[float] = REDACTED               # evaluate this long after each close
    max_entry_spread_bp: Optional[float] = REDACTED       # skip an entry if the live spread is wider
    loop_seconds: Optional[float] = REDACTED              # pause between loop passes

    def need(self) -> "RunConfig":
        missing = [k for k, v in asdict(self).items() if v is None]
        if missing:
            raise SystemExit("run settings not published - set: " + ", ".join(missing))
        return self


RUN = RunConfig()


class Runner:
    def __init__(self, b: mt5_layer.Broker, p: strategy.Params, sc: selection.SelectConfig,
                 rc: RunConfig, workdir: Path):
        self.b, self.p, self.sc, self.rc = b, p.need(), sc.need(), rc.need()
        self.archive = selection.Archive(workdir / "bars")
        self.sel_path = workdir / "selection.json"
        self.sel: Optional[selection.Selection] = selection.load(self.sel_path)
        self.last_bar: Optional[pd.Timestamp] = None
        self.ref_balance: Optional[float] = None
        self.d = 1 if self.p.direction == "LONG" else -1

    # -- setup -----------------------------------------------------------------------

    def symbols(self) -> List[str]:
        return [s for syms in self.rc.universe.values() for s in syms]

    def start(self) -> None:
        self.b.refresh_offset(self.symbols(), force=True)
        acct = self.b.account()
        self.ref_balance = self.b.initial_deposit() or float(acct.balance)
        log.info("reference balance %.2f | %s", self.ref_balance,
                 "LIVE" if self.b.live else "dry run (no orders)")
        open_now = self.b.positions()
        if open_now:
            log.info("adopted %d open position(s): %s", len(open_now),
                     ", ".join(p.symbol for p in open_now))

    # -- the re-rank -----------------------------------------------------------------

    def rerank(self, now: datetime) -> None:
        data, exposure_of = {}, {}
        for exposure, syms in self.rc.universe.items():
            for sym in syms:
                fresh = self.b.bars(sym, self.rc.rank_bars)
                if fresh.empty:
                    log.warning("%s: no history from the terminal - left out", sym)
                    continue
                data[sym], exposure_of[sym] = self.archive.merge(sym, fresh), exposure
        self.sel = selection.choose(data, exposure_of, now, self.p, self.sc)
        selection.save(self.sel, self.sel_path)
        log.info("re-ranked\n%s", selection.describe(self.sel))

    # -- exits -----------------------------------------------------------------------

    def held_bars(self, pos, sess: pd.DataFrame) -> int:
        """Session bars held so far, counting the signal bar (the one before the entry)."""
        opened = pd.Timestamp(self.b.to_utc(pos.time)).floor("5min")
        return 1 + int((sess.index >= opened).sum())

    def manage_exits(self) -> None:
        for pos in self.b.positions():
            sess = strategy.session_bars(self.b.bars(pos.symbol, self.rc.signal_bars), self.p)
            if self.held_bars(pos, sess) >= self.p.max_hold:
                log.info("%s #%s: max hold reached - closing", pos.symbol, pos.ticket)
                self.b.close(pos, "max hold")

    # -- entries ---------------------------------------------------------------------

    def set_target(self, ticket: int, sym: str, fill: float) -> None:
        """broker.open() puts the stop on the server with the order; the target goes on right after."""
        mt5, pos, info = self.b.mt5, self.b.position(ticket), self.b.info(sym)
        if pos is None or info is None:
            return
        _, target = strategy.brackets(fill, self.p)
        req = {"action": mt5.TRADE_ACTION_SLTP, "position": int(ticket), "symbol": sym,
               "sl": float(pos.sl), "tp": round(target, int(info.digits)), "magic": int(pos.magic)}
        res = mt5.order_send(req)
        if res is None or res.retcode not in (mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_NO_CHANGES):
            log.error("%s #%s: target not set (%s) - the stop is in place; set the target in MT5",
                      sym, ticket, res.comment if res is not None else mt5.last_error())

    def try_enter(self, sym: str, sweep: bool, bar: pd.Timestamp) -> None:
        positions = self.b.positions()
        if any(p.symbol == sym for p in positions) or len(positions) >= self.sc.top_n:
            return
        sess = strategy.session_bars(self.b.bars(sym, self.rc.signal_bars), self.p)
        if sess.empty or sess.index[-1] != bar:
            return                                         # this symbol's bar hasn't printed: skip
        if not strategy.signal_now(sess, self.p, sweep):
            return
        spread = self.b.spread_bp(sym)
        if spread is None or spread > self.rc.max_entry_spread_bp:
            log.info("%s: signal skipped - spread %s bp", sym, "n/a" if spread is None else f"{spread:.1f}")
            return
        tick = self.b.tick(sym)
        entry = float(tick.ask if self.d > 0 else tick.bid)
        stop, _ = strategy.brackets(entry, self.p)
        per_lot = self.b.loss_per_lot(sym, self.d, entry, stop)
        if not per_lot:
            log.warning("%s: MT5 could not price the stop - skipped", sym)
            return
        lots = self.b.round_lots(sym, self.ref_balance * self.rc.risk_pct / per_lot)
        if lots <= 0:
            log.info("%s: signal skipped - size rounds below the minimum lot", sym)
            return
        res = self.b.open(sym, self.d, lots, abs(entry - stop), self.rc.magic, "entry")
        if res.ok:
            log.info("OPENED %s %.2f lots @ %.5f", sym, lots, res.price)
            self.set_target(res.ticket, sym, res.price)

    # -- one loop --------------------------------------------------------------------

    def step(self) -> None:
        now = mt5_layer.utcnow()
        if not self.b.ensure():
            return
        self.b.refresh_offset(self.symbols())
        if self.sel is None or (self.sel.due(now) and not strategy.in_session(now, self.p)):
            self.rerank(now)
        boundary = pd.Timestamp(now - timedelta(seconds=self.rc.bar_delay_s)).floor("5min")
        if boundary == self.last_bar:
            return
        self.last_bar = boundary
        bar = boundary - BAR                                # the bar that just closed
        self.manage_exits()                                 # exits before entries
        if not strategy.in_session(bar, self.p):
            return
        for sym, sweep in self.sel.book().items():
            self.try_enter(sym, sweep, bar)


def main() -> None:
    ap = argparse.ArgumentParser(description="Golden Ratio runner (MetaTrader 5)")
    ap.add_argument("--live", action="store_true", help="send orders (default: dry run)")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(message)s")
    rc = RUN.need()
    b = mt5_layer.Broker(live=args.live, magics=[rc.magic], comment="gr-runner",
                         env_path=HERE / ".env")
    b.connect()
    runner = Runner(b, strategy.PARAMS, selection.SELECT, rc, HERE)
    runner.start()
    try:
        while True:
            try:
                runner.step()
            except Exception:
                log.exception("loop failed - continuing")
            time.sleep(rc.loop_seconds)
    finally:
        b.shutdown()


if __name__ == "__main__":
    main()
