"""
webhook_receiver.py - TradingView alert -> checks -> Alpaca order (summer 2026)

The architecture was brain / nervous system / muscles:
    brain     market_context.pine on TradingView classifies each ticker (regime, VWAP side, volume)
              and scores it 0-100
    nerves    a TradingView alert POSTs that context here as JSON
    muscles   this receiver decides whether the context is good enough, sends the order to Alpaca,
              waits for the broker to confirm the fill and logs the real fill price

What this file shows
    * a shared-secret check on every request (constant-time compare); bad or missing -> 401
    * strict payload validation: unknown actions, symbols or malformed numbers are refused
    * duplicate-alert suppression and one signal at a time (a lock), so a burst of alerts can't
      double an order
    * a receiver-side score gate that is independent of the indicator's own thresholds
    * position-aware actions: "buy" opens a long or covers a short, "sell" closes a long or (if
      allowed) opens a short - never a second position on the same symbol
    * fills confirmed with the broker before anything is logged as done; unfilled orders are cancelled
    * a CSV journal of every signal: received, blocked (and why), filled (signal price vs fill price)

Not published: the watchlist, score gates, sizing and timers - all REDACTED, and the server
refuses to start until they are set. Secrets come from environment variables only:

    APCA_API_KEY_ID / APCA_API_SECRET_KEY   Alpaca keys
    APCA_API_BASE_URL                        optional, defaults to paper trading
    WEBHOOK_PASSPHRASE                       must match the passphrase typed into the indicator

    python webhook_receiver.py --port 5000    # then expose /webhook through a tunnel (e.g. ngrok)
"""
from __future__ import annotations

import argparse
import csv
import hmac
import json
import logging
import math
import os
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional

import requests
from flask import Flask, jsonify, request

log = logging.getLogger("webhook")

PAPER_URL = "https://paper-api.alpaca.markets"
REDACTED = None
POLL_SECONDS = 0.5


@dataclass
class Settings:
    symbols: Optional[List[str]] = REDACTED          # tickers this receiver will trade
    min_buy_score: Optional[int] = REDACTED          # a buy needs at least this context score
    max_sell_score: Optional[int] = REDACTED         # a sell needs at most this context score
    notional_per_trade: Optional[float] = REDACTED   # USD per new position
    max_positions: Optional[int] = REDACTED
    allow_short: Optional[bool] = REDACTED
    dedupe_seconds: Optional[float] = REDACTED       # ignore a repeat of the same symbol + action
    fill_timeout: Optional[float] = REDACTED         # seconds to wait for a fill before cancelling

    def check(self) -> None:
        missing = [k for k, v in asdict(self).items() if v is None]
        if missing:
            raise SystemExit("settings not published - set these before running: " + ", ".join(missing))


SETTINGS = Settings()


# ----------------------------------------------------------------------------- broker

class Alpaca:
    def __init__(self, key: str, secret: str, base_url: str = PAPER_URL, timeout: float = 10.0):
        self.base, self.timeout = base_url.rstrip("/"), timeout
        self.http = requests.Session()
        self.http.headers.update({"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret})

    def _call(self, method: str, path: str, **kw):
        try:
            r = self.http.request(method, self.base + path, timeout=self.timeout, **kw)
        except requests.RequestException as exc:
            log.warning("%s %s failed: %s", method, path, exc)
            return None
        if r.status_code in (200, 201, 207):
            return r.json()
        if r.status_code == 204:
            return {}
        log.warning("%s %s -> HTTP %s: %s", method, path, r.status_code, r.text[:200])
        return None

    def market_open(self) -> bool:
        return bool((self._call("GET", "/v2/clock") or {}).get("is_open"))

    def positions(self) -> Optional[Dict[str, dict]]:
        data = self._call("GET", "/v2/positions")
        return None if data is None else {p["symbol"]: p for p in data}

    def submit_market(self, symbol: str, qty: float, side: str) -> Optional[str]:
        data = self._call("POST", "/v2/orders", json={"symbol": symbol, "qty": f"{qty:.9g}",
                                                      "side": side, "type": "market",
                                                      "time_in_force": "day"})
        return (data or {}).get("id")

    def order(self, order_id: str) -> Optional[dict]:
        return self._call("GET", f"/v2/orders/{order_id}")

    def cancel(self, order_id: str) -> None:
        self._call("DELETE", f"/v2/orders/{order_id}")


# ----------------------------------------------------------------------------- the receiver

class Rejected(Exception):
    def __init__(self, reason: str, http: int = 200):
        super().__init__(reason)
        self.reason, self.http = reason, http


@dataclass
class Signal:
    action: str
    symbol: str
    score: int
    regime: str
    price: float
    timeframe: str


def parse(raw: bytes, passphrase: str, allowed: List[str]) -> Signal:
    try:
        d = json.loads(raw.decode("utf-8"))        # TradingView posts the alert text as text/plain
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise Rejected("body is not JSON", 400)
    if not isinstance(d, dict):
        raise Rejected("body is not a JSON object", 400)
    if not hmac.compare_digest(str(d.get("passphrase", "")).encode(), passphrase.encode()):
        raise Rejected("bad passphrase", 401)
    action = str(d.get("action", "")).lower()
    if action not in ("buy", "sell"):
        raise Rejected(f"unknown action {action!r}", 400)
    symbol = str(d.get("symbol", "")).upper().split(":")[-1]
    if symbol not in allowed:
        raise Rejected(f"{symbol or 'missing symbol'} is not on the watchlist")
    try:
        score, price = int(d["score"]), float(d["price"])
    except (KeyError, TypeError, ValueError):
        raise Rejected("score / price missing or not numbers", 400)
    if not 0 <= score <= 100 or not math.isfinite(price) or price <= 0:
        raise Rejected("score / price out of range", 400)
    return Signal(action, symbol, score, str(d.get("regime", "unknown")), price,
                  str(d.get("timeframe", "")))


class Receiver:
    def __init__(self, settings: Settings, broker: Alpaca, passphrase: str,
                 journal: Path = Path("signals.csv"), clock: Callable[[], float] = time.time,
                 sleep: Callable[[float], None] = time.sleep):
        settings.check()
        if not passphrase:
            raise SystemExit("set WEBHOOK_PASSPHRASE in the environment")
        self.s, self.b, self.passphrase = settings, broker, passphrase
        self.journal, self.now, self.sleep = journal, clock, sleep
        self.lock = threading.Lock()
        self.last_seen: Dict[tuple, float] = {}

    # -- journal ---------------------------------------------------------------------

    def record(self, sig: Optional[Signal], result: str, detail: str = "",
               fill: Optional[float] = None, qty: Optional[float] = None) -> None:
        new = not self.journal.exists()
        with self.journal.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["time_utc", "symbol", "action", "regime", "score", "signal_price",
                            "fill_price", "qty", "result", "detail"])
            w.writerow([datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        sig.symbol if sig else "", sig.action if sig else "",
                        sig.regime if sig else "", sig.score if sig else "",
                        sig.price if sig else "", "" if fill is None else f"{fill:.4f}",
                        "" if qty is None else f"{qty:g}", result, detail])

    # -- orders ----------------------------------------------------------------------

    def fill(self, symbol: str, qty: float, side: str) -> tuple[float, float]:
        """Send a market order and wait for the broker to confirm it. Returns (price, qty)."""
        order_id = self.b.submit_market(symbol, qty, side)
        if not order_id:
            raise Rejected("broker refused the order")
        deadline = self.now() + self.s.fill_timeout
        while True:
            info = self.b.order(order_id) or {}
            status = info.get("status")
            if status == "filled":
                return float(info["filled_avg_price"]), float(info["filled_qty"])
            if status in ("canceled", "expired", "rejected"):
                raise Rejected(f"order {status}")
            if self.now() >= deadline:
                self.b.cancel(order_id)
                done = float(info.get("filled_qty") or 0)
                if done > 0:                                   # partial: keep what filled
                    return float(info["filled_avg_price"]), done
                raise Rejected("not filled in time - cancelled")
            self.sleep(POLL_SECONDS)

    # -- one alert -------------------------------------------------------------------

    def handle(self, raw: bytes) -> tuple[dict, int]:
        sig = None
        try:
            sig = parse(raw, self.passphrase, self.s.symbols)
            with self.lock:                                    # one signal at a time
                return self._act(sig), 200
        except Rejected as r:
            if r.http != 401:                                  # don't journal probes with no passphrase
                self.record(sig, "blocked", r.reason)
            log.info("blocked %s: %s", f"{sig.action} {sig.symbol}" if sig else "request", r.reason)
            return {"status": "blocked", "reason": r.reason}, r.http

    def _act(self, sig: Signal) -> dict:
        s, now = self.s, self.now()
        key = (sig.symbol, sig.action)
        if now - self.last_seen.get(key, float("-inf")) < s.dedupe_seconds:
            raise Rejected("duplicate alert")
        if sig.action == "buy" and sig.score < s.min_buy_score:
            raise Rejected(f"score {sig.score} below the buy gate")
        if sig.action == "sell" and sig.score > s.max_sell_score:
            raise Rejected(f"score {sig.score} above the sell gate")
        if not self.b.market_open():
            raise Rejected("market closed")
        held = self.b.positions()
        if held is None:
            raise Rejected("could not read positions - doing nothing")
        self.last_seen[key] = now                              # from here on the alert is acted on
        pos = held.get(sig.symbol)
        qty_held = float(pos["qty"]) if pos else 0.0           # negative for a short

        if sig.action == "buy" and qty_held > 0:
            raise Rejected("already long")
        if sig.action == "sell" and qty_held < 0:
            raise Rejected("already short")
        if qty_held != 0:                                      # opposite signal: close what is held
            side = "sell" if qty_held > 0 else "buy"
            price, qty = self.fill(sig.symbol, abs(qty_held), side)
            entry = float(pos["avg_entry_price"])
            pnl = (price - entry) * qty * (1 if qty_held > 0 else -1)
            self.record(sig, "closed", f"entry {entry:.4f} pnl {pnl:+.2f}", price, qty)
            log.info("CLOSED %s %g @ %.4f (entry %.4f, %+.2f)", sig.symbol, qty, price, entry, pnl)
            return {"status": "closed", "fill": price, "qty": qty, "pnl": round(pnl, 2)}

        if sig.action == "sell" and not s.allow_short:
            raise Rejected("no long to close and shorting is off")
        if len(held) >= s.max_positions:
            raise Rejected("max positions open")
        qty = math.floor(s.notional_per_trade / sig.price)
        if qty < 1:
            raise Rejected("size rounds to zero shares")
        price, qty = self.fill(sig.symbol, qty, sig.action)
        self.record(sig, "opened", f"slippage {price - sig.price:+.4f}", price, qty)
        log.info("OPENED %s %s %g @ %.4f | signal %.4f | regime %s | score %d",
                 sig.action.upper(), sig.symbol, qty, price, sig.price, sig.regime, sig.score)
        return {"status": "opened", "fill": price, "qty": qty}


def create_app(receiver: Receiver) -> Flask:
    app = Flask(__name__)

    @app.post("/webhook")
    def webhook():
        body, code = receiver.handle(request.get_data(cache=False))
        return jsonify(body), code

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    return app


def main() -> None:
    ap = argparse.ArgumentParser(description="TradingView webhook -> Alpaca")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--live", action="store_true", help="allow a non-paper endpoint")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(message)s")
    key, secret = os.environ.get("APCA_API_KEY_ID"), os.environ.get("APCA_API_SECRET_KEY")
    if not key or not secret:
        raise SystemExit("set APCA_API_KEY_ID and APCA_API_SECRET_KEY in the environment")
    url = os.environ.get("APCA_API_BASE_URL", PAPER_URL)
    if url.rstrip("/") != PAPER_URL and not args.live:
        raise SystemExit(f"{url} is not the paper endpoint - pass --live to trade it")
    receiver = Receiver(SETTINGS, Alpaca(key, secret, url), os.environ.get("WEBHOOK_PASSPHRASE", ""))
    create_app(receiver).run(host="127.0.0.1", port=args.port, debug=False)


if __name__ == "__main__":
    main()
