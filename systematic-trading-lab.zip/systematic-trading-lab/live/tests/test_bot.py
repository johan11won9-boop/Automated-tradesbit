"""
Code-path tests for the live bot against a fake MT5 (tests/fake_mt5.py): sizing, floors, orders,
stops, exits, the session close, restarts. They check the plumbing, not the strategy -
a private parity test checks the rules against the research lab.

    python -m pytest tests -q
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import fake_mt5                                            # noqa: E402
sys.modules["MetaTrader5"] = fake_mt5

import broker as broker_mod                                # noqa: E402
import bot as bot_mod                                      # noqa: E402
import config as cfg                                       # noqa: E402
import news as news_mod                                    # noqa: E402
import strategy                                            # noqa: E402

NOW = datetime(2026, 9, 23, 14, 30, 5)          # Wednesday 10:30:05 in New York (EDT)
OFFSET = 3 * 3600
SYM = "XYZ"


def epoch(dt: datetime) -> float:
    return (dt - datetime(1970, 1, 1)).total_seconds()


def floor5(dt):
    return dt.replace(minute=dt.minute - dt.minute % 5, second=0, microsecond=0)


def session_index(end_utc: datetime, days: int = 40) -> pd.DatetimeIndex:
    """FTMO-style US stock bars: 09:35..15:55 New York on weekdays, up to the bar that closed by end_utc."""
    out = []
    end_ny = pd.Timestamp(end_utc).tz_localize("UTC").tz_convert("America/New_York")
    for d in pd.bdate_range(end=end_ny.normalize().tz_localize(None), periods=days):
        t = pd.date_range(f"{d.date()} 09:35", f"{d.date()} 15:55", freq="5min").tz_localize("America/New_York")
        out.append(t)
    idx = out[0].append(out[1:]).tz_convert("UTC").tz_localize(None)
    return idx[idx + pd.Timedelta(minutes=5) <= pd.Timestamp(end_utc)]


def synthetic(idx, start=250.0, seed=1, vol=0.0015):
    rng = np.random.default_rng(seed)
    c = start * np.exp(np.cumsum(rng.normal(0, vol, len(idx))))
    o = np.r_[c[0], c[:-1]]
    h = np.maximum(o, c) * (1 + rng.uniform(0, 0.0008, len(idx)))
    l = np.minimum(o, c) * (1 - rng.uniform(0, 0.0008, len(idx)))
    v = rng.integers(200, 900, len(idx))
    return pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": v}, index=idx)


def install(w, df):
    w.set_rates(SYM, df.index, df.open.values, df.high.values, df.low.values, df.close.values, df.volume.values)
    w.set_price(SYM, float(df.close.iloc[-1]))


@pytest.fixture
def world(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)                     # the bot chdirs into its workdir; put it back after
    w = fake_mt5.World(offset_s=OFFSET, balance=100_000.0, leverage=3.33)
    w.now_epoch = epoch(NOW)
    w.deals[0].time = int(epoch(datetime(2026, 9, 1))) + OFFSET
    w.add_symbol(SYM, 250.0, contract=1.0, point=0.01, digits=2, vol_min=1.0, vol_step=1.0)
    install(w, synthetic(session_index(datetime(2026, 9, 25, 20, 0))))   # through Friday; the fake hides the future
    w.set_price(SYM, 250.0)
    fake_mt5.reset(w)
    monkeypatch.setattr(broker_mod, "epoch_now", lambda: w.now_epoch)
    monkeypatch.setattr(news_mod.News, "refresh", lambda self, now, force=False: None)
    monkeypatch.setattr(cfg, "INITIAL_BALANCE", 100_000)
    monkeypatch.setattr(cfg, "SYMBOL", SYM)
    monkeypatch.setattr(cfg, "VB", dict(k=0.6))                          # example values, not the live ones
    monkeypatch.setattr(cfg, "NA", dict(check=60, lookback=14, mult=1.0))
    monkeypatch.setattr(cfg, "ENTRY_CUTOFF_MIN", 60)
    monkeypatch.setattr(cfg, "PHASE", "evaluation")
    monkeypatch.setattr(cfg, "RISK_PCT", 0.01)
    monkeypatch.setattr(cfg, "ACCOUNT_TYPE", "standard")
    monkeypatch.setattr(bot_mod.time, "sleep", lambda s: None)
    return w


def make_bot(tmp_path, live=True):
    b = bot_mod.Bot(live=live, workdir=tmp_path)
    b.start()
    return b


def set_time(w, dt):
    w.now_epoch = epoch(dt)


def crafted(monkeypatch, bar_open_utc, **kw):
    """Make strategy.frame return one hand-made row for the bar opening at bar_open_utc."""
    row = dict(open=250.0, high=251.0, low=249.0, close=250.0, in_sess=True, day=1, date="2026-09-23",
               first=False, last=False, block=False, sessions_before=30.0, open_s=249.0, prev_close=248.0,
               prev_range=5.0, datr=6.0, vwap=249.5, vb_sig=0, vb_sd=2.5, na_sig=0, na_sd=3.0, na_ub=252.0,
               na_lb=246.0, na_check=False, na_exit_long=False, na_exit_short=False)
    row.update(kw)
    fr = pd.DataFrame([row], index=pd.DatetimeIndex([pd.Timestamp(bar_open_utc)]))
    monkeypatch.setattr(strategy, "frame", lambda df, c: fr)
    return row


def opens(w):
    return [r for r in w.sent if r["action"] == fake_mt5.TRADE_ACTION_DEAL and "position" not in r]


def closes(w):
    return [r for r in w.sent if r["action"] == fake_mt5.TRADE_ACTION_DEAL and "position" in r]


# --------------------------------------------------------------- end to end

def test_breakout_from_real_bars_buys_with_the_stop_on_the_server(world, tmp_path):
    idx = session_index(NOW)
    df = synthetic(idx, seed=3)
    fr = strategy.frame(df, cfg)
    today = fr[fr["date"] == fr["date"].iloc[-1]]
    # make the newest bar the day's first close above open + k x yesterday's range
    lvl = today["open_s"].iloc[-1] + cfg.VB["k"] * today["prev_range"].iloc[-1]
    for t in today.index[:-1]:
        for k in ("open", "high", "low", "close"):
            df.loc[t, k] = min(df.loc[t, k], lvl - 0.5)
    df.loc[today.index[-1], ["open", "low"]] = lvl - 0.5
    df.loc[today.index[-1], ["close", "high"]] = lvl + 0.8
    install(world, df)
    row = strategy.latest(strategy.frame(df, cfg))
    assert row["vb_sig"] == 1
    b = make_bot(tmp_path)
    b.step()
    o = [r for r in opens(world) if r["magic"] == cfg.MAGIC["VB"]]
    assert len(o) == 1 and o[0]["type"] == fake_mt5.ORDER_TYPE_BUY
    pos = next(p for p in world.positions if p.magic == cfg.MAGIC["VB"])
    assert pos.sl == pytest.approx(pos.price_open - row["vb_sd"], abs=0.011)
    assert pos.volume == np.floor(cfg.RISK_PCT * 100_000 / row["vb_sd"])                 # risk % of 100k, 1 share per lot
    # the same jump closes above the 10:30 noise band too, so NA (if it fired) went long as well
    assert len(opens(world)) == 1 + int(row["na_sig"] == 1)
    j = pd.read_csv(tmp_path / cfg.JOURNAL_FILE)
    assert set(j["event"]) == {"entry"}


def test_dry_run_sends_nothing(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path, live=False)
    b.step()
    assert opens(world) == [] and world.positions == []
    assert "dry-entry" in pd.read_csv(tmp_path / cfg.JOURNAL_FILE)["event"].tolist()


# ------------------------------------------------------------------ entries

def test_noise_short_entry_sizes_from_the_initial_balance(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), na_sig=-1, na_sd=4.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    o = opens(world)
    assert len(o) == 1 and o[0]["type"] == fake_mt5.ORDER_TYPE_SELL and o[0]["magic"] == cfg.MAGIC["NA"]
    p = world.positions[0]
    assert p.volume == 250 and p.sl == pytest.approx(p.price_open + 4.0, abs=0.011)


def test_both_rules_can_hold_a_position_at_once(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1, vb_sd=3.0, na_sig=1, na_sd=5.0,
            na_check=True)
    b = make_bot(tmp_path)
    b.step()
    assert sorted(p.magic for p in world.positions) == sorted(cfg.MAGIC.values())


def test_a_rule_never_holds_two_positions(world, tmp_path, monkeypatch):
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, na_sig=1, na_sd=5.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    set_time(world, NOW + timedelta(minutes=30))
    crafted(monkeypatch, bar + timedelta(minutes=30), na_sig=1, na_sd=5.0, na_check=True)
    b.step()
    assert len(world.positions) == 1


def test_old_signal_is_skipped(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    set_time(world, NOW + timedelta(seconds=120))       # the bar was only picked up 2 minutes late
    b.step()
    assert opens(world) == []


def test_same_bar_is_never_acted_on_twice_after_a_restart(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    b.step()
    world.positions.clear()                              # e.g. closed by hand
    b2 = make_bot(tmp_path)
    b2.step()
    assert len(opens(world)) == 1


# -------------------------------------------------------------------- exits

def test_noise_exit_closes_and_does_not_flip_on_the_same_bar(world, tmp_path, monkeypatch):
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, na_sig=1, na_sd=5.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    assert len(world.positions) == 1
    set_time(world, NOW + timedelta(minutes=30))
    crafted(monkeypatch, bar + timedelta(minutes=30), na_check=True, na_exit_long=True, na_sig=-1)
    b.step()
    assert world.positions == [] and len(closes(world)) == 1
    assert "exit" in closes(world)[0]["comment"]
    assert len(opens(world)) == 1                        # no short on the bar that closed the long
    j = pd.read_csv(tmp_path / cfg.JOURNAL_FILE)
    assert j["event"].tolist() == ["entry", "exit"]


def test_stop_during_the_bar_allows_a_new_entry_at_its_close(world, tmp_path, monkeypatch):
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, na_sig=1, na_sd=5.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    p = world.positions[0]
    set_time(world, NOW + timedelta(minutes=12))         # stopped out inside the next 30-minute block
    world.set_price(SYM, p.sl - 0.5)
    world.hit_stops()
    b.step()
    set_time(world, NOW + timedelta(minutes=30))
    crafted(monkeypatch, bar + timedelta(minutes=30), na_sig=-1, na_sd=5.0, na_check=True)
    b.step()
    assert len(opens(world)) == 2 and opens(world)[1]["type"] == fake_mt5.ORDER_TYPE_SELL


def test_stop_after_the_bar_closed_blocks_an_entry_on_that_bar(world, tmp_path, monkeypatch):
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, na_sig=1, na_sd=5.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    p = world.positions[0]
    nxt = bar + timedelta(minutes=30)
    set_time(world, nxt + timedelta(minutes=5, seconds=1))   # stop fills 1s after that bar closed
    world.set_price(SYM, p.sl - 0.5)
    world.hit_stops()
    set_time(world, nxt + timedelta(minutes=5, seconds=5))
    crafted(monkeypatch, nxt, na_sig=-1, na_sd=5.0, na_check=True)
    b.step()
    assert len(opens(world)) == 1                        # in the backtest it was still long at that close


def test_everything_closes_a_minute_before_the_close(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1, na_sig=-1, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    assert len(world.positions) == 2
    set_time(world, datetime(2026, 9, 23, 19, 59, 2))     # 15:59:02 New York
    crafted(monkeypatch, datetime(2026, 9, 23, 19, 50))
    b.step()
    assert world.positions == []
    assert all("close" in c["comment"] for c in closes(world))


def test_early_close_day_flattens_before_one_pm(world, tmp_path, monkeypatch):
    day = datetime(2026, 11, 27, 15, 0, 5)                # Friday after Thanksgiving, 10:00 New York
    world.offset_s = 2 * 3600                             # FTMO's clock is New York + 7h: UTC+2 in winter
    set_time(world, day)
    install(world, synthetic(session_index(day)))
    crafted(monkeypatch, floor5(day) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    b.step()
    assert len(world.positions) == 1
    set_time(world, datetime(2026, 11, 27, 17, 59, 5))     # 12:59:05 New York
    b.step()
    assert world.positions == []


def test_a_position_left_overnight_is_closed_at_the_open(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    b.step()
    world.market_open = False
    set_time(world, datetime(2026, 9, 23, 21, 0, 0))       # after the close; the bot was off at 15:59
    b.step()
    assert len(world.positions) == 1                      # market shut: can't close
    world.market_open = True
    set_time(world, datetime(2026, 9, 24, 13, 31, 0))       # 09:31 next day
    b._next_flat_try = 0
    b.step()
    assert world.positions == []


# --------------------------------------------------------------------- risk

def test_risk_is_cut_only_when_a_full_stop_would_not_fit(world, tmp_path, monkeypatch):
    world.acct.balance = 91_500.0                          # 1,500 above the 90k max-loss floor
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), na_sig=1, na_sd=4.0, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    p = world.positions[0]
    room = (91_500 - 90_000 - 0.005 * 100_000) / 1.25      # 800
    assert p.volume == np.floor(room / 4.0)
    worst = 91_500 - p.volume * 4.0 * 1.25
    assert worst >= 90_000 + 0.005 * 100_000 - 1e-6


def test_no_room_no_trade(world, tmp_path, monkeypatch):
    world.acct.balance = 90_400.0
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    b.step()
    assert opens(world) == []


def test_kill_switch_flattens_and_halts_until_the_daily_reset(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1, vb_sd=2.0)
    b = make_bot(tmp_path)
    b.step()
    world.positions[0].sl = 0.0                            # pretend the stop failed
    world.set_price(SYM, world.positions[0].price_open - 10.0)     # -$7,500ish: inside 0.3% of the daily floor
    set_time(world, NOW + timedelta(seconds=30))
    world.acct.balance = 100_000.0
    b.step()
    assert world.positions == [] and b.state.halt_until


def test_swing_one_to_one_leverage_cuts_the_size_to_fit_margin(world, tmp_path, monkeypatch):
    world.acct.leverage = 1.0
    monkeypatch.setattr(cfg, "ACCOUNT_TYPE", "swing")
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1, vb_sd=1.0)   # 1000 lots wanted
    b = make_bot(tmp_path)
    b.step()
    p = world.positions[0]
    assert p.volume * p.price_open <= 0.80 * 100_000 + 300


def test_refuses_to_trade_a_non_ftmo_account(world, tmp_path):
    world.acct.server, world.acct.company = "OtherBroker-Server", "Other Broker Ltd"
    with pytest.raises(RuntimeError):
        make_bot(tmp_path, live=True)


def test_a_new_login_files_the_old_account_away(world, tmp_path, monkeypatch):
    crafted(monkeypatch, floor5(NOW) - timedelta(minutes=5), vb_sig=1)
    b = make_bot(tmp_path)
    b.step()
    world.acct.login = 1520000
    world.positions.clear()
    make_bot(tmp_path)
    assert any(f.name.startswith("trades_1510000_") for f in tmp_path.iterdir())
    assert json.loads((tmp_path / cfg.STATE_FILE).read_text())["login"] == "1520000"


# --------------------------------------------------------------------- news

def test_news_rule_only_on_standard_funded(world, tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "PHASE", "funded")
    monkeypatch.setattr(cfg, "RISK_PCT", 0.0075)
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, vb_sig=1)
    b = make_bot(tmp_path)
    b.news.events = [(NOW + timedelta(minutes=1), "USD", "CPI")]
    b.step()
    assert opens(world) == []                              # entry inside the news window: skipped
    monkeypatch.setattr(cfg, "ACCOUNT_TYPE", "swing")
    b2 = make_bot(tmp_path / "x") if (tmp_path / "x").mkdir() is None else None
    b2.news.events = [(NOW + timedelta(minutes=1), "USD", "CPI")]
    b2.step()
    assert len(opens(world)) == 1                          # Swing has no news rule


def test_noise_exit_waits_out_a_news_window_on_standard_funded(world, tmp_path, monkeypatch):
    monkeypatch.setattr(cfg, "PHASE", "funded")
    monkeypatch.setattr(cfg, "RISK_PCT", 0.0075)
    bar = floor5(NOW) - timedelta(minutes=5)
    crafted(monkeypatch, bar, na_sig=1, na_check=True)
    b = make_bot(tmp_path)
    b.step()
    t_exit = NOW + timedelta(minutes=30)
    set_time(world, t_exit)
    crafted(monkeypatch, bar + timedelta(minutes=30), na_check=True, na_exit_long=True)
    b.news.events = [(t_exit + timedelta(minutes=1), "USD", "ISM")]
    b.step()
    assert len(world.positions) == 1                       # deferred
    set_time(world, t_exit + timedelta(minutes=5))
    b.step()
    assert world.positions == []                           # closed once the window passed


def test_a_whole_week_runs_clean_and_ends_flat_every_day(world, tmp_path):
    """Smoke test: the real rules on synthetic trending bars, the loop stepped every 5 seconds
    of simulated time through four sessions, prices and stops moving with the bars."""
    end = datetime(2026, 9, 25, 20, 10)
    idx = session_index(datetime(2026, 9, 25, 20, 0), days=45)
    df = synthetic(idx, seed=11, vol=0.004)                 # volatile enough to fire both rules
    install(world, df)
    b = make_bot(tmp_path)
    t = datetime(2026, 9, 22, 13, 25)
    closes_by_day = {}
    while t < end:
        set_time(world, t)
        k = df.index.searchsorted(pd.Timestamp(t), side="right") - 1
        if k >= 0:
            world.set_price(SYM, float(df["close"].iloc[k]))
            world.hit_stops()
        b.step()
        ny = pd.Timestamp(t).tz_localize("UTC").tz_convert("America/New_York")
        if ny.hour == 16 and ny.minute == 1:
            closes_by_day[str(ny.date())] = len(world.positions)
        t += timedelta(seconds=5)
    j = pd.read_csv(tmp_path / cfg.JOURNAL_FILE)
    n_in, n_out = (j["event"] == "entry").sum(), (j["event"] == "exit").sum()
    assert n_in >= 3 and n_in == n_out, j
    assert closes_by_day and all(v == 0 for v in closes_by_day.values()), closes_by_day
    assert world.positions == []
