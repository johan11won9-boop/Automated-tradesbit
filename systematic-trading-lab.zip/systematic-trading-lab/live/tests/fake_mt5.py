"""
A stand-in for the MetaTrader5 package, just enough to run the bot's code paths on any PC
without a terminal: longs and shorts, stops on the server, closes, deals, margin.
Prices are synthetic; nothing here says anything about the strategy.
"""
from __future__ import annotations

from types import SimpleNamespace as NS

import numpy as np
import pandas as pd

TIMEFRAME_M1, TIMEFRAME_M5 = 1, 5
ORDER_TYPE_BUY, ORDER_TYPE_SELL = 0, 1
ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN = 0, 1, 2
ORDER_TIME_GTC = 0
TRADE_ACTION_DEAL, TRADE_ACTION_SLTP = 1, 6
TRADE_RETCODE_DONE, TRADE_RETCODE_DONE_PARTIAL = 10009, 10010
TRADE_RETCODE_NO_CHANGES = 10025
TRADE_RETCODE_MARKET_CLOSED = 10018
DEAL_TYPE_BUY, DEAL_TYPE_SELL, DEAL_TYPE_BALANCE = 0, 1, 2
DEAL_ENTRY_IN, DEAL_ENTRY_OUT = 0, 1

RATE_DTYPE = np.dtype([("time", "<i8"), ("open", "<f8"), ("high", "<f8"), ("low", "<f8"),
                       ("close", "<f8"), ("tick_volume", "<u8"), ("spread", "<i4"),
                       ("real_volume", "<u8")])


class World:
    def __init__(self, offset_s: int = 3 * 3600, balance: float = 100_000.0, leverage: float = 3.33,
                 server: str = "FTMO-Demo"):
        self.offset_s = offset_s
        self.now_epoch = 0.0
        self.symbols = {}
        self.rates = {}
        self.positions = []
        self.deals = []
        self.sent = []
        self.next_ticket = 1000
        self.market_open = True
        self.acct = NS(login=1510000, server=server, company="FTMO Global Markets Ltd" if "FTMO" in server
                       else "Other Ltd", currency="USD", leverage=leverage, balance=balance, equity=balance,
                       margin_free=balance, trade_allowed=True)
        self.term = NS(connected=True, trade_allowed=True, maxbars=100_000)
        self.deals.append(NS(ticket=1, time=offset_s, type=DEAL_TYPE_BALANCE, entry=0, profit=balance,
                             commission=0.0, swap=0.0, fee=0.0, symbol="", position_id=0, price=0.0,
                             comment="initial"))

    def add_symbol(self, name, price, contract=1.0, point=0.01, digits=2, vol_min=1.0, vol_step=1.0,
                   vol_max=10_000.0, spread_pts=10, filling=1):
        self.symbols[name] = NS(name=name, point=point, digits=digits, trade_tick_size=point,
                                trade_tick_value=point * contract, trade_tick_value_loss=point * contract,
                                trade_contract_size=contract, volume_min=vol_min, volume_step=vol_step,
                                volume_max=vol_max, filling_mode=filling)
        self.set_price(name, price, spread_pts)

    def set_price(self, name, bid, spread_pts=10):
        pt = self.symbols[name].point
        self.symbols[name].bid = bid
        self.symbols[name].ask = bid + spread_pts * pt

    def set_rates(self, name, utc_index, o, h, l, c, v, spread_pts=10):
        arr = np.zeros(len(utc_index), dtype=RATE_DTYPE)
        arr["time"] = ((utc_index - pd.Timestamp("1970-01-01")) // pd.Timedelta("1s")) + self.offset_s
        arr["open"], arr["high"], arr["low"], arr["close"] = o, h, l, c
        arr["tick_volume"] = v
        arr["spread"] = spread_pts
        self.rates[name] = arr

    def margin_used(self):
        return sum(p.volume * self.symbols[p.symbol].trade_contract_size * p.price_open / self.acct.leverage
                   for p in self.positions)

    def mark(self):
        fl = 0.0
        for p in self.positions:
            s = self.symbols[p.symbol]
            px = s.bid if p.type == 0 else s.ask
            p.profit = (px - p.price_open) * (1 if p.type == 0 else -1) * p.volume * s.trade_contract_size
            p.price_current = px
            fl += p.profit
        self.acct.equity = self.acct.balance + fl
        self.acct.margin_free = self.acct.equity - self.margin_used()

    def hit_stops(self, comment="[sl]"):
        """Fill every stop the current price has crossed (as FTMO's server would)."""
        for p in list(self.positions):
            s = self.symbols[p.symbol]
            if p.sl and ((p.type == 0 and s.bid <= p.sl) or (p.type == 1 and s.ask >= p.sl)):
                close_position(p, p.sl, comment)


W = World()


def reset(world: World) -> None:
    global W
    W = world


def initialize(**kw): return True
def shutdown(): return None
def last_error(): return (0, "ok")
def account_info(): W.mark(); return W.acct
def terminal_info(): return W.term
def symbols_get(): return [NS(name=n) for n in W.symbols]
def symbol_select(name, on=True): return name in W.symbols
def symbol_info(name): return W.symbols.get(name)


def symbol_info_tick(name):
    s = W.symbols.get(name)
    if s is None:
        return None
    return NS(bid=s.bid, ask=s.ask, time=int(W.now_epoch) + W.offset_s)


def copy_rates_from_pos(name, tf, pos, count):
    arr = W.rates.get(name)
    if arr is None or count > W.term.maxbars:
        return None
    now_server = W.now_epoch + W.offset_s
    arr = arr[arr["time"] <= now_server]             # nothing from the future
    return arr[-count:] if count < len(arr) else arr


def order_calc_profit(kind, name, vol, open_, close):
    s = W.symbols[name]
    sign = 1 if kind == ORDER_TYPE_BUY else -1
    return sign * (close - open_) * vol * s.trade_contract_size


def order_calc_margin(kind, name, vol, price):
    s = W.symbols[name]
    return vol * s.trade_contract_size * price / W.acct.leverage


def positions_get(symbol=None, ticket=None):
    W.mark()
    out = W.positions
    if symbol is not None:
        out = [p for p in out if p.symbol == symbol]
    if ticket is not None:
        out = [p for p in out if p.ticket == ticket]
    return tuple(out)


def history_deals_get(*args, position=None):
    if position is not None:
        return tuple(d for d in W.deals if d.position_id == position)
    return tuple(W.deals)


def order_send(req):
    W.sent.append(dict(req))
    t_server = int(W.now_epoch) + W.offset_s
    if req["action"] == TRADE_ACTION_SLTP:
        for p in W.positions:
            if p.ticket == req["position"]:
                p.sl, p.tp = req["sl"], req["tp"]
        return NS(retcode=TRADE_RETCODE_DONE, order=0, price=0.0, comment="done")
    if not W.market_open:
        return NS(retcode=TRADE_RETCODE_MARKET_CLOSED, order=0, price=0.0, comment="Market closed")
    s = W.symbols[req["symbol"]]
    W.next_ticket += 1
    tk = W.next_ticket
    if "position" not in req:                                     # open
        is_buy = req["type"] == ORDER_TYPE_BUY
        fill = s.ask if is_buy else s.bid
        W.positions.append(NS(ticket=tk, symbol=req["symbol"], volume=req["volume"], price_open=fill,
                              sl=req["sl"], tp=req["tp"], profit=0.0, magic=req["magic"], time=t_server,
                              time_msc=t_server * 1000, type=0 if is_buy else 1, price_current=fill))
        W.deals.append(NS(ticket=tk, time=t_server, type=DEAL_TYPE_BUY if is_buy else DEAL_TYPE_SELL,
                          entry=DEAL_ENTRY_IN, profit=0.0, commission=0.0, swap=0.0, fee=0.0,
                          symbol=req["symbol"], position_id=tk, price=fill, comment=req.get("comment", "")))
        return NS(retcode=TRADE_RETCODE_DONE, order=tk, price=fill, comment="done")
    p = next(p for p in W.positions if p.ticket == req["position"])
    px = s.bid if p.type == 0 else s.ask
    close_position(p, px, req.get("comment", "close"))
    return NS(retcode=TRADE_RETCODE_DONE, order=tk, price=px, comment="done")


def close_position(p, price, comment):
    s = W.symbols[p.symbol]
    pnl = (price - p.price_open) * (1 if p.type == 0 else -1) * p.volume * s.trade_contract_size
    W.positions.remove(p)
    W.acct.balance += pnl
    W.deals.append(NS(ticket=W.next_ticket + 1, time=int(W.now_epoch) + W.offset_s,
                      type=DEAL_TYPE_SELL if p.type == 0 else DEAL_TYPE_BUY, entry=DEAL_ENTRY_OUT,
                      profit=pnl, commission=0.0, swap=0.0, fee=0.0, symbol=p.symbol,
                      position_id=p.ticket, price=price, comment=comment))
    W.next_ticket += 1
