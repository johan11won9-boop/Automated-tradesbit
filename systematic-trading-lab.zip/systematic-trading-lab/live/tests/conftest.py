# the tests run against config.example.py (copied to config.py if you haven't made one)
import shutil
from pathlib import Path

root = Path(__file__).resolve().parents[1]
if not (root / "config.py").exists():
    shutil.copy(root / "config.example.py", root / "config.py")
