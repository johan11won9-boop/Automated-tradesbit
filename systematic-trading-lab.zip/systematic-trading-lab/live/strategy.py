"""
strategy.py — the two intraday rules, computed exactly the way the research lab backtested them.
(Privately, a parity test replays this file against the lab's backtest kernel: 2,080 / 2,080
trades identical. Parameter values and the instrument are not published: see config.example.py.)

  VB  volatility breakout   the FIRST 5-minute close of the day beyond
                            day open +- k x yesterday's session range -> trade that way.
                            Stop: k x yesterday's range (at least 10% of the 14-day average range).
  NA  noise area            on every 30-minute mark, a close outside the "noise band":
                            max/min(day open, yesterday's close) x (1 +- mult x the average move
                            from the open at that time of day over the previous 14 days).
                            Stop: half the band's width (at least 5% of the 14-day average range).
                            Exit at a 30-minute mark once the close is back inside max(band, VWAP)
                            (longs) / min(band, VWAP) (shorts).
  Both: enter at the next bar's open, no target, flat at the session close, no new entry from
  a bar starting within ENTRY_CUTOFF_MIN of the close.

Everything is decided on CLOSED bars only. The frame is rebuilt from MT5's history on every bar,
so a restart never loses anything.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

BAR = 5   # minutes


def _mins(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def close_minute(date_str: str, cfg) -> int:
    return _mins(cfg.EARLY_CLOSE.get(date_str, cfg.SESSION_CLOSE))


def frame(df: pd.DataFrame, cfg) -> pd.DataFrame:
    """df: closed M5 bars, index = bar OPEN time in naive UTC, columns open/high/low/close/volume.
    Returns one row per bar with everything both rules need, plus their signals."""
    if df is None or df.empty:
        return pd.DataFrame()
    missing = [k for k, v in {**cfg.VB, **cfg.NA}.items() if v is None]
    if missing or cfg.ENTRY_CUTOFF_MIN is None:
        raise ValueError("strategy parameters are not published - set VB, NA and ENTRY_CUTOFF_MIN in config.py")
    df = df[~df.index.duplicated(keep="last")].sort_index()
    idx = pd.DatetimeIndex(df.index)
    n = len(idx)
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    h = np.maximum.reduce([h, o, c])
    l = np.minimum.reduce([l, o, c])
    v = df["volume"].to_numpy(dtype=float) if "volume" in df else np.ones(n)
    v = np.where(np.isfinite(v) & (v > 0), v, 1.0)

    so, sc = _mins(cfg.SESSION_OPEN), _mins(cfg.SESSION_CLOSE)
    loc = idx.tz_localize("UTC").tz_convert(cfg.SESSION_TZ).tz_localize(None)
    loc_min = np.asarray(loc.hour * 60 + loc.minute, dtype=float)
    wd = np.asarray(loc.dayofweek)
    in_sess = (loc_min >= so) & (loc_min + BAR <= sc) & (wd < 5)
    dnum = np.asarray((loc.normalize() - pd.Timestamp("2000-01-01")).days, dtype=np.int64)
    day = np.where(in_sess, dnum, -1).astype(np.int64)
    mfo = loc_min - so                      # minutes from the open to the bar's start
    mtc = sc - (loc_min + BAR)              # minutes from the bar's end to the (normal) close
    dstr = np.asarray(loc.strftime("%Y-%m-%d"))
    cm = np.array([close_minute(s, cfg) for s in dstr], dtype=float) if cfg.EARLY_CLOSE else np.full(n, sc, float)
    block = (cm - loc_min) <= cfg.ENTRY_CUTOFF_MIN    # FTMO gap rule, as the backtest applied it

    si = np.flatnonzero(in_sess)
    first = np.zeros(n, bool)
    last = np.zeros(n, bool)
    if len(si):
        ds = day[si]
        brk = ds[1:] != ds[:-1]
        first[si[np.r_[True, brk]]] = True
        last[si[np.r_[brk, True]]] = True
    sess = pd.DataFrame({"day": day[si], "o": o[si], "h": h[si], "l": l[si], "c": c[si],
                         "pv": ((h + l + c) / 3 * v)[si], "v": v[si]}, index=si)
    g = sess.groupby("day", sort=True)
    daily = pd.DataFrame({"open": g["o"].first(), "high": g["h"].max(), "low": g["l"].min(),
                          "close": g["c"].last()})
    daily["range"] = daily["high"] - daily["low"]
    daily["prev_close"] = daily["close"].shift(1)
    daily["prev_range"] = daily["range"].shift(1)
    daily["datr"] = daily["range"].rolling(14, min_periods=5).mean().shift(1)
    m = pd.Series(day)
    open_s = m.map(daily["open"]).to_numpy(dtype=float)
    prev_close = m.map(daily["prev_close"]).to_numpy(dtype=float)
    prev_range = m.map(daily["prev_range"]).to_numpy(dtype=float)
    datr = m.map(daily["datr"]).to_numpy(dtype=float)
    vwap = np.full(n, np.nan)
    if len(si):
        vwap[si] = (g["pv"].cumsum() / g["v"].cumsum()).to_numpy()
    sessions_before = m.map(pd.Series(np.arange(len(daily)), index=daily.index)).to_numpy(dtype=float)

    # ---------------------------------------------------------- VB
    k = cfg.VB["k"]
    up = in_sess & (c > open_s + k * prev_range) & ~block & (mtc >= 30)
    dn = in_sess & (c < open_s - k * prev_range) & ~block & (mtc >= 30)
    trig = np.zeros(n, bool)
    hit = np.flatnonzero(up | dn)
    if len(hit):
        dd = day[hit]
        trig[hit[np.r_[True, dd[1:] != dd[:-1]]]] = True
    vb_sig = np.where(trig & up, 1, np.where(trig & dn, -1, 0)).astype(np.int8)
    vb_sd = np.maximum(k * prev_range, 0.1 * np.nan_to_num(datr, nan=0.0))

    # ---------------------------------------------------------- NA
    lb, chk, mult = cfg.NA["lookback"], cfg.NA["check"], cfg.NA["mult"]
    move = np.abs(c / open_s - 1)
    key_t = (mfo + BAR).astype(int)
    s = pd.DataFrame({"day": day[in_sess], "t": key_t[in_sess], "mv": move[in_sess]})
    sigma = np.full(n, np.nan)
    if len(s):
        piv = s.pivot_table(index="day", columns="t", values="mv", aggfunc="last")
        sig_t = piv.rolling(lb, min_periods=max(5, lb // 2)).mean().shift(1)
        st = sig_t.stack()
        look = pd.Series(st.to_numpy(), index=pd.MultiIndex.from_arrays(
            [st.index.get_level_values(0), st.index.get_level_values(1)]))
        sigma = look.reindex(pd.MultiIndex.from_arrays([day, key_t])).to_numpy(dtype=float)
    sigma = sigma * mult
    ref_hi = np.fmax(open_s, prev_close)
    ref_lo = np.fmin(open_s, prev_close)
    ub, lbd = ref_hi * (1 + sigma), ref_lo * (1 - sigma)
    chkp = in_sess & (key_t % chk == 0) & (mfo + BAR >= chk) & np.isfinite(sigma)
    ok = chkp & ~block & (mtc >= BAR)
    na_sig = np.where(ok & (c > ub), 1, np.where(ok & (c < lbd), -1, 0)).astype(np.int8)
    na_exl = chkp & (c < np.fmax(ub, vwap))
    na_exs = chkp & (c > np.fmin(lbd, vwap))
    na_sd = np.maximum((ub - lbd) / 2, 0.05 * np.nan_to_num(datr, nan=0.0))

    # a signal needs a positive stop distance (as the backtest required)
    vb_sig = np.where(np.isfinite(vb_sd) & (vb_sd > 0), vb_sig, 0).astype(np.int8)
    na_sig = np.where(np.isfinite(na_sd) & (na_sd > 0), na_sig, 0).astype(np.int8)

    return pd.DataFrame({
        "open": o, "high": h, "low": l, "close": c, "in_sess": in_sess, "day": day,
        "date": dstr, "first": first, "last": last, "block": block, "sessions_before": sessions_before,
        "open_s": open_s, "prev_close": prev_close, "prev_range": prev_range, "datr": datr, "vwap": vwap,
        "vb_sig": vb_sig, "vb_sd": vb_sd,
        "na_sig": na_sig, "na_sd": na_sd, "na_ub": ub, "na_lb": lbd, "na_check": chkp,
        "na_exit_long": na_exl, "na_exit_short": na_exs,
    }, index=idx)


RULES = ("VB", "NA")


def decide(row: Dict, open_dir: Dict[str, int]) -> List[Tuple]:
    """What to do on the bar that just closed - the backtest's order of events.

    row       one row of frame() (the newest closed bar)
    open_dir  rule -> +1/-1 for each rule that holds a position right now
    returns   [("exit", "NA"), ("enter", rule, direction, stop_distance), ...]

    NA's exit check comes first. A rule that exits on this bar's signal does NOT re-enter on the
    same bar (the backtest was still in the trade at this close); a rule stopped out DURING the bar
    may enter at its close (it was already flat). VB fires once a day at most: only the day's first
    breakout bar carries a signal."""
    acts: List[Tuple] = []
    d = open_dir.get("NA")
    exiting = bool(d) and bool(row["na_check"]) and (
        (d > 0 and bool(row["na_exit_long"])) or (d < 0 and bool(row["na_exit_short"])))
    if exiting:
        acts.append(("exit", "NA"))
    if "VB" not in open_dir and int(row["vb_sig"]) != 0:
        acts.append(("enter", "VB", int(row["vb_sig"]), float(row["vb_sd"])))
    if "NA" not in open_dir and int(row["na_sig"]) != 0:
        acts.append(("enter", "NA", int(row["na_sig"]), float(row["na_sd"])))
    return acts


def latest(fr: pd.DataFrame) -> Optional[Dict]:
    """The newest closed bar's row as a dict (None if there is no data)."""
    if fr is None or fr.empty:
        return None
    r = fr.iloc[-1].to_dict()
    r["time"] = fr.index[-1]
    return r


# ------------------------------------------------------------- session clock

def session_times(now_utc, cfg):
    """(open_utc, close_utc, is_trading_day) for the New York date of now_utc, naive UTC."""
    ts = pd.Timestamp(now_utc).tz_localize("UTC").tz_convert(cfg.SESSION_TZ)
    d = ts.strftime("%Y-%m-%d")
    open_l = pd.Timestamp(f"{d} {cfg.SESSION_OPEN}").tz_localize(cfg.SESSION_TZ)
    close_l = pd.Timestamp(f"{d} {cfg.EARLY_CLOSE.get(d, cfg.SESSION_CLOSE)}").tz_localize(cfg.SESSION_TZ)
    to_utc = lambda t: t.tz_convert("UTC").tz_localize(None).to_pydatetime()   # noqa: E731
    return to_utc(open_l), to_utc(close_l), ts.dayofweek < 5


def in_session(now_utc, cfg) -> bool:
    o, c, wk = session_times(now_utc, cfg)
    return wk and o <= now_utc < c
