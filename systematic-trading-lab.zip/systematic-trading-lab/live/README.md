# live - MetaTrader 5 execution bot

Two intraday rules (see `strategies/s1_intraday_momentum.py`) traded on a prop-firm account through the native
MetaTrader5 Python API. The rules' code here is the one the research lab tested: privately, the bot's own
decision function is replayed over the full history and reproduces the backtest trade for trade.

```
bot.py       the loop: closed bars -> decisions -> orders; session close; restart-safe state; journal
strategy.py  the two rules (frame) + the order of events at each bar close (decide)
broker.py    MT5: measured server clock, closed bars, lot sizing from MT5, long/short orders, stops on the server
risk.py      the prop firm's daily and max-loss floors from the broker's own numbers; worst-case sizing; kill switch
news.py      high-impact news calendar (ForexFactory feed) for accounts with a news rule
ui.py        the terminal view for a person watching; everything else goes to logs/
tests/       the whole loop against a fake MT5, including a simulated week
```

```powershell
copy config.example.py config.py     # then fill in - the strategy values are not published
python -m pytest tests -q
python bot.py --symbols
python bot.py --check                # read-only: account, floors, sizing, today's levels
python bot.py                        # dry run: says what it would do, sends nothing
python bot.py --live
```

Safety design:
* every position has its stop on the broker's server from the moment it opens
* a trade is never sized so that every open stop plus the new one (x1.25 slippage) breaches a loss limit
* kill switch near a limit; no entries until the firm's daily reset
* never holds overnight: flat before the close; a position found from a previous day is closed at the next open
* `--live` refuses any account that isn't on the expected firm's server
