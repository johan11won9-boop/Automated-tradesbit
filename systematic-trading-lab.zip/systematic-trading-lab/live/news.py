"""
news.py — hold new entries around high-impact releases.

FTMO rule (Standard account, funded stage only): no opening or closing
trades, and no stop/target fills, from 2 minutes before to 2 minutes after
a restricted release. Swing accounts and the evaluation have no such rule.

The bot always holds NEW ENTRIES for NEWS_WINDOW_MIN either side of any
High-impact event — it costs a handful of bars a week and keeps the bot
legal on either account type. On a Standard funded account it also defers
its own max-hold exits out of the window. It cannot stop a broker-side stop
or target from filling inside one; that is the reason to buy Swing.

Source: the ForexFactory weekly calendar feed (free, no key), refreshed
every few hours and cached to disk, plus an optional news_extra.json list
of UTC timestamps you add by hand.
"""
from __future__ import annotations

import json
import logging
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional, Set, Tuple

log = logging.getLogger("news")

Event = Tuple[datetime, str, str]      # (utc time, currency, title)


def _parse_time(s: str) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        return dt
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


class News:
    def __init__(self, feed: str, cache_path: str, extra_path: str,
                 window_min: float, impacts: Set[str],
                 currencies: Optional[Set[str]], refresh_hours: float):
        self.feed = feed
        self.cache = Path(cache_path)
        self.extra = Path(extra_path)
        self.window = timedelta(minutes=window_min)
        self.impacts = {i.lower() for i in impacts}
        self.currencies = {c.upper() for c in currencies} if currencies else None
        self.refresh_every = timedelta(hours=refresh_hours)
        self.events: List[Event] = []
        self.fetched_at: Optional[datetime] = None
        self._load_cache()

    # --------------------------------------------------------------- load

    def _keep(self, row: dict) -> Optional[Event]:
        if str(row.get("impact", "")).lower() not in self.impacts:
            return None
        cur = str(row.get("country", "")).upper()
        if self.currencies is not None and cur not in self.currencies:
            return None
        t = _parse_time(row.get("date", ""))
        return (t, cur, str(row.get("title", ""))) if t else None

    def _ingest(self, rows: list) -> None:
        ev = [e for e in (self._keep(r) for r in rows) if e]
        known = {(e[0], e[2]) for e in self.events}
        self.events += [e for e in ev if (e[0], e[2]) not in known]
        cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=14)
        self.events = sorted(e for e in self.events if e[0] >= cutoff)

    def _load_cache(self) -> None:
        if self.cache.exists():
            try:
                d = json.loads(self.cache.read_text(encoding="utf-8"))
                self._ingest(d.get("rows", []))
                self.fetched_at = _parse_time(d.get("fetched_at", ""))
            except (OSError, ValueError) as exc:
                log.warning("news cache unreadable (%s)", exc)
        self._load_extra()

    def _load_extra(self) -> None:
        if not self.extra.exists():
            return
        try:
            for s in json.loads(self.extra.read_text(encoding="utf-8")):
                t = _parse_time(s)
                if t and all(t != e[0] for e in self.events):
                    self.events.append((t, "MANUAL", "news_extra.json"))
            self.events.sort()
        except (OSError, ValueError) as exc:
            log.warning("%s unreadable (%s)", self.extra, exc)

    def refresh(self, now: datetime, force: bool = False) -> None:
        if not force and self.fetched_at and now - self.fetched_at < self.refresh_every:
            return
        try:
            req = urllib.request.Request(self.feed, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                rows = json.loads(r.read().decode("utf-8"))
            self._ingest(rows)
            self.fetched_at = now
            self.cache.write_text(json.dumps({"fetched_at": now.isoformat(), "rows": rows}),
                                  encoding="utf-8")
            self._load_extra()
            log.info("news: %d high-impact events on file, next: %s",
                     len(self.events), self.next_event(now))
        except Exception as exc:
            # keep trading on the cache; back off 2h if the feed is rate-limiting us
            wait = timedelta(hours=2) if "429" in str(exc) else timedelta(minutes=30)
            self.fetched_at = now - self.refresh_every + wait
            log.warning("news feed unavailable (%s) — using %d cached events, retrying in %s",
                        exc, len(self.events), wait)

    # -------------------------------------------------------------- query

    def blocked(self, now: datetime) -> Optional[str]:
        for t, cur, title in self.events:
            if abs(now - t) <= self.window:
                return f"{cur} {title} at {t:%H:%M} UTC"
        return None

    def next_event(self, now: datetime) -> str:
        for t, cur, title in self.events:
            if t >= now:
                return f"{cur} {title} {t:%a %H:%M} UTC"
        return "none on file"
