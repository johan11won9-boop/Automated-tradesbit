"""
bot.py — intraday execution bot for FTMO / MetaTrader 5.   MT5 data -> two rules -> MT5 orders.

    python bot.py --symbols   what this terminal calls the configured instrument, then exit
    python bot.py --check     read-only health check: account, floors, sizing, today's levels
    python bot.py             DRY RUN: everything except sending orders
    python bot.py --live      trades

Every 5 minutes, a few seconds after each bar closes (New York session only):
  1  rebuild both rules from MT5's own price history (strategy.frame)
  2  NA: on a 30-minute mark, close its position if price is back inside the band/VWAP
  3  enter any new signal at market, stop attached on the server, sized to RISK_PCT of the
     initial balance (fixed) as long as every stop hit still clears FTMO's floors
And 60 seconds before the close, everything is closed: the strategy never holds overnight.

Stops live on FTMO's server from the moment of entry, so a crash, a reboot or a dropped
connection never leaves a position without one. If the bot is off at the close, close by hand.
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import logging.handlers
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import config as cfg                                        # noqa: E402
import strategy                                             # noqa: E402
from broker import Broker, utcnow                           # noqa: E402
from news import News                                       # noqa: E402
from risk import Risk, next_day_start_utc, pos_dir          # noqa: E402
from ui import say, hm, money, console_handler              # noqa: E402

log = logging.getLogger("bot")
FIVE = timedelta(minutes=5)
RULE_OF = {m: r for r, m in cfg.MAGIC.items()}
NAME = {"VB": "breakout", "NA": "noise band"}


def floor5(dt: datetime) -> datetime:
    return dt.replace(minute=dt.minute - dt.minute % 5, second=0, microsecond=0)


def setup_logging() -> None:
    Path(cfg.LOG_DIR).mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)-9s %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    fh = logging.handlers.TimedRotatingFileHandler(
        Path(cfg.LOG_DIR) / "bot.log", when="midnight", backupCount=90, encoding="utf-8")
    fh.setFormatter(fmt)
    root.handlers = [console_handler(), fh]


def keep_awake() -> None:
    """Stop Windows sleeping (and switching the screen off) while the bot runs."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x1 | 0x2)
        except Exception:
            pass


# -------------------------------------------------------------------- state

class State:
    """The little the bot must remember across restarts. Money is always re-read from FTMO."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.known: Dict[str, dict] = {}          # ticket -> entry details
        self.halt_until: Optional[str] = None
        self.login: Optional[str] = None
        self.done_bar: Optional[str] = None       # newest bar already acted on (UTC iso)
        self.last_exit: Dict[str, list] = {}      # rule -> [UTC iso of the exit, direction]
        if self.path.exists():
            try:
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self.known = d.get("known", {})
                self.halt_until = d.get("halt_until")
                self.login = d.get("login")
                self.done_bar = d.get("done_bar")
                self.last_exit = d.get("last_exit", {})
            except (OSError, ValueError) as exc:
                log.warning("state file unreadable (%s) - starting clean", exc)

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"known": self.known, "halt_until": self.halt_until,
                                   "login": self.login, "done_bar": self.done_bar,
                                   "last_exit": self.last_exit}, indent=1),
                       encoding="utf-8")
        os.replace(tmp, self.path)

    def halted(self, now: datetime) -> bool:
        return bool(self.halt_until) and now < datetime.fromisoformat(self.halt_until)


class Journal:
    FIELDS = ["time_utc", "event", "rule", "symbol", "ticket", "side", "lots", "price", "sl",
              "pnl", "r", "note"]

    def __init__(self, path: str):
        self.path = Path(path)
        if not self.path.exists():
            with self.path.open("w", newline="", encoding="utf-8") as fh:
                csv.writer(fh).writerow(self.FIELDS)

    def write(self, **row: Any) -> None:
        row.setdefault("time_utc", utcnow().strftime("%Y-%m-%d %H:%M:%S"))
        with self.path.open("a", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerow([row.get(k, "") for k in self.FIELDS])


# ---------------------------------------------------------------------- bot

class Bot:
    def __init__(self, live: bool, workdir: Optional[Path] = None):
        os.chdir(workdir or HERE)
        self.live = live
        self.broker = Broker(live, cfg.MAGIC.values(), cfg.ORDER_COMMENT, cfg.DEVIATION_BP,
                             env_path=HERE / ".env")
        self.state = State(cfg.STATE_FILE)
        self.journal = Journal(cfg.JOURNAL_FILE)
        self.news = News(cfg.NEWS_FEED, cfg.NEWS_CACHE, cfg.NEWS_EXTRA, cfg.NEWS_WINDOW_MIN,
                         cfg.NEWS_IMPACT, cfg.NEWS_CURRENCIES, cfg.NEWS_REFRESH_HOURS)
        self.sym: Optional[str] = None
        self.risk: Optional[Risk] = None
        self._said: Dict[str, str] = {}
        self._last_boundary: Optional[datetime] = None
        self._pending: Optional[datetime] = None
        self._exit_wanted: Dict[str, str] = {}     # rule -> why (deferred by a news window)
        self._last_beat = 0.0
        self._last_check = 0.0
        self._last_step: Optional[float] = None
        self._down_since: Optional[float] = None
        self._down_warned = 0.0
        self._missing: Dict[str, int] = {}
        self._flat_warned: Optional[str] = None
        self._next_flat_try = 0.0

    def say_once(self, key: str, msg: str, kind: str = "WATCH") -> None:
        if self._said.get(key) != msg:
            self._said[key] = msg
            say(kind, msg)

    # -------------------------------------------------------------- start

    def start(self) -> None:
        b = self.broker
        b.connect()
        acct, term = b.account(), b.terminal()
        if acct is None:
            raise RuntimeError("MT5 is open but not logged in to an account")
        log.info("account %s on %s (%s), balance %.2f %s, leverage 1:%s", acct.login, acct.server,
                 acct.company, acct.balance, acct.currency, acct.leverage)
        self.check_account_change(str(acct.login))
        is_ftmo = "FTMO" in f"{acct.server} {acct.company}".upper()
        if self.live and cfg.REQUIRE_FTMO_SERVER and not is_ftmo:
            raise RuntimeError(f"refusing to trade: {acct.server} is not an FTMO server. Log MT5 into "
                               "the FTMO account (or set REQUIRE_FTMO_SERVER = False if you mean it).")
        if self.live and term is not None and not term.trade_allowed:
            log.error("the 'Algo Trading' button in MT5 is OFF - orders will be refused until it's on")
        found = b.resolve({"main": [cfg.SYMBOL]}).get("main") or []
        if not found:
            raise RuntimeError(f"{cfg.SYMBOL} is not offered on this account - run  python bot.py --symbols")
        self.sym = found[0]
        b.refresh_offset([self.sym], force=True)
        initial = cfg.INITIAL_BALANCE or b.initial_deposit()
        if not initial:
            initial = float(acct.balance)
            log.warning("could not find the initial deposit - using the current balance %.2f. "
                        "Set INITIAL_BALANCE in config.py to be exact.", initial)
        self.risk = Risk(cfg, b, initial)
        self.news.refresh(utcnow())
        self.sync_positions(utcnow())

    def check_account_change(self, login: str) -> None:
        """A new free trial, challenge or funded account is a new MT5 login: file the old account's
        state and journal away and start clean."""
        old = self.state.login
        if old and old != login:
            stamp = utcnow().strftime("%Y%m%d-%H%M")
            for f, name in ((self.state.path, f"state_{old}_{stamp}.json"),
                            (self.journal.path, f"trades_{old}_{stamp}.csv")):
                if f.exists():
                    f.rename(f.with_name(name))
            log.warning("MT5 is now on account %s; account %s's files were saved with its number "
                        "- starting clean", login, old)
            self.state = State(cfg.STATE_FILE)
            self.journal = Journal(cfg.JOURNAL_FILE)
        if self.state.login != login:
            self.state.login = login
            self.state.save()

    def say_start(self) -> None:
        acct = self.broker.account()
        now = utcnow()
        fl = self.risk.floors(acct, now)
        o, c, _ = strategy.session_times(now, cfg)
        init = self.risk.initial
        say("START", f"account {acct.login} ({acct.server}) - {'LIVE' if self.live else 'DRY RUN, no orders'}"
                     f" - {cfg.ACCOUNT_TYPE} {cfg.PHASE} - {self.sym}")
        say("START", f"balance {acct.balance:,.2f} - equity {acct.equity:,.2f} - started at {init:,.0f}"
                     f" ({(acct.equity / init - 1) * 100:+.2f}%)")
        say("START", f"risk {cfg.RISK_PCT:.2%} = {cfg.RISK_PCT * init:,.0f} per trade (fixed) - "
                     f"loss limits: today {fl.daily_floor:,.0f}, overall {fl.max_loss_floor:,.0f}")
        say("START", f"session {hm(o)}-{hm(c)} your time, Mon-Fri - everything closes {cfg.FLAT_BEFORE_CLOSE_SEC}s "
                     f"before the close - no new trades in the last {cfg.ENTRY_CUTOFF_MIN} min")
        if cfg.news_rule_applies():
            say("START", f"news rule ON (Standard funded): next {self.news.next_event(now)}")
        if cfg.ACCOUNT_TYPE == "swing":
            say("WARN", "Swing account: single stocks are 1:1 leverage here, so many trades will be cut to "
                        "fit the margin. Buy the real challenge as Standard.")

    # ---------------------------------------------------------- positions

    def rule_of(self, p) -> str:
        return RULE_OF.get(int(p.magic), "?")

    def open_dir(self, positions: List[Any]) -> Dict[str, int]:
        return {self.rule_of(p): pos_dir(p) for p in positions}

    def sync_positions(self, now: datetime) -> List[Any]:
        """Notice exits (stop, close, by hand, or while the bot was off) and adopt positions
        opened by an earlier run."""
        positions = self.broker.positions()
        live = {str(p.ticket) for p in positions}
        changed = False
        for tk, info in list(self.state.known.items()):
            if tk in live:
                continue
            deals = self.broker.deals_for_position(int(tk))
            out = [d for d in deals if int(d.entry) in (1, 3)]
            if not out:
                n = self._missing.get(tk, 0) + 1
                self._missing[tk] = n
                if n < 12:
                    continue
                say("WARN", f"{info['rule']} #{tk}: no closing deal found - check MT5's History tab")
            self._missing.pop(tk, None)
            pnl = sum(float(d.profit) + float(getattr(d, "commission", 0)) + float(getattr(d, "swap", 0))
                      + float(getattr(d, "fee", 0)) for d in deals)
            when = self.broker.to_utc(max(d.time for d in out)) if out else now
            price = float(out[-1].price) if out else ""
            why = (out[-1].comment if out else "") or "closed"
            r = pnl / info["risk"] if info.get("risk") else ""
            self.state.last_exit[info["rule"]] = [when.isoformat(), 1 if info.get("side") == "long" else -1]
            self.journal.write(time_utc=when.strftime("%Y-%m-%d %H:%M:%S"), event="exit", rule=info["rule"],
                               symbol=info.get("symbol"), ticket=tk, side=info.get("side"), lots=info.get("lots"),
                               price=price, pnl=round(pnl, 2), r=round(r, 3) if r != "" else "", note=why)
            log.info("EXIT  %s #%s  %s  pnl %+.2f", info["rule"], tk, why, pnl)
            self.say_exit(tk, info, why, price, pnl, when)
            del self.state.known[tk]
            changed = True
        for p in positions:
            if str(p.ticket) not in self.state.known:
                self.state.known[str(p.ticket)] = {
                    "rule": self.rule_of(p), "symbol": p.symbol, "side": "long" if pos_dir(p) > 0 else "short",
                    "lots": p.volume, "price": p.price_open, "opened": self.broker.to_utc(p.time).isoformat(),
                    "sl": float(p.sl or 0)}
                changed = True
                say("CHECK", f"{self.rule_of(p)} #{p.ticket} picked up: {'long' if pos_dir(p) > 0 else 'short'} "
                             f"since {hm(self.broker.to_utc(p.time))} @ {p.price_open:g}")
        if changed:
            self.state.save()
        return positions

    @staticmethod
    def exit_kind(comment: str) -> str:
        c = (comment or "").lower()
        if c.startswith("[sl"):
            return "STOP hit"
        if "close" in c:
            return "SESSION CLOSE"
        if "exit" in c:
            return "BAND EXIT"
        if "kill" in c:
            return "KILL SWITCH"
        if c.startswith("[so") or "stop out" in c:
            return "FTMO STOP-OUT"
        return "CLOSED (by hand or other)"

    def say_exit(self, tk: str, info: dict, comment: str, price, pnl: float, when: datetime) -> None:
        kind = self.exit_kind(comment)
        opened = datetime.fromisoformat(info["opened"]) if info.get("opened") else None
        parts = [f"{info['rule']} {NAME.get(info['rule'], '')} {info.get('side', '')}", kind]
        if opened:
            parts.append(f"in {hm(opened)} -> out {hm(when)}")
        if price != "" and info.get("price"):
            parts.append(f"{float(info['price']):g} -> {float(price):g}")
        r = f" ({pnl / info['risk']:+.2f}R)" if info.get("risk") else ""
        parts.append(f"{money(pnl)}{r}")
        say("EXIT", "  ".join(parts))

    def flatten(self, positions: List[Any], reason: str) -> None:
        for p in positions:
            if self.broker.close(p, reason):
                log.warning("closed %s #%s (%s)", self.rule_of(p), p.ticket, reason)

    # -------------------------------------------------------------- entries

    def try_enter(self, rule: str, d: int, sd: float, row: dict, now: datetime, acct,
                  positions: List[Any]) -> bool:
        bar = row["time"]
        side = "long" if d > 0 else "short"
        tag = f"{rule} {side} on the {hm(bar.to_pydatetime() + FIVE)} bar"

        def skip(why: str) -> bool:
            log.info("SIGNAL %s - skipped: %s", tag, why)
            say("SKIP", f"{tag} - {why}")
            self.journal.write(event="skip", rule=rule, symbol=self.sym, side=side, note=why)
            return False

        if self.state.halted(now):
            return skip(f"halted until {self.state.halt_until} (kill switch)")
        age = (now - (bar.to_pydatetime() + FIVE)).total_seconds()
        if age > cfg.MAX_SIGNAL_AGE_SECONDS:
            return skip(f"signal is {age:.0f}s old")
        if cfg.news_rule_applies():
            hit = self.news.blocked(now)
            if hit:
                return skip(f"news window: {hit}")
        spr = self.broker.spread_bp(self.sym)
        if spr is None or spr > cfg.MAX_ENTRY_SPREAD_BP:
            return skip(f"spread {spr if spr is not None else float('nan'):.1f}bp over {cfg.MAX_ENTRY_SPREAD_BP:.0f}bp")
        fl = self.risk.floors(acct, now)
        t = self.broker.tick(self.sym)
        px = float(t.ask) if d > 0 else float(t.bid)
        per_lot = self.broker.loss_per_lot(self.sym, d, px, px - d * sd)
        cash = self.risk.risk_cash(acct, fl, positions)
        if not per_lot or cash <= 0:
            return skip("no room above FTMO's loss limits" if cash <= 0 else "no contract data from MT5")
        lots = self.broker.round_lots(self.sym, cash / per_lot)
        if lots <= 0:
            return skip(f"{cash:,.0f} of risk is below the minimum lot")
        m = self.broker.margin(self.sym, d, lots, px)
        free = float(acct.margin_free)
        if m and m > cfg.MARGIN_USE_MAX * free:
            lots = self.broker.round_lots(self.sym, lots * cfg.MARGIN_USE_MAX * free / m)
            if lots <= 0:
                return skip(f"not enough free margin ({free:,.0f})")
            say("WARN", f"{rule}: cut to {lots:g} lots to fit the margin ({cfg.ACCOUNT_TYPE} leverage)")
        risk_amt = lots * per_lot
        ok, why = self.risk.can_open(risk_amt, acct, positions, fl)
        if not ok:
            return skip(why)
        if cash < cfg.RISK_PCT * self.risk.initial - 1:
            say("WARN", f"{rule}: risk cut to {cash:,.0f} so a stop can't breach FTMO's {fl.binding} limit")

        log.info("SIGNAL %s - %s %.2f lots, risk %.0f, stop distance %.4f", tag, side, lots, risk_amt, sd)
        res = self.broker.open(self.sym, d, lots, sd, cfg.MAGIC[rule], rule)
        if res.dry:
            say("DRY", f"{tag}: would {'BUY' if d > 0 else 'SELL'} {lots:g} lots @ {res.price:g}, stop "
                       f"{res.price - d * sd:.2f}, risk {money(-risk_amt)}")
            self.journal.write(event="dry-entry", rule=rule, symbol=self.sym, side=side, lots=lots,
                               price=res.price, sl=round(res.price - d * sd, 4), note=f"risk {risk_amt:.0f}")
            return False
        if not res.ok:
            log.error("%s: order refused by FTMO - %s %s (nothing opened)", rule, res.retcode, res.comment)
            self.journal.write(event="refused", rule=rule, symbol=self.sym, side=side, lots=lots,
                               note=f"{res.retcode} {res.comment}")
            return False
        sl = res.price - d * sd
        slip = d * (res.price - float(row["close"])) / float(row["close"]) * 100
        say("ENTRY", f"{rule} {NAME[rule]}  {'BUY' if d > 0 else 'SELL'} {lots:g} lots @ {res.price:g} "
                     f"(signal {float(row['close']):g}, {slip:+.3f}% against)  stop {sl:.2f}  risk {money(-risk_amt)}")
        pos = self.broker.position(res.ticket)
        if pos is not None and not pos.sl:
            say("ERROR", f"{rule} #{res.ticket} has NO stop on FTMO - set it by hand in MT5 now ({sl:.2f})")
        else:
            say("CONF", f"#{res.ticket} confirmed by FTMO: the stop is on the server")
        self.journal.write(event="entry", rule=rule, symbol=self.sym, ticket=res.ticket, side=side, lots=lots,
                           price=res.price, sl=round(sl, 4), note=f"risk {risk_amt:.0f} sd {sd:.4f}")
        self.state.known[str(res.ticket)] = {"rule": rule, "symbol": self.sym, "side": side, "lots": lots,
                                             "price": res.price, "opened": now.isoformat(),
                                             "risk": round(risk_amt, 2), "sl": round(sl, 4),
                                             "signal": float(row["close"])}
        self.state.save()
        return True

    # ---------------------------------------------------------------- bar

    def on_bar(self, boundary: datetime, now: datetime, acct, positions: List[Any]) -> Optional[bool]:
        """None = bar not in yet, try again; False = done; True = something was traded."""
        expected = pd.Timestamp(boundary - FIVE)
        if self.state.done_bar == expected.isoformat():
            return False
        df = self.broker.bars(self.sym, cfg.SIGNAL_BARS)
        fresh = not df.empty and df.index[-1] >= expected
        if not fresh and (now - boundary).total_seconds() < cfg.BAR_WAIT_SECONDS:
            return None
        if not fresh:
            o_utc, _, _ = strategy.session_times(expected.to_pydatetime(), cfg)
            if expected.to_pydatetime() > o_utc:          # FTMO has no 09:30 bar: its first is 09:35
                say("WARN", f"the {hm(boundary)} bar never arrived from MT5 - skipped")
            return False
        fr = strategy.frame(df, cfg)
        row = strategy.latest(fr)
        if row is None or row["time"] != expected or not row["in_sess"]:
            return False
        self.state.done_bar = expected.isoformat()
        self.state.save()
        if row["sessions_before"] < cfg.MIN_SESSIONS:
            self.say_once("hist", f"only {row['sessions_before']:.0f} sessions of {self.sym} history in MT5 - "
                                  f"need {cfg.MIN_SESSIONS}. Open the {self.sym} M5 chart and scroll back.", "WARN")
            return False
        acted = False
        at_close = self.open_dir(positions)
        bar_end = expected.to_pydatetime() + FIVE
        for rule, (iso, d) in self.state.last_exit.items():
            if rule not in at_close and datetime.fromisoformat(iso) >= bar_end:
                at_close[rule] = d          # it closed AFTER this bar ended: in the backtest it was still open
        for a in strategy.decide(row, at_close):
            if a[0] == "exit":
                self._exit_wanted[a[1]] = "exit"
                acted |= self.do_exits(positions, now)
            else:
                acted |= self.try_enter(a[1], a[2], a[3], row, now, acct, positions)
                if acted:
                    acct = self.broker.account()
                    positions = self.sync_positions(now)
        return acted

    def do_exits(self, positions: List[Any], now: datetime) -> bool:
        """NA band exits, at market. On a Standard funded account they wait out a news window."""
        did = False
        for rule, why in list(self._exit_wanted.items()):
            mine = [p for p in positions if self.rule_of(p) == rule]
            if not mine:
                self._exit_wanted.pop(rule)
                continue
            if cfg.news_rule_applies():
                hit = self.news.blocked(now)
                if hit:
                    self.say_once(f"news-exit-{rule}", f"{rule} exit waiting for the news window ({hit})")
                    continue
            for p in mine:
                if self.broker.close(p, why):
                    did = True
            if did or not self.live:
                self._exit_wanted.pop(rule)
        return did

    # --------------------------------------------------------------- loop

    def run(self) -> None:
        keep_awake()
        self.start()
        self.say_start()
        while True:
            try:
                self.step()
            except KeyboardInterrupt:
                raise
            except Exception:
                log.exception("loop error - carrying on")
                time.sleep(10)
            time.sleep(cfg.LOOP_SECONDS)

    def step(self) -> None:
        now = utcnow()
        t = time.time()
        if self._last_step is not None and t - self._last_step > 120:
            log.warning("the bot did not run for %.0f min - the PC was asleep or the window was paused by "
                        "a click in it (stops on the server still work)", (t - self._last_step) / 60)
        self._last_step = t
        if not self.broker.ensure():
            if self._down_since is None:
                self._down_since = t
                say("MT5", "connection to MT5 lost - reconnecting")
            down = (t - self._down_since) / 60
            if down >= 10 and t - self._down_warned >= 600:
                self._down_warned = t
                log.error("MT5 has been disconnected for %.0f min - no trades until it's back", down)
            time.sleep(10)
            return
        if self._down_since is not None:
            say("MT5", f"MT5 back after {(t - self._down_since) / 60:.0f} min")
            self._down_since = None
        self.broker.refresh_offset([self.sym])
        self.news.refresh(now)
        acct = self.broker.account()
        positions = self.sync_positions(now)
        fl = self.risk.floors(acct, now)

        if positions and self.risk.kill(acct, fl):
            say("KILL", f"equity {acct.equity:,.2f} is within {cfg.KILL_PCT:.1%} of the {fl.binding} limit "
                        f"{fl.floor:,.0f} - closing everything, no entries until FTMO's daily reset")
            self.flatten(positions, "kill")
            self.state.halt_until = next_day_start_utc(now, cfg.DAY_RESET_TZ).isoformat()
            self.state.save()
            self.journal.write(event="kill", note=f"equity {acct.equity:.2f}")
            positions = self.sync_positions(now)

        # flat before the close; and never carry anything into a new session
        o_utc, c_utc, wk = strategy.session_times(now, cfg)
        flat_at = c_utc - timedelta(seconds=cfg.FLAT_BEFORE_CLOSE_SEC)
        if positions and time.time() >= self._next_flat_try:
            if wk and flat_at <= now < c_utc + timedelta(minutes=30):
                if now >= c_utc:
                    self._next_flat_try = time.time() + 120           # market shut: don't hammer MT5
                self.flatten(positions, "close")
                positions = self.sync_positions(now)
                if positions and now >= c_utc and self._flat_warned != str(now.date()):
                    self._flat_warned = str(now.date())
                    say("ERROR", f"{len(positions)} position(s) still open after the close - the market is "
                                 f"shut; the bot will close them at the next open. Check MT5.")
            elif not (wk and o_utc <= now < flat_at):
                key = f"overnight-{now:%Y%m%d}"
                if self._said.get("overnight") != key:
                    self._said["overnight"] = key
                    say("WARN", "position(s) open outside the session (the bot was off at the close?) - "
                                "closing at the first chance")
                self._next_flat_try = time.time() + 300
                self.flatten(positions, "close")
                positions = self.sync_positions(now)
            elif wk and o_utc <= now and any(
                    datetime.fromisoformat(i["opened"]) < o_utc for i in self.state.known.values()
                    if i.get("opened")):
                self.flatten(positions, "close")                 # held overnight by accident
                positions = self.sync_positions(now)

        if self._exit_wanted:
            self.do_exits(positions, now)
            positions = self.sync_positions(now)

        boundary = floor5(now)
        if boundary != self._last_boundary and (now - boundary).total_seconds() >= cfg.BAR_DELAY_SECONDS:
            self._last_boundary = boundary
            if strategy.in_session(boundary - FIVE, cfg):
                self._pending = boundary
        if self._pending is not None:
            r = self.on_bar(self._pending, now, acct, positions)
            if r is not None:
                self._pending = None
                if r:
                    acct = self.broker.account()
                    positions = self.sync_positions(now)

        if time.time() - self._last_beat > 900:
            self._last_beat = time.time()
            log.info("%s | next news: %s", self.risk.status(acct, fl, positions), self.news.next_event(now))
        if time.time() - self._last_check > (900 if positions else 3600):
            self._last_check = time.time()
            self.say_check(acct, fl, positions, now)

    def say_check(self, acct, fl, positions: List[Any], now: datetime) -> None:
        today = float(acct.equity) - fl.day_start_balance
        init = self.risk.initial
        acc = (f"equity {acct.equity:,.2f} ({(acct.equity / init - 1) * 100:+.2f}% overall, today {money(today)})"
               f" - room: today {acct.equity - fl.daily_floor:,.0f}, overall {acct.equity - fl.max_loss_floor:,.0f}")
        if not positions:
            say("WATCH", f"no open trades - {'in session' if strategy.in_session(now, cfg) else 'market closed'} - {acc}")
            return
        say("CHECK", acc)
        for p in positions:
            info = self.state.known.get(str(p.ticket), {})
            risk = info.get("risk") or abs(self.broker.pnl_at(p.symbol, pos_dir(p), p.volume, p.price_open,
                                                               p.sl or p.price_open))
            say("CHECK", f"{self.rule_of(p)} {'long' if pos_dir(p) > 0 else 'short'} @ {p.price_open:g} - "
                         f"{money(float(p.profit))} ({float(p.profit) / risk:+.2f}R) - stop {float(p.sl or 0):g}")

    # -------------------------------------------------------------- tools

    def check(self) -> None:
        self.start()
        now = utcnow()
        acct = self.broker.account()
        positions = self.broker.positions()
        fl = self.risk.floors(acct, now)
        info = self.broker.info(self.sym)
        t = self.broker.tick(self.sym)
        print(f"\nACCOUNT  {acct.login} {acct.server}  balance {acct.balance:,.2f}  equity {acct.equity:,.2f}  "
              f"initial {self.risk.initial:,.0f}  ({cfg.ACCOUNT_TYPE}, {cfg.PHASE})")
        print(f"FLOORS   max-loss {fl.max_loss_floor:,.0f}   daily {fl.daily_floor:,.0f} "
              f"(midnight balance {fl.day_start_balance:,.0f})")
        cash = self.risk.risk_cash(acct, fl, positions)
        print(f"RISK     {cfg.RISK_PCT:.2%} = {cfg.RISK_PCT * self.risk.initial:,.0f} per trade; fits now: {cash:,.0f}; "
              f"{len(positions)} bot positions")
        o, c, wk = strategy.session_times(now, cfg)
        print(f"SESSION  {o:%H:%M}-{c:%H:%M} UTC today ({'trading day' if wk else 'weekend'}), "
              f"{'OPEN' if strategy.in_session(now, cfg) else 'closed'}; server clock UTC{self.broker.offset_s / 3600:+.0f}h")
        if info is not None and t is not None and t.ask:
            spr = (t.ask - t.bid) / t.ask * 1e4
            print(f"{self.sym:<8} bid {t.bid:g} ask {t.ask:g} spread {spr:.1f}bp  contract {info.trade_contract_size:g}  "
                  f"lots min {info.volume_min:g} step {info.volume_step:g}")
            for d in (1, -1):
                pl = self.broker.loss_per_lot(self.sym, d, t.ask, t.ask * (1 - d * 0.016))
                if pl:
                    lots = self.broker.round_lots(self.sym, cash / pl)
                    m = self.broker.margin(self.sym, d, lots, t.ask) if lots else None
                    print(f"         a typical {'long' if d > 0 else 'short'} (1.6% stop): {lots:g} lots, margin "
                          f"{m:,.0f} of {acct.margin_free:,.0f} free" if m else "")
        df = self.broker.bars(self.sym, cfg.SIGNAL_BARS)
        fr = strategy.frame(df, cfg)
        if fr.empty:
            print("BARS     none - open the M5 chart in MT5 and scroll back")
            return
        today = fr[fr["in_sess"]]
        print(f"BARS     {len(df)} M5 bars, {int(fr['sessions_before'].max() + 1)} sessions, newest {df.index[-1]} UTC")
        if len(today):
            r = today.iloc[-1]
            k = cfg.VB["k"]
            print(f"LEVELS   day open {r['open_s']:g}  prev range {r['prev_range']:.2f}  -> breakout above "
                  f"{r['open_s'] + k * r['prev_range']:.2f} / below {r['open_s'] - k * r['prev_range']:.2f}")
            if r["na_check"]:
                print(f"         noise band at the last 30-min mark: {r['na_lb']:.2f} - {r['na_ub']:.2f}, VWAP {r['vwap']:.2f}")
        print(f"NEWS     next: {self.news.next_event(now)} (rule {'ON' if cfg.news_rule_applies() else 'off'})")

    def symbols(self) -> None:
        b = self.broker
        b.connect()
        names = sorted(s.name for s in (b.mt5.symbols_get() or []))
        hits = [n for n in names if cfg.SYMBOL.upper() in n.upper()]
        print(f"{len(names)} symbols on this account; matches: {', '.join(hits) or 'NOT FOUND'}; "
              f"config uses {cfg.SYMBOL} ({'OK' if cfg.SYMBOL in names else 'MISSING - edit config.SYMBOL'})")


def main() -> None:
    ap = argparse.ArgumentParser(description="Intraday bot for FTMO / MT5")
    ap.add_argument("--live", action="store_true", help="send real orders")
    ap.add_argument("--check", action="store_true", help="read-only health check")
    ap.add_argument("--symbols", action="store_true", help="show the instrument's symbol name and exit")
    a = ap.parse_args()
    setup_logging()
    bot = Bot(live=a.live)
    try:
        if a.symbols:
            bot.symbols()
        elif a.check:
            bot.check()
        else:
            if a.live:
                print("LIVE - orders will be sent. Ctrl+C in the next 5 seconds to stop.")
                time.sleep(5)
            bot.run()
    except KeyboardInterrupt:
        say("BYE", "stopped by hand - open trades keep their stops on FTMO; close them yourself before "
                   "the close if the bot stays off")
    finally:
        bot.broker.shutdown()


if __name__ == "__main__":
    main()
