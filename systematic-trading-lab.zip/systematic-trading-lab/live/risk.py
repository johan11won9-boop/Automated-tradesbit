"""
risk.py — FTMO's two floors, and sizing against them.

Everything is computed from the broker's own numbers (equity, balance, open positions,
today's deals) every loop. Nothing is kept in a private ledger, so a restart, a manual trade
or a stop filled while the bot was off can't leave the guard believing something the account
doesn't.

  MAX LOSS   equity must stay above initial x 0.90, forever (static)
  DAILY      equity must stay above (balance at midnight Prague) - initial x 0.05

Risk per trade is FIXED (config.RISK_PCT of the initial balance) - it does not shrink after
losses. The one exception: a trade is never bigger than what still fits above the higher
floor with every open stop and the new one hit at 1.25x slippage, plus a safety margin.
So a normal stop can never breach the account; only a gap through the stop could.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, List, Optional, Tuple

import pandas as pd

log = logging.getLogger("risk")


@dataclass
class Floors:
    initial: float
    max_loss_floor: float
    day_start_balance: float
    daily_floor: float

    @property
    def floor(self) -> float:
        return max(self.max_loss_floor, self.daily_floor)

    @property
    def binding(self) -> str:
        return "daily" if self.daily_floor >= self.max_loss_floor else "max-loss"


def day_start_utc(now_utc: datetime, tz: str) -> datetime:
    """Midnight in the reset time zone, expressed in naive UTC."""
    local = pd.Timestamp(now_utc, tz="UTC").tz_convert(tz)
    mid = pd.Timestamp(local.date()).tz_localize(tz)
    return mid.tz_convert("UTC").tz_localize(None).to_pydatetime()


def next_day_start_utc(now_utc: datetime, tz: str) -> datetime:
    local = pd.Timestamp(now_utc, tz="UTC").tz_convert(tz)
    mid = pd.Timestamp(local.date() + timedelta(days=1)).tz_localize(tz)
    return mid.tz_convert("UTC").tz_localize(None).to_pydatetime()


def pos_dir(p) -> int:
    return 1 if int(getattr(p, "type", 0)) == 0 else -1


class Risk:
    def __init__(self, cfg, broker, initial: float):
        self.cfg = cfg
        self.broker = broker
        self.initial = float(initial)
        self._day_key: Optional[str] = None
        self._day_balance: Optional[float] = None

    # ------------------------------------------------------------ floors

    def day_start_balance(self, now_utc: datetime, balance: float) -> float:
        """Balance at the last Prague midnight = balance now minus every deal amount booked
        since then. Recomputed once a minute."""
        start = day_start_utc(now_utc, self.cfg.DAY_RESET_TZ)
        key = f"{start:%Y-%m-%d}|{now_utc:%H:%M}"
        if key == self._day_key and self._day_balance is not None:
            return self._day_balance
        moved = 0.0
        for d in self.broker.deals_between(start, now_utc + timedelta(minutes=1)):
            if int(getattr(d, "type", 0)) not in (0, 1):    # deposits, payouts, credit: not trading
                continue
            moved += float(d.profit) + float(getattr(d, "commission", 0.0)) \
                + float(getattr(d, "swap", 0.0)) + float(getattr(d, "fee", 0.0))
        dsb = float(balance) - moved
        self._day_key, self._day_balance = key, dsb if dsb > 0 else float(balance)
        return self._day_balance

    def floors(self, acct, now_utc: datetime) -> Floors:
        dsb = self.day_start_balance(now_utc, float(acct.balance))
        return Floors(
            initial=self.initial,
            max_loss_floor=self.initial * (1 - self.cfg.MAX_LOSS_PCT),
            day_start_balance=dsb,
            daily_floor=dsb - self.initial * self.cfg.DAILY_LOSS_PCT)

    # -------------------------------------------------------------- risk

    def position_drop(self, p) -> float:
        """How much equity falls if this position goes from here to its stop."""
        d = pos_dir(p)
        # no stop on the server (shouldn't happen - can_open refuses new trades then): count a 3% move
        sl = float(p.sl) if p.sl else float(p.price_open) * (1 - d * 0.03)
        at_stop = self.broker.pnl_at(p.symbol, d, p.volume, p.price_open, sl)
        return max(0.0, float(p.profit) - at_stop)

    def open_risk(self, positions: List[Any]) -> float:
        return sum(self.position_drop(p) for p in positions) * self.cfg.SLIPPAGE_BUFFER

    def room(self, acct, fl: Floors, positions: List[Any]) -> float:
        """Cash a NEW trade may risk so that every stop hit (x1.25) still clears the floor + safety."""
        free = float(acct.equity) - self.open_risk(positions) \
            - (fl.floor + self.cfg.SAFETY_PCT * self.initial)
        return max(0.0, free / self.cfg.SLIPPAGE_BUFFER)

    def risk_cash(self, acct, fl: Floors, positions: List[Any]) -> float:
        """The fixed risk (RISK_PCT of the initial balance), or less only if that would not fit."""
        return min(self.cfg.RISK_PCT * self.initial, self.room(acct, fl, positions))

    def can_open(self, new_risk: float, acct, positions: List[Any],
                 fl: Floors) -> Tuple[bool, str]:
        if any(not p.sl for p in positions):
            return False, "an open position has no stop on the server - fix it in MT5 first"
        worst = float(acct.equity) - self.open_risk(positions) \
            - new_risk * self.cfg.SLIPPAGE_BUFFER
        need = fl.floor + self.cfg.SAFETY_PCT * self.initial
        if worst < need - 1e-6:
            return False, (f"worst case {worst:,.0f} would sit under the {fl.binding} "
                           f"floor {fl.floor:,.0f} + safety")
        return True, "ok"

    def kill(self, acct, fl: Floors) -> bool:
        return float(acct.equity) <= fl.floor + self.cfg.KILL_PCT * self.initial

    def status(self, acct, fl: Floors, positions: List[Any]) -> str:
        return (f"equity {acct.equity:,.2f}  balance {acct.balance:,.2f}  "
                f"daily floor {fl.daily_floor:,.0f}  max-loss floor {fl.max_loss_floor:,.0f}  "
                f"open risk {self.open_risk(positions):,.0f}  positions {len(positions)}")
