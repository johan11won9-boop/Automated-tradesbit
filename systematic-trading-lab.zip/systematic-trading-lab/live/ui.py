"""
ui.py — what the terminal shows.

The terminal is for a person watching: entries, exits (with FTMO's
confirmation), skipped signals, a check on open trades every 15 minutes,
and anything that needs action. Everything else (news refreshes, clock
checks, reconnect attempts) goes only to logs/bot.log, which still keeps
the full record.

    say("ENTRY", "...")   prints  "14:35:10  ENTRY  ..."  and writes it to bot.log
"""
from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone

_ui = logging.getLogger("ui")

# ANSI colours for the tag only; text stays in the normal colour.
_COLOUR = {"ENTRY": "32", "EXIT": "36", "CONF": "32",
           "SKIP": "90", "CHECK": "37", "WATCH": "90", "MT5": "33", "WARN": "33",
           "ERROR": "31;1", "KILL": "31;1", "START": "36", "BOOK": "36", "HOLD": "33",
           "BYE": "36"}


def say(kind: str, text: str) -> None:
    """One line for the person watching. Multi-line text is indented."""
    _ui.info("%-5s  %s", kind, text, extra={"kind": kind})


def local(dt_utc: datetime) -> datetime:
    """A naive UTC datetime -> this PC's local time (the clock the user reads)."""
    if dt_utc.tzinfo is None:
        dt_utc = dt_utc.replace(tzinfo=timezone.utc)
    return dt_utc.astimezone()


def hm(dt_utc: datetime) -> str:
    return local(dt_utc).strftime("%H:%M")


def money(x: float) -> str:
    return f"{'+' if x >= 0 else '-'}${abs(x):,.0f}"


class ConsoleFilter(logging.Filter):
    """Show ui lines, plus warnings/errors from the rest of the bot that are
    not marked quiet (reconnect retries are marked quiet: one ui line covers them)."""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.name == "ui":
            return True
        return record.levelno >= logging.WARNING and not getattr(record, "quiet", False)


class ConsoleFormatter(logging.Formatter):
    def __init__(self, colour: bool):
        super().__init__()
        self.colour = colour

    def format(self, record: logging.LogRecord) -> str:
        t = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        kind = getattr(record, "kind", None)
        if kind is None:
            kind = "ERROR" if record.levelno >= logging.ERROR else "WARN"
            body = record.getMessage()
            if record.exc_info:
                body += "\n" + self.formatException(record.exc_info)
        else:
            body = record.getMessage()[7:]               # drop the padded kind
        lines = body.split("\n")
        tag = f"{kind:<5}"
        if self.colour and kind in _COLOUR:
            tag = f"\x1b[{_COLOUR[kind]}m{tag}\x1b[0m"
        out = f"{t}  {tag}  {lines[0]}"
        for extra in lines[1:]:
            out += "\n" + " " * 17 + extra
        return out


def console_handler() -> logging.Handler:
    colour = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
    if colour and os.name == "nt":
        os.system("")                                   # turns on ANSI colours in Windows consoles
    h = logging.StreamHandler(sys.stdout)
    h.addFilter(ConsoleFilter())
    h.setFormatter(ConsoleFormatter(colour))
    return h
