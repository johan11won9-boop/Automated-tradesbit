"""
broker.py — everything that talks to MetaTrader 5.

Data in:   copy_rates_from_pos  -> closed 5-minute bars, stamped in UTC
Orders out: order_send          -> market buy OR sell with the stop attached (no target)

Three things here are easy to get wrong and all of them cost money:

  SERVER TIME. MT5 stamps bars and deals in the broker's clock, not UTC,
  and that clock moves an hour twice a year. The offset is measured from the
  freshest tick every few minutes, never hard-coded.

  CLOSED BARS. The newest bar MT5 returns can still be forming, and on a
  quiet symbol the newest bar can already be closed. A bar counts as closed
  by the clock (open + 5 min has passed), not by its position in the array.

  LOT SIZE. Contract sizes differ by symbol and the P&L may be in a
  different currency to the account. Sizing asks MT5 itself what one lot
  loses at the stop (order_calc_profit) instead of doing the arithmetic.

live=False never sends an order. Everything else (data, account, positions)
is read for real, so a dry run shows exactly what live would do.
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

log = logging.getLogger("broker")

FIVE_MIN = timedelta(minutes=5)
RETRY_CODES = {10004, 10020, 10021, 10024, 10031}   # requote, price changed/off, too many, no connection


def epoch_now() -> float:
    return time.time()


def utcnow() -> datetime:
    return datetime(1970, 1, 1) + timedelta(seconds=epoch_now())


def load_env(path: Path) -> Dict[str, str]:
    """Tiny .env reader so there is no extra dependency."""
    out: Dict[str, str] = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def ny_rule_offset(now: datetime) -> int:
    """Fallback server offset in seconds: most MT5 servers (FTMO included)
    run on New York time + 7h, so midnight on the server = 17:00 in New York."""
    ny = pd.Timestamp(now, tz="UTC").tz_convert("America/New_York")
    return int(ny.utcoffset().total_seconds()) + 7 * 3600


@dataclass
class OrderResult:
    ok: bool
    ticket: Optional[int] = None
    price: float = float("nan")
    retcode: Optional[int] = None
    comment: str = ""
    dry: bool = False


class Broker:
    def __init__(self, live: bool, magics, comment: str,
                 deviation_bp: float = 5.0, env_path: Optional[Path] = None):
        self.live = live
        self.magics = set(int(m) for m in magics)
        self.comment = comment
        self.deviation_bp = deviation_bp
        self.env_path = env_path
        self.mt5 = None
        self.offset_s: Optional[int] = None      # server clock minus UTC
        self._offset_checked = 0.0
        self._cand: Optional[int] = None
        self._cand_hits = 0

    # ------------------------------------------------------------ connect

    def connect(self) -> None:
        import MetaTrader5 as mt5                 # Windows only
        env = load_env(self.env_path) if self.env_path else {}
        kw: Dict[str, Any] = {}
        if env.get("MT5_PATH"):
            kw["path"] = env["MT5_PATH"]
        if env.get("MT5_LOGIN"):
            kw["login"] = int(env["MT5_LOGIN"])
            kw["password"] = env.get("MT5_PASSWORD", "")
            kw["server"] = env.get("MT5_SERVER", "")
        if not mt5.initialize(**kw):
            raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}. "
                               "Is the terminal open and logged in?")
        self.mt5 = mt5

    def ensure(self) -> bool:
        """True if the terminal is up and connected; reconnects if not."""
        try:
            ti = self.mt5.terminal_info() if self.mt5 else None
            if ti is not None and ti.connected:
                return True
            log.warning("MT5 not connected — reconnecting", extra={"quiet": True})
            if self.mt5:
                self.mt5.shutdown()
            self.connect()
            ti = self.mt5.terminal_info()
            return ti is not None and ti.connected
        except Exception as exc:
            log.warning("reconnect failed: %s", exc, extra={"quiet": True})
            return False

    def shutdown(self) -> None:
        if self.mt5:
            self.mt5.shutdown()

    def account(self):
        return self.mt5.account_info()

    def terminal(self):
        return self.mt5.terminal_info()

    # --------------------------------------------------------------- time

    def refresh_offset(self, symbols: List[str], force: bool = False) -> int:
        """Server-minus-UTC in seconds.

        Starts from the New York + 7h rule (FTMO's clock) and only moves off
        it when two FRESH readings in a row, 10 minutes apart, agree on a
        different whole-hour offset. A reading is fresh when the newest tick
        sits within 90 seconds of a whole hour. A stale tick (market shut,
        weekend) drifts further off every check, so it can never confirm a
        wrong clock — which is what used to happen on Friday nights."""
        now = epoch_now()
        if not force and self.offset_s is not None and now - self._offset_checked < 600:
            return self.offset_s
        self._offset_checked = now
        best = None
        for s in symbols:
            t = self.mt5.symbol_info_tick(s)
            if t is not None and t.time:
                best = t.time if best is None else max(best, t.time)
        fresh = None
        if best is not None:
            raw = best - now
            snapped = int(round(raw / 3600.0)) * 3600
            resid = raw - snapped
            if abs(resid) <= 90 and -12 * 3600 <= snapped <= 14 * 3600:
                fresh = snapped
                if resid > 15:
                    log.warning("the server's newest tick is %.0fs ahead of this PC's clock — "
                                "turn on automatic time sync in Windows", resid)
        if self.offset_s is None:
            self.offset_s = ny_rule_offset(utcnow())
            log.info("server clock UTC%+.0fh (New York + 7h)", self.offset_s / 3600)
        if fresh is None or fresh == self.offset_s:
            self._cand, self._cand_hits = None, 0
            return self.offset_s
        self._cand_hits = self._cand_hits + 1 if fresh == self._cand else 1
        self._cand = fresh
        if self._cand_hits >= 2:
            log.warning("server clock moved: UTC%+.0fh -> UTC%+.0fh (confirmed by two fresh "
                        "readings)", self.offset_s / 3600, fresh / 3600)
            self.offset_s, self._cand, self._cand_hits = fresh, None, 0
        return self.offset_s

    def to_utc(self, server_epoch: float) -> datetime:
        return datetime(1970, 1, 1) + timedelta(seconds=float(server_epoch) - (self.offset_s or 0))

    def to_server_epoch(self, utc: datetime) -> int:
        return int((utc - datetime(1970, 1, 1)).total_seconds()) + (self.offset_s or 0)

    # ------------------------------------------------------------ symbols

    def resolve(self, universe: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Map each exposure to the symbol names this terminal really has."""
        names = [s.name for s in (self.mt5.symbols_get() or [])]
        upper = {n.upper(): n for n in names}
        out: Dict[str, List[str]] = {}
        for exp, wanted in universe.items():
            found = []
            for w in wanted:
                if w in names:
                    found.append(w)
                    continue
                base = w.split(".")[0].upper()
                alt = upper.get(base) or next(
                    (n for u, n in upper.items() if u.startswith(base)), None)
                if alt:
                    log.info("%s: %s not found, using %s", exp, w, alt)
                    found.append(alt)
                else:
                    log.warning("%s: %s is not offered on this account", exp, w)
            for s in found:
                self.mt5.symbol_select(s, True)
            out[exp] = found
        return out

    def info(self, symbol: str):
        return self.mt5.symbol_info(symbol)

    def tick(self, symbol: str):
        return self.mt5.symbol_info_tick(symbol)

    def spread_bp(self, symbol: str) -> Optional[float]:
        t = self.tick(symbol)
        if t is None or not t.ask or not t.bid:
            return None
        return (t.ask - t.bid) / t.ask * 1e4

    # --------------------------------------------------------------- bars

    def bars(self, symbol: str, count: int, minutes: int = 5) -> pd.DataFrame:
        """Closed M5 (or M1 with minutes=1) bars, index = bar open time in
        naive UTC, oldest first. Columns: open high low close volume spread_bp."""
        mt5 = self.mt5
        tf = mt5.TIMEFRAME_M1 if minutes == 1 else mt5.TIMEFRAME_M5
        ti = mt5.terminal_info()
        cap = int(getattr(ti, "maxbars", 0) or 0) if ti is not None else 0
        tries = [count] + [n for n in (200_000, 100_000, 50_000, 20_000, 10_000, 5_000)
                           if n < count]
        if cap:
            tries = [min(n, cap) for n in tries]
        raw = None
        for n in dict.fromkeys(tries):
            raw = mt5.copy_rates_from_pos(symbol, tf, 0, int(n))
            if raw is not None and len(raw):
                break
        if raw is None or not len(raw):
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume", "spread_bp"])
        df = pd.DataFrame(raw)
        off = self.offset_s or 0
        df.index = pd.to_datetime(df["time"] - off, unit="s")
        vol = df["tick_volume"].astype(float)
        if "real_volume" in df and float(df["real_volume"].sum()) > 0:
            vol = df["real_volume"].astype(float)
        info = self.info(symbol)
        point = float(info.point) if info is not None else 0.0
        spread = df["spread"].astype(float) if "spread" in df else pd.Series(0.0, index=df.index)
        out = pd.DataFrame({"open": df["open"].astype(float), "high": df["high"].astype(float),
                            "low": df["low"].astype(float), "close": df["close"].astype(float),
                            "volume": vol.values,
                            "spread_bp": (spread * point / df["close"] * 1e4).values},
                           index=df.index)
        out = out[~out.index.duplicated(keep="last")].sort_index()
        closed_before = pd.Timestamp(utcnow() - timedelta(minutes=minutes, seconds=3))
        return out[out.index <= closed_before]

    # ------------------------------------------------------------- sizing

    def _otype(self, d: int) -> int:
        return self.mt5.ORDER_TYPE_BUY if d > 0 else self.mt5.ORDER_TYPE_SELL

    def loss_per_lot(self, symbol: str, d: int, entry: float, stop: float) -> Optional[float]:
        mt5 = self.mt5
        v = mt5.order_calc_profit(self._otype(d), symbol, 1.0, float(entry), float(stop))
        if v is not None and v < 0:
            return abs(float(v))
        info = self.info(symbol)            # fallback: tick value arithmetic
        if info is None or not info.trade_tick_size:
            return None
        ticks = abs(entry - stop) / info.trade_tick_size
        val = ticks * float(info.trade_tick_value_loss or info.trade_tick_value)
        return val if val > 0 else None

    def round_lots(self, symbol: str, lots: float) -> float:
        info = self.info(symbol)
        step = float(info.volume_step) or 0.01
        lots = math.floor(lots / step + 1e-9) * step
        lots = round(lots, 8)
        if lots < float(info.volume_min):
            return 0.0
        return min(lots, float(info.volume_max))

    def margin(self, symbol: str, d: int, lots: float, price: float) -> Optional[float]:
        m = self.mt5.order_calc_margin(self._otype(d), symbol, float(lots), float(price))
        return None if m is None else float(m)

    # ------------------------------------------------------------- orders

    def _filling(self, symbol: str) -> int:
        mt5 = self.mt5
        fm = int(getattr(self.info(symbol), "filling_mode", 0) or 0)
        if fm & 1:
            return mt5.ORDER_FILLING_FOK
        if fm & 2:
            return mt5.ORDER_FILLING_IOC
        return mt5.ORDER_FILLING_RETURN

    def _deviation_points(self, symbol: str, price: float) -> int:
        info = self.info(symbol)
        pt = float(info.point) or 1e-5
        return max(5, int(price * self.deviation_bp / 1e4 / pt))

    def _round_price(self, symbol: str, price: float) -> float:
        info = self.info(symbol)
        tick = float(info.trade_tick_size or info.point or 0)
        if tick > 0:
            price = round(price / tick) * tick
        return round(price, int(info.digits))

    def open(self, symbol: str, d: int, lots: float, stop_dist: float, magic: int,
             tag: str, attempts: int = 3) -> OrderResult:
        """Market order (d=+1 buy at the ask, d=-1 sell at the bid) with the stop attached from
        the first moment, then re-anchored to the actual fill: stop = fill -/+ stop_dist."""
        mt5 = self.mt5
        for attempt in range(1, attempts + 1):
            t = self.tick(symbol)
            if t is None or not t.ask or not t.bid:
                return OrderResult(False, comment="no quote")
            px = float(t.ask) if d > 0 else float(t.bid)
            sl = self._round_price(symbol, px - d * stop_dist)
            if not self.live:
                log.info("DRY RUN  %s %s %.2f lots @ %.5f  sl %.5f",
                         "buy" if d > 0 else "sell", symbol, lots, px, sl)
                return OrderResult(False, price=px, comment="dry run", dry=True)
            req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": symbol,
                   "volume": float(lots), "type": self._otype(d),
                   "price": px, "sl": sl, "tp": 0.0,
                   "deviation": self._deviation_points(symbol, px),
                   "magic": int(magic), "comment": f"{self.comment} {tag}"[:31],
                   "type_time": mt5.ORDER_TIME_GTC,
                   "type_filling": self._filling(symbol)}
            res = mt5.order_send(req)
            if res is not None and res.retcode in (mt5.TRADE_RETCODE_DONE,
                                                   mt5.TRADE_RETCODE_DONE_PARTIAL):
                ticket = int(res.order)
                pos = self.position(ticket)
                if pos is None:                     # some servers number positions differently
                    mine = [p for p in self.positions() if p.symbol == symbol and p.magic == magic]
                    pos = max(mine, key=lambda p: p.time_msc) if mine else None
                    ticket = int(pos.ticket) if pos is not None else ticket
                fill = float(pos.price_open) if pos is not None else float(res.price or px)
                self.set_sl(ticket, symbol, fill - d * stop_dist)
                return OrderResult(True, ticket, fill, res.retcode, res.comment)
            code = res.retcode if res is not None else None
            why = res.comment if res is not None else str(mt5.last_error())
            if code not in RETRY_CODES:
                return OrderResult(False, retcode=code, comment=why)
            log.warning("%s: attempt %d refused (%s %s) - retrying", symbol, attempt, code, why)
            time.sleep(1.0)
        return OrderResult(False, comment="retries exhausted")

    def set_sl(self, ticket: int, symbol: str, sl: float) -> bool:
        mt5 = self.mt5
        sl = self._round_price(symbol, sl)
        pos = self.position(ticket)
        if pos is not None:
            half_tick = 0.5 * float(getattr(mt5.symbol_info(symbol), "point", 0) or 0)
            if abs(float(pos.sl or 0) - sl) <= half_tick:
                return True                    # filled at the price sent: already right
        req = {"action": mt5.TRADE_ACTION_SLTP, "position": int(ticket), "symbol": symbol,
               "sl": sl, "tp": 0.0, "magic": int(pos.magic) if pos is not None else 0}
        res = mt5.order_send(req)
        ok = res is not None and res.retcode in (mt5.TRADE_RETCODE_DONE,
                                                 mt5.TRADE_RETCODE_NO_CHANGES)
        if not ok:
            pos = self.position(ticket)
            has = pos is not None and pos.sl
            (log.info if has else log.error)(
                "%s #%s: could not move the stop to the fill price (%s) - %s", symbol, ticket,
                res.comment if res is not None else mt5.last_error(),
                "the one sent with the order is in place" if has
                else "STOP MISSING - set it in MT5 by hand")
        return ok

    def close(self, pos, reason: str) -> bool:
        """Close a whole position at market (a long sells at the bid, a short buys at the ask)."""
        mt5 = self.mt5
        if not self.live:
            log.info("DRY RUN  close %s #%s (%s)", pos.symbol, pos.ticket, reason)
            return False
        is_long = int(getattr(pos, "type", 0)) == 0
        for attempt in range(1, 4):
            t = self.tick(pos.symbol)
            if t is None:
                return False
            px = float(t.bid) if is_long else float(t.ask)
            req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": pos.symbol,
                   "volume": float(pos.volume),
                   "type": mt5.ORDER_TYPE_SELL if is_long else mt5.ORDER_TYPE_BUY,
                   "position": int(pos.ticket), "price": px,
                   "deviation": self._deviation_points(pos.symbol, px),
                   "magic": int(pos.magic), "comment": f"{self.comment} {reason}"[:31],
                   "type_time": mt5.ORDER_TIME_GTC,
                   "type_filling": self._filling(pos.symbol)}
            res = mt5.order_send(req)
            if res is not None and res.retcode in (mt5.TRADE_RETCODE_DONE,
                                                   mt5.TRADE_RETCODE_DONE_PARTIAL):
                return True
            code = res.retcode if res is not None else None
            if code not in RETRY_CODES:
                log.error("%s #%s: close refused (%s %s)", pos.symbol, pos.ticket, code,
                          res.comment if res is not None else mt5.last_error())
                return False
            time.sleep(1.0)
        return False

    # ---------------------------------------------------------- positions

    def positions(self) -> List[Any]:
        return [p for p in (self.mt5.positions_get() or []) if int(p.magic) in self.magics]

    def position(self, ticket: int):
        ps = self.mt5.positions_get(ticket=int(ticket))
        return ps[0] if ps else None

    def pnl_at(self, symbol: str, d: int, lots: float, entry: float, price: float) -> float:
        v = self.mt5.order_calc_profit(self._otype(d), symbol, float(lots),
                                       float(entry), float(price))
        return float(v) if v is not None else 0.0

    # -------------------------------------------------------------- deals

    def deals_between(self, utc_from: datetime, utc_to: datetime) -> List[Any]:
        """Deals whose server time falls in [utc_from, utc_to). The API's own
        date filter is loose about time zones, so ask wide and filter here."""
        lo, hi = self.to_server_epoch(utc_from), self.to_server_epoch(utc_to)
        got = self.mt5.history_deals_get(utc_from - timedelta(days=2),
                                         utc_to + timedelta(days=2)) or []
        return [d for d in got if lo <= int(d.time) < hi]

    def deals_for_position(self, ticket: int) -> List[Any]:
        return list(self.mt5.history_deals_get(position=int(ticket)) or [])

    def initial_deposit(self) -> Optional[float]:
        got = self.mt5.history_deals_get(datetime(2000, 1, 1), utcnow() + timedelta(days=2)) or []
        bal = sorted((d for d in got if d.type == self.mt5.DEAL_TYPE_BALANCE),
                     key=lambda d: d.time)
        return float(bal[0].profit) if bal and bal[0].profit > 0 else None
