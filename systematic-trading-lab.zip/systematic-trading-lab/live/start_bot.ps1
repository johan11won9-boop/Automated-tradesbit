# start_bot.ps1 - run the bot live and restart it if it ever exits.
# Usage:  powershell -ExecutionPolicy Bypass -File start_bot.ps1
# Stop:   Ctrl+C twice (once for the bot, once for this loop).

Set-Location $PSScriptRoot
& "$PSScriptRoot\..\venv1\Scripts\Activate.ps1"

while ($true) {
    python bot.py --live
    Write-Host "$(Get-Date -Format s)  bot exited - restarting in 30 seconds (Ctrl+C to stop)"
    Start-Sleep -Seconds 30
}
