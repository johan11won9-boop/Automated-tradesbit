"""
config.example.py — copy to config.py and fill in. Every number the live bot uses, in one place.

The strategy values (instrument, rule parameters, entry cut-off) and the live risk settings are
deliberately NOT published. The ranges below are the research grid they were chosen from.
"""

# ------------------------------------------------------------------ account
INITIAL_BALANCE = None     # None = read it from the account's first deposit

# Risk per trade as a share of the INITIAL balance, fixed (it does not shrink after losses;
# it is only cut when a full stop would not fit above FTMO's loss limits). Example values.
RISK_BY_PHASE = {"evaluation": 0.010, "funded": 0.005}
PHASE = "evaluation"       # "evaluation" or "funded"
RISK_PCT = RISK_BY_PHASE[PHASE]

ACCOUNT_TYPE = "standard"  # "standard" or "swing" (FTMO). Single stocks are 1:1 leverage on Swing.

MAX_LOSS_PCT = 0.10        # FTMO static max loss, from the initial balance
DAILY_LOSS_PCT = 0.05      # FTMO daily loss: midnight (Prague) balance - 5% of initial
DAY_RESET_TZ = "Europe/Prague"

SAFETY_PCT = 0.005         # worst case (every stop hit, 1.25x slippage) must stay this far above a floor
KILL_PCT = 0.003           # flatten everything if equity gets this close to a floor
SLIPPAGE_BUFFER = 1.25

REQUIRE_FTMO_SERVER = True # refuse --live on any non-FTMO login

# ----------------------------------------------------------------- strategy
SYMBOL = "YOUR_SYMBOL"     # not published
SESSION_TZ = "America/New_York"
SESSION_OPEN = "09:30"
SESSION_CLOSE = "16:00"
EARLY_CLOSE = {"2026-11-27": "13:00", "2026-12-24": "13:00", "2027-11-26": "13:00"}   # NYSE 1 pm closes
ENTRY_CUTOFF_MIN = None    # not published - no new entries from a bar this close to the close (tested 30-180)
FLAT_BEFORE_CLOSE_SEC = 60

VB = dict(k=None)                                    # not published - tested 0.3 - 0.7
NA = dict(check=None, lookback=None, mult=None)      # not published - tested 30/60, 14, 0.75 - 1.5

# ---------------------------------------------------------------- execution
MAGIC = {"VB": 880105, "NA": 880131}   # one MT5 magic number per rule: one position each
ORDER_COMMENT = "bot"
MAX_ENTRY_SPREAD_BP = 15.0
DEVIATION_BP = 10.0
MARGIN_USE_MAX = 0.80
SIGNAL_BARS = 6000
MIN_SESSIONS = 16
BAR_DELAY_SECONDS = 4
BAR_WAIT_SECONDS = 40
MAX_SIGNAL_AGE_SECONDS = 90
LOOP_SECONDS = 2

# --------------------------------------------------------------------- news
NEWS_FEED = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
NEWS_IMPACT = {"High"}
NEWS_CURRENCIES = {"USD"}
NEWS_WINDOW_MIN = 3
NEWS_REFRESH_HOURS = 4

# -------------------------------------------------------------------- files
STATE_FILE = "state.json"
JOURNAL_FILE = "trades.csv"
NEWS_CACHE = "news_cache.json"
NEWS_EXTRA = "news_extra.json"
LOG_DIR = "logs"


def news_rule_applies() -> bool:
    """FTMO's news rule only exists on a Standard account once it is funded."""
    return ACCOUNT_TYPE == "standard" and PHASE == "funded"
