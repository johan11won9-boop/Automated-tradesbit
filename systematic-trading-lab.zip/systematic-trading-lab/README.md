# Systematic Trading Lab

**A research lab and a live execution bot for systematic trading - built to find out which strategy ideas
are real before any money is risked.**

Data from three sources → a broker-realistic backtester → a statistics engine with fixed, pre-registered verdict rules →
a strategy search across 217 instruments → a prop-firm economics simulator → a MetaTrader 5 bot whose live decisions
reproduce the backtest trade for trade.

📄 **[Project journey (PDF)](docs/Project_Journey.pdf)** - how this went from a first paper-trading script to here.

| | |
|---|---|
| Instruments searched | **217** across indices, stocks, FX, metals, energy, agriculture and crypto |
| Configurations tested | **10,906** from 14 strategy families in the published literature |
| Survived every out-of-sample test | **1 of 490 finalist strategies** (two intraday rules on one instrument) |
| Live-vs-backtest parity | **2,080 / 2,080** trades reproduced by the live bot's own decision code |
| Lab self-test | luck called an edge **2–4%** of the time; a planted real edge found **87–93%** of the time |

> Strategy parameters, instruments, position sizing and prop-firm settings are **not published**. The code shows the
> method; the values that make it trade are kept private. See [`strategies/`](strategies/) for the ranges they were
> picked from.

---

## What's in here

```
lab/          research lab: data, engine, statistics, strategy search, prop-firm simulator, self-test
strategies/   six strategies taken end-to-end through the lab - one live, five not (and why)
live/         the MetaTrader 5 execution bot (risk engine, broker layer, tests against a fake MT5)
history/      earlier generations: tick scalper, TradingView/Pine Script webhook connector, Golden Ratio MT5 bot
docs/         project journey (PDF + text), research protocol
```

### `lab/` - one tool for data, backtests and verdicts
* **Data**: MetaTrader 5 (every market the terminal serves), Alpaca market data (SIP minute bars since 2016) and Yahoo Finance into one cache;
  quality checks, bad-print repair, cross-source agreement.
* **Engine**: signals fill at the *next* bar's open, longs pay the ask and shorts the bid, real per-bar spreads,
  swaps, gaps through stops fill at the open, stops checked on every bar like a broker holds them.
* **Evidence**: stationary block bootstrap, deflated Sharpe ratio, a random-entry null (does it beat random
  entries in the same market, month and hour?), a robustness battery, an automatic look-ahead check, a 12-month vault
  and Benjamini–Hochberg false-discovery control across finalists.
* **Search**: 14 strategy families × every instrument × a small fixed grid; discovery on pre-2022 data only,
  confirmation on 2022–2025, then an independent price feed, then the held-back final year.
* **Prop-firm simulator**: evaluation fees, phases, payouts, splits, scaling plans, breaches and re-buys, block-
  bootstrapped over the strategy's own daily history, next to a zero-edge twin.

### `live/` - the execution bot (MetaTrader 5, Python)
Measured broker clock (FTMO's server moves with New York DST), closed-bar logic, lot sizing asked from MT5 itself,
stops on the server from the first moment, prop-firm loss floors recomputed from the broker's own numbers every loop,
a worst-case "every stop hits" check before each entry, a kill switch, a news-rule module, restart-safe state, and a
test suite that runs the whole loop - including a simulated week - against a fake MT5.

### `history/` - earlier generations (settings redacted)
A sub-second async tick scalper, the TradingView → webhook → Alpaca pipeline (Pine Script indicator + Flask
receiver) and the Golden Ratio MetaTrader 5 bot with its periodic re-rank. Shown for the engineering; every value they
ran with is redacted. See [`history/README.md`](history/README.md).

### `strategies/` - six strategies through the full protocol

| | strategy | result | status |
|---|---|---|---|
| S1 | Intraday momentum (two breakout rules) | Sharpe 1.3–1.7 per rule out of sample, 1.1–1.6 on a second data feed, positive in the held-back year, beats random entries (p ≤ 0.002) | **live** |
| S2 | Opening-range breakout | Sharpe 0.5–0.6, didn't beat random entries | watch list |
| S3 | RSI(2) daily reversion | Sharpe ~0.9, PF ~2.2 - only 74 trades | needs data |
| S4 | First-candle momentum | Sharpe ~0.9 - random entries did the same (market drift) | rejected |
| S5 | IBS daily reversion | positive 2022–25, negative on the second feed and the final year | rejected |
| S6 | Gap follow-through | positive 2022–25, failed the second feed and the final year | rejected |

---

## Run it

```bash
python -m venv .venv && . .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt

cd lab && python lab.py selftest --quick             # the lab proves itself: unit tests + measured error rates
cd ../live && python -m pytest tests -q              # the bot's code paths against a fake MetaTrader 5
```

Market data needs your own accounts: copy `.env.example` to `lab/.env` and add your keys (never commit `.env`).
The MetaTrader5 package is Windows-only; everything else runs anywhere.

## Built with
Python 3.12 · pandas · numpy · numba · pyarrow · MetaTrader 5 (Python API, MQL5) · Alpaca API · Yahoo Finance ·
TradingView / Pine Script · Flask · pytest · VS Code · vibe-coded with Claude Code, with an agentic AI workflow built in
(e.g. pipeline discovery)

## Disclaimer
Research code. Every figure here is a backtest or simulation result, reported as a range - not live trading
results, and not investment advice. Trading leveraged products can lose more than you put in.

© 2026 Ye. All rights reserved - see [LICENSE](LICENSE).
