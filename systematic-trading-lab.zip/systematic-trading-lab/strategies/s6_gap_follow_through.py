"""
S6 - Opening-gap follow-through                                STATUS: REJECTED (failed out of sample)

Idea
    A large overnight gap (vs yesterday's close, measured in average daily ranges) carries on in its
    direction for the rest of the session ("follow"); the mirror test fades it back to the close.
    Stop at half the gap, flat at the close.

Evidence (ranges)
    confirmation 2022 -> 2025 on its best instrument (a European large-cap stock CFD): Sharpe ~0.7,
    profit factor ~1.16, ~560 trades, beat random entries (p ~0.03).
    Then: no edge on the independent price feed and negative in the held-back final year.
    Verdict: dropped.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, Session, context, frame, need

PARAMS = dict(gap_min=REDACTED, mode=REDACTED)
RANGES = dict(gap_min=(0.25, 0.5), mode=("follow", "fade"))


def gap(df: pd.DataFrame, p: dict = PARAMS, sess: Session = Session()) -> pd.DataFrame:
    need(p)
    x = context(df, sess)
    g = x["day_open"].to_numpy() - x["prev_close"].to_numpy()
    big = np.abs(g) > p["gap_min"] * x["avg_range"].to_numpy()
    trig = x["first"].to_numpy() & x["in_sess"].to_numpy() & big
    d = -np.sign(g) if p["mode"] == "fade" else np.sign(g)
    stop = np.maximum(0.5 * np.abs(g), 0.1 * np.nan_to_num(x["avg_range"].to_numpy()))
    out = frame(df.index, np.where(trig, d, 0), stop)
    out["target_dist"] = np.abs(g) if p["mode"] == "fade" else np.nan
    return out
