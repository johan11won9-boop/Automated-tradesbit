"""
_common.py - the session context every strategy here is built on.

Bars in, one row per bar out: which trading session the bar belongs to, the session's open,
yesterday's range and close, the 14-session average range, VWAP, minutes from the open and to the
close. Everything uses CLOSED bars only - the research lab re-checks that by cutting the history at
random points and recomputing (a signal that changes when later bars are added reads the future).

Conventions shared by every strategy module:
  * input  : DataFrame of OHLCV bars, index = bar OPEN time in naive UTC
  * output : DataFrame with
       entry      +1 long / -1 short / 0 nothing, decided at the bar's CLOSE
       stop_dist  stop distance in price, fixed at the signal (the fill is the next bar's open)
       exit_long / exit_short   optional exit signals (filled at the next bar's open)
  * intraday strategies are flat at the session close
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

REDACTED = None          # live parameter values are not published - see each module's RANGES


@dataclass
class Session:
    tz: str = "America/New_York"
    open: str = "09:30"
    close: str = "16:00"
    entry_cutoff_min: int | None = None    # no new entries this close to the close (None = no cutoff)


def _m(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def context(df: pd.DataFrame, sess: Session, bar_min: int = 5) -> pd.DataFrame:
    idx = pd.DatetimeIndex(df.index)
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    h, l = np.maximum.reduce([h, o, c]), np.minimum.reduce([l, o, c])
    v = df["volume"].to_numpy(float) if "volume" in df else np.ones(len(df))
    v = np.where(np.isfinite(v) & (v > 0), v, 1.0)
    loc = idx.tz_localize("UTC").tz_convert(sess.tz).tz_localize(None)
    mins = np.asarray(loc.hour * 60 + loc.minute, float)
    so, sc = _m(sess.open), _m(sess.close)
    in_sess = (mins >= so) & (mins + bar_min <= sc) & (np.asarray(loc.dayofweek) < 5)
    day = np.where(in_sess, np.asarray((loc.normalize() - pd.Timestamp("2000-01-01")).days), -1)

    si = np.flatnonzero(in_sess)
    s = pd.DataFrame({"day": day[si], "o": o[si], "h": h[si], "l": l[si], "c": c[si],
                      "pv": ((h + l + c) / 3 * v)[si], "v": v[si]}, index=si)
    g = s.groupby("day", sort=True)
    d = pd.DataFrame({"open": g["o"].first(), "high": g["h"].max(), "low": g["l"].min(), "close": g["c"].last()})
    d["range"] = d["high"] - d["low"]
    d["prev_close"], d["prev_range"] = d["close"].shift(1), d["range"].shift(1)
    d["avg_range"] = d["range"].rolling(14, min_periods=5).mean().shift(1)
    m = pd.Series(day)
    out = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "in_sess": in_sess, "day": day,
                        "min_from_open": mins - so, "min_to_close": sc - (mins + bar_min)}, index=idx)
    for k in ("open", "prev_close", "prev_range", "avg_range"):
        out["day_" + k if k == "open" else k] = m.map(d[k]).to_numpy(float)
    vwap = np.full(len(df), np.nan)
    if len(si):
        vwap[si] = (g["pv"].cumsum() / g["v"].cumsum()).to_numpy()
    out["vwap"] = vwap
    first = np.zeros(len(df), bool)
    if len(si):
        first[si[np.r_[True, day[si][1:] != day[si][:-1]]]] = True
    out["first"] = first
    cut = sess.entry_cutoff_min
    out["can_enter"] = in_sess & ((out["min_to_close"] + bar_min > cut) if cut else True)
    return out


def first_per_day(mask: np.ndarray, day: np.ndarray) -> np.ndarray:
    out = np.zeros_like(mask, dtype=bool)
    ix = np.flatnonzero(mask)
    if len(ix):
        out[ix[np.r_[True, day[ix][1:] != day[ix][:-1]]]] = True
    return out


def atr(df: pd.DataFrame, n: int = 14) -> np.ndarray:
    c, h, l = df["close"].to_numpy(float), df["high"].to_numpy(float), df["low"].to_numpy(float)
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum.reduce([h - l, np.abs(h - pc), np.abs(l - pc)])
    return pd.Series(tr).rolling(n, min_periods=n).mean().to_numpy()


def rsi(c: np.ndarray, n: int) -> np.ndarray:
    d = np.diff(c, prepend=c[0])
    g = pd.Series(np.clip(d, 0, None)).rolling(n).mean()
    l_ = pd.Series(np.clip(-d, 0, None)).rolling(n).mean()
    return (100 - 100 / (1 + g / l_.replace(0, np.nan))).to_numpy()


def need(params: dict) -> None:
    missing = [k for k, v in params.items() if v is None]
    if missing:
        raise ValueError(f"parameters not published: {', '.join(missing)} - pick values from RANGES")


def frame(index, entry, stop_dist, exit_long=None, exit_short=None) -> pd.DataFrame:
    n = len(index)
    return pd.DataFrame({"entry": np.asarray(entry, np.int8), "stop_dist": np.asarray(stop_dist, float),
                         "exit_long": np.zeros(n, bool) if exit_long is None else np.asarray(exit_long, bool),
                         "exit_short": np.zeros(n, bool) if exit_short is None else np.asarray(exit_short, bool)},
                        index=index)
