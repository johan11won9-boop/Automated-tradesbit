"""
S2 - Opening-range breakout                                  STATUS: NOT TRADED (inconclusive)

Idea
    The high and low of the first N minutes act as the day's battle lines; the first close outside
    them, once a day, is traded in that direction (classic ORB, Toby Crabel 1990). Stop at the
    other side of the range (or half of it), optional 2R target, otherwise flat at the close.

Evidence (ranges)
    confirmation 2022 -> 2025 on its best instrument: Sharpe 0.5 - 0.6, profit factor ~1.10,
    700-870 trades - positive, but NOT significant after false-discovery control and it did not
    beat random entries in the same month and hour (timing test p 0.15 - 0.21).
    Verdict: INCONCLUSIVE - LEANS YES. Kept on the watch list, not traded.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, Session, context, first_per_day, frame, need

PARAMS = dict(or_min=REDACTED, stop=REDACTED, target_r=REDACTED)
RANGES = dict(or_min=(15, 30, 60), stop=("range", "half", "avg_range_10pct"), target_r=(0, 2))
SESSION = Session(entry_cutoff_min=30)


def opening_range_breakout(df: pd.DataFrame, p: dict = PARAMS, sess: Session = SESSION) -> pd.DataFrame:
    need(p)
    x = context(df, sess)
    in_or = x["in_sess"].to_numpy() & (x["min_from_open"].to_numpy() < p["or_min"])
    g = pd.DataFrame({"day": x["day"].to_numpy()[in_or], "h": x["high"].to_numpy()[in_or],
                      "l": x["low"].to_numpy()[in_or]}).groupby("day")
    d = pd.Series(x["day"].to_numpy())
    hi, lo = d.map(g["h"].max()).to_numpy(float), d.map(g["l"].min()).to_numpy(float)
    ok = x["can_enter"].to_numpy() & (x["min_from_open"].to_numpy() >= p["or_min"]) & np.isfinite(hi)
    c = x["close"].to_numpy()
    up, dn = ok & (c > hi), ok & (c < lo)
    trig = first_per_day(up | dn, x["day"].to_numpy())
    entry = np.where(trig & up, 1, np.where(trig & dn, -1, 0))
    rng = hi - lo
    stop = {"range": rng, "half": 0.5 * rng, "avg_range_10pct": 0.1 * x["avg_range"].to_numpy()}[p["stop"]]
    out = frame(df.index, entry, np.maximum(stop, 0.05 * np.nan_to_num(x["avg_range"].to_numpy())))
    out["target_dist"] = out["stop_dist"] * p["target_r"] if p["target_r"] else np.nan
    return out
