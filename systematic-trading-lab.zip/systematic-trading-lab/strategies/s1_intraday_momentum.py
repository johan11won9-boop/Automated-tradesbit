"""
S1 - Intraday momentum, two complementary breakout rules              STATUS: LIVE (prop-firm evaluation)

Idea
    On some single stocks, a strong move away from the day's open tends to keep going into the close
    (intraday momentum / "noise area" literature: Zarattini, Barbon & Aziz 2024; volatility
    breakouts: Williams, Crabel). Two rules, traded both long and short, flat every day at the close:

    VB  volatility breakout   the FIRST 5-minute close of the day beyond
                              day open +- k x yesterday's session range. Stop: k x yesterday's range.
    NA  noise-area breakout   at fixed check times, a close outside the "noise band":
                              max/min(day open, yesterday's close) x (1 +- m x the average absolute move
                              from the open at that time of day over the previous L sessions).
                              Stop: half the band. Exit when price is back inside max(band, VWAP).

Evidence (research lab protocol - see docs/research-protocol.md; ranges, not exact figures)
    discovery          pre-2022 data only; picked from 10,906 configurations x 217 instruments
    confirmation       2022 -> Oct 2025, never seen in discovery:
                       Sharpe 1.3 - 1.7 per rule, profit factor 1.28 - 1.41, 600-900 trades per rule,
                       random-entry timing test p <= 0.002 (beats random entries in the same month/hour)
                       survives false-discovery control across all 490 finalists (BH, q = 10%)
    second price feed  independent exchange data: Sharpe 1.1 - 1.6
    held-back year     Oct 2025 -> Oct 2026, opened once at the end: Sharpe 0.4 - 1.4 per rule
    combined book      Sharpe ~1.2 - 1.5, ~400-480 trades a year, ~41% winners (winners > losers),
                       ~0 correlation with the underlying stock's own return; long and short both pay
    breadth            the same rules on 46 other US stocks: no edge - the effect is specific
    execution          the live bot replays its own decisions over the history and reproduces the
                       backtest trade for trade (2,080 / 2,080)

Not published: the instrument, the parameter values, the entry cut-off, the sizing and the
prop-firm settings. RANGES below are the search grid the values were picked from.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, Session, context, first_per_day, frame, need

PARAMS = dict(
    vb_k=REDACTED,          # breakout distance, x yesterday's range
    na_check=REDACTED,      # minutes between noise-band checks
    na_lookback=REDACTED,   # sessions in the noise average
    na_mult=REDACTED,       # band width multiplier
)
RANGES = dict(vb_k=(0.3, 0.7), na_check=(30, 60), na_lookback=(14, 14), na_mult=(0.75, 1.5))
SESSION = Session(tz="America/New_York", open="09:30", close="16:00", entry_cutoff_min=REDACTED)
BAR_MIN = 5


def volatility_breakout(df: pd.DataFrame, p: dict = PARAMS, sess: Session = SESSION) -> pd.DataFrame:
    need({"vb_k": p["vb_k"]})
    x = context(df, sess, BAR_MIN)
    k = p["vb_k"]
    ok = x["can_enter"].to_numpy() & (x["min_to_close"].to_numpy() >= 30)
    c, o, pr = x["close"].to_numpy(), x["day_open"].to_numpy(), x["prev_range"].to_numpy()
    up, dn = ok & (c > o + k * pr), ok & (c < o - k * pr)
    trig = first_per_day(up | dn, x["day"].to_numpy())
    entry = np.where(trig & up, 1, np.where(trig & dn, -1, 0))
    stop = np.maximum(k * pr, 0.1 * np.nan_to_num(x["avg_range"].to_numpy()))
    return frame(df.index, entry, stop)


def noise_area(df: pd.DataFrame, p: dict = PARAMS, sess: Session = SESSION) -> pd.DataFrame:
    need({k: p[k] for k in ("na_check", "na_lookback", "na_mult")})
    x = context(df, sess, BAR_MIN)
    c, o = x["close"].to_numpy(), x["day_open"].to_numpy()
    day, ins = x["day"].to_numpy(), x["in_sess"].to_numpy()
    t_end = (x["min_from_open"].to_numpy() + BAR_MIN).astype(int)        # minutes from the open at the bar's end
    move = pd.DataFrame({"day": day[ins], "t": t_end[ins], "mv": np.abs(c / o - 1)[ins]})
    piv = move.pivot_table(index="day", columns="t", values="mv", aggfunc="last")
    avg = piv.rolling(p["na_lookback"], min_periods=max(5, p["na_lookback"] // 2)).mean().shift(1).stack()
    sigma = pd.Series(avg.to_numpy(), index=avg.index).reindex(
        pd.MultiIndex.from_arrays([day, t_end])).to_numpy(float) * p["na_mult"]
    hi = np.fmax(o, x["prev_close"].to_numpy()) * (1 + sigma)
    lo = np.fmin(o, x["prev_close"].to_numpy()) * (1 - sigma)
    check = ins & (t_end % p["na_check"] == 0) & (t_end >= p["na_check"]) & np.isfinite(sigma)
    ok = check & x["can_enter"].to_numpy() & (x["min_to_close"].to_numpy() >= BAR_MIN)
    entry = np.where(ok & (c > hi), 1, np.where(ok & (c < lo), -1, 0))
    vwap = x["vwap"].to_numpy()
    stop = np.maximum((hi - lo) / 2, 0.05 * np.nan_to_num(x["avg_range"].to_numpy()))
    return frame(df.index, entry, stop, check & (c < np.fmax(hi, vwap)), check & (c > np.fmin(lo, vwap)))
