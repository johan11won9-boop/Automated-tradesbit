"""
S5 - Internal bar strength (IBS) mean reversion                STATUS: REJECTED (failed the held-back year)

Idea
    IBS = (close - low) / (high - low). A close in the bottom of the day's range tends to bounce the
    next day: buy below a threshold, exit at the next close; 2 ATR stop. Long-only and two-sided
    variants.

Evidence (ranges)
    confirmation 2022 -> 2025 on its best instrument (a US mega-cap stock): Sharpe 0.45 - 0.8,
    profit factor 1.2 - 1.6, 100-190 trades, beat random entries (p ~0.02-0.05).
    Then: the second price feed and the held-back final year were both negative (Sharpe < 0).
    Verdict: dropped - a textbook case of an effect that looked real on one window only.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, atr, frame, need

PARAMS = dict(threshold=REDACTED, long_only=REDACTED)
RANGES = dict(threshold=(0.1, 0.2), long_only=(True, False))


def ibs(df: pd.DataFrame, p: dict = PARAMS) -> pd.DataFrame:
    """df = DAILY bars. Exit = next close (max_hold 1)."""
    need(p)
    h, l, c = (df[k].to_numpy(float) for k in ("high", "low", "close"))
    v = (c - l) / np.where(h > l, h - l, np.nan)
    entry = np.where(v < p["threshold"], 1, np.where(v > 1 - p["threshold"], -1, 0))
    if p["long_only"]:
        entry = np.where(entry > 0, entry, 0)
    out = frame(df.index, entry, 2.0 * atr(df, 14))
    out["max_hold"] = 1
    return out
