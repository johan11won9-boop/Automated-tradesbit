"""
S4 - First-candle momentum (5-minute opening candle)          STATUS: REJECTED (looks like beta)

Idea
    Zarattini & Aziz (2023): trade the direction of the first 5-minute candle of the US session,
    stop a fraction of the average daily range, 10R target (rarely hit), otherwise out at the close.

Evidence (ranges)
    confirmation 2022 -> 2025 on a US index CFD: Sharpe ~0.9, profit factor ~1.19, ~960 trades -
    but random entries in the same months made about the same (timing test p ~0.33): the profit was
    the index's upward drift, not the signal. The tighter-stop variant made nothing (Sharpe ~0.0).
    Verdict: INCONCLUSIVE - LOOKS LIKE BETA. Dropped.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, Session, context, frame, need

PARAMS = dict(stop_frac=REDACTED)
RANGES = dict(stop_frac=(0.05, 0.2))


def opening_candle(df: pd.DataFrame, p: dict = PARAMS, sess: Session = Session()) -> pd.DataFrame:
    need(p)
    x = context(df, sess)
    trig = x["first"].to_numpy() & x["in_sess"].to_numpy()
    d = np.sign(x["close"].to_numpy() - x["open"].to_numpy())
    stop = np.maximum(p["stop_frac"] * x["avg_range"].to_numpy(), 0.02 * np.nan_to_num(x["avg_range"].to_numpy()))
    out = frame(df.index, np.where(trig, d, 0), stop)
    out["target_dist"] = 10 * out["stop_dist"]
    return out
