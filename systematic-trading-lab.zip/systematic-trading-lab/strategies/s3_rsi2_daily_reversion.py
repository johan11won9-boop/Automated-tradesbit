"""
S3 - Short-term mean reversion, RSI(2) on daily bars         STATUS: PROMISING, NEEDS MORE DATA

Idea
    Larry Connors' RSI(2): in a long-term uptrend (close above the 200-day average) buy a 2-day
    RSI washout, sell when price closes back above its 5-day average (mirror image for shorts below
    the 200-day), at most 10 days, 3 ATR catastrophe stop.

Evidence (ranges)
    confirmation 2022 -> 2025 on its best instrument (a US mega-cap stock): Sharpe ~0.9,
    profit factor ~2.2 - but only 74 trades; held-back final year still positive (Sharpe ~1.0 on
    30 trades). Signals are rare on daily bars, so the sample is too small to call.
    Verdict: INSUFFICIENT DATA - forward-tracking it; a basket version is the next test.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from _common import REDACTED, atr, frame, need, rsi

PARAMS = dict(lo=REDACTED)
RANGES = dict(lo=(5, 10))
MAX_HOLD_DAYS = 10


def rsi2_daily(df: pd.DataFrame, p: dict = PARAMS) -> pd.DataFrame:
    """df = DAILY bars."""
    need(p)
    c = df["close"].to_numpy(float)
    r = rsi(c, 2)
    ma200 = pd.Series(c).rolling(200, min_periods=150).mean().to_numpy()
    ma5 = pd.Series(c).rolling(5).mean().to_numpy()
    entry = np.where((r < p["lo"]) & (c > ma200), 1, np.where((r > 100 - p["lo"]) & (c < ma200), -1, 0))
    out = frame(df.index, entry, 3.0 * atr(df, 14), c > ma5, c < ma5)
    out["max_hold"] = MAX_HOLD_DAYS
    return out
