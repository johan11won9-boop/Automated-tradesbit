# Strategies

Six strategies taken end-to-end through the lab's protocol ([docs/research-protocol.md](../docs/research-protocol.md)).
Each module is a self-contained signal function on OHLCV bars, documented with its idea, the evidence (as ranges) and
its status. **Parameter values are not published** - each module's `PARAMS` is `REDACTED` and refuses to run until you
choose values from its `RANGES` (the grid the lab searched).

| module | strategy | status |
|---|---|---|
| `s1_intraday_momentum.py` | volatility breakout + noise-area breakout, long & short, flat at the close | **live** |
| `s2_opening_range_breakout.py` | first break of the opening range | watch list |
| `s3_rsi2_daily_reversion.py` | Connors RSI(2) with a 200-day trend filter | needs more data |
| `s4_opening_candle_momentum.py` | follow the first 5-minute candle | rejected - market drift |
| `s5_ibs_daily_reversion.py` | internal bar strength reversion | rejected - failed out of sample |
| `s6_gap_follow_through.py` | large opening gaps continue | rejected - failed out of sample |

Output of every module: a DataFrame with `entry` (+1 / -1 / 0, decided at the bar's close; the fill is the next
bar's open), `stop_dist` (fixed at the signal) and optional `exit_long` / `exit_short`, `target_dist`, `max_hold`.

```python
import s1_intraday_momentum as s1
from _common import Session
sig = s1.volatility_breakout(bars, dict(vb_k=0.6), Session(entry_cutoff_min=60))   # example values
```

Why publish the failures? Because the rejections are the evidence that the process works: a protocol that never
says no is not a protocol.
