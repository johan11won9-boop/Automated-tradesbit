"""
prop.py - what the strategy's history means for a prop-firm challenge.

The account is replayed day by day from the backtest (in blocks of days, so
losing streaks stay together), at a chosen risk per trade:
  * daily loss  - equity at ANY point in the day (open trades at their worst
                  bid/ask) vs the balance at midnight Prague minus 5% of initial
  * max loss    - equity vs initial minus 10%, static
  * targets     - closed balance must reach +10% then +5%, with 4+ trading days
  * funded year - monthly payouts of the split, balance reset to initial

Every result is shown next to a ZERO-EDGE TWIN: the same days with the average
profit removed. A strategy only earns its pass rate if it beats its twin -
prop rules alone hand out passes to coin flips.
"""
from __future__ import annotations

from typing import List, Optional

import numpy as np
import pandas as pd

import catalog


def _days(daily: pd.DataFrame) -> np.ndarray:
    """Per-day moves relative to that day's start balance (in strategy units):
    real = closed P&L, low = worst equity, close = equity at day end, and
    whether anything was traded."""
    d = daily.copy()
    real = (d["end_bal"] - d["start_bal"]).to_numpy()
    low = (d["min_eq"] - d["start_bal"]).to_numpy()
    close = (d["end_eq"] - d["start_bal"]).to_numpy()
    traded = (d["trades"].to_numpy() > 0) | (np.abs(real) > 1e-12)
    return np.vstack([real, low, close, traded.astype(float)]).T


def simulate(daily: pd.DataFrame, risk: float, rules: dict, paths: int = 4000, block: int = 10,
             shrink: bool = True, zero_edge: bool = False, seed: int = 21, max_days: int = 520,
             funded_days: int = 252) -> dict:
    """risk = account fraction per 1 unit of the strategy (per R for event strategies)."""
    D = _days(daily)
    if len(D) < 20:
        return dict(ok=False)
    if zero_edge:
        mu = D[:, 0].mean()
        D = D.copy()
        D[:, 0] -= mu
        D[:, 1] -= mu
        D[:, 2] -= mu
    rng = np.random.default_rng(seed)
    n = len(D)
    dl, ml = rules["daily_loss"], rules["max_loss"]
    stops_room = max(1, round(ml / risk)) if risk > 0 else 10

    def path_days(k):
        out = np.empty(k, dtype=np.int64)
        i = int(rng.integers(n))
        for j in range(k):
            if j % block == 0:
                i = int(rng.integers(n))
            out[j] = i
            i = (i + 1) % n
        return out

    def phase(target: float) -> tuple:
        bal = eq = 1.0
        days_traded = 0
        idx = path_days(max_days)
        for j, k in enumerate(idx):
            real, low, close, traded = D[k]
            r = risk
            if shrink:
                r = min(risk, max(0.0, (eq - (1 - ml)) / stops_room))
            # low/close already include P&L carried in from the previous day's open trades
            start = bal
            if start + r * low <= max(start - dl, 1 - ml):
                return "fail", j + 1
            bal = start + r * real
            eq = start + r * close
            days_traded += int(traded > 0)
            if bal - 1 >= target and days_traded >= rules["min_trading_days"]:
                return "pass", j + 1
            if eq <= 1 - ml:
                return "fail", j + 1
        return "stalled", max_days

    res = []
    for _ in range(paths):
        out, days = [], 0
        for ph in rules["phases"]:
            o, dd = phase(ph["target"])
            days += dd
            out.append(o)
            if o != "pass":
                break
        res.append((out, days))
    p1 = np.mean([r[0][0] == "pass" for r in res])
    both = np.mean([len(r[0]) == len(rules["phases"]) and all(o == "pass" for o in r[0]) for r in res])
    fail1 = np.mean([r[0][0] == "fail" for r in res])
    stall = np.mean([r[0][-1] == "stalled" for r in res])
    dpass = [r[1] for r in res if all(o == "pass" for o in r[0]) and len(r[0]) == len(rules["phases"])]
    # funded year
    inc, breach = [], []
    for _ in range(paths // 2):
        bal = eq = 1.0
        paid = 0.0
        broke = False
        idx = path_days(funded_days)
        for j, k in enumerate(idx):
            real, low, close, traded = D[k]
            r = min(risk, max(0.0, (eq - (1 - ml)) / stops_room)) if shrink else risk
            start = bal
            if start + r * low <= max(start - dl, 1 - ml):
                broke = True
                break
            bal = start + r * real
            eq = start + r * close
            if (j + 1) % 21 == 0 and bal > 1.0 and eq >= bal:      # monthly payout
                paid += (bal - 1.0) * rules["split"]
                eq -= bal - 1.0
                bal = 1.0
        inc.append(paid)
        breach.append(broke)
    inc = np.asarray(inc)
    return dict(ok=True, risk=risk, pass_phase1=float(p1), pass_all=float(both), fail_phase1=float(fail1),
                stalled=float(stall), median_days_to_pass=float(np.median(dpass)) if dpass else np.nan,
                funded_income_mean=float(inc.mean()), funded_income_median=float(np.median(inc)),
                funded_zero_income=float((inc <= 0).mean()), funded_breach=float(np.mean(breach)))


# ===================================================================== lifecycle
# A year of running the bot at one firm, the way it really goes: buy an evaluation, pass or fail
# (and buy again), trade the funded account, get paid on the firm's schedule (split, caps,
# consistency, minimums, fee refund), lose the account on a breach and start over.


def business_days(daily: pd.DataFrame) -> pd.DataFrame:
    """The daily account frame on EVERY business day (days without trades = flat), so a month is
    21 rows whatever the trading frequency."""
    if daily.empty:
        return daily
    idx = pd.bdate_range(daily.index.min(), daily.index.max())
    d = daily.reindex(idx)
    for c in ("end_bal", "end_eq"):
        d[c] = d[c].ffill()
    d["start_bal"] = d["end_bal"].shift(1).fillna(daily["start_bal"].iloc[0])
    d["min_eq"] = d["min_eq"].fillna(d[["start_bal", "end_eq"]].min(axis=1))
    d["trades"] = d["trades"].fillna(0)
    return d


def lifecycle(daily: pd.DataFrame, risk: float, P: dict, months: int = 12, paths: int = 2000, block: int = 10,
              shrink: bool = True, zero_edge: bool = False, seed: int = 31, start_funded: bool = False,
              scaling: bool = False, detail: bool = False, eval_risk: Optional[float] = None,
              floor_frac: float = 0.0) -> dict:
    """Net cash (payouts - fees) of ONE account slot over `months`, in dollars of the starting account
    size, over `paths` block-bootstrapped histories. risk = account fraction per strategy unit (1R).
    scaling: apply the program's scaling plan (P['scaling']) - the account grows, payouts with it.
    detail: also return month-by-month cash, challenge timings and account-size growth."""
    D = _days(business_days(daily))
    if len(D) < 40:
        return dict(ok=False)
    if zero_edge:
        D = D.copy()
        mu = D[:, 0].mean()
        D[:, :3] -= mu
    rng = np.random.default_rng(seed)
    n, H = len(D), months * 21
    size = P["size"]
    fee, monthly, act = P.get("fee", 0) / size, P.get("monthly", 0) / size, P.get("activation", 0) / size
    ml, dd = P["max_loss"], P.get("dd", "static")
    lock = P.get("lock")
    dl, dbase, dsoft = P.get("daily"), P.get("daily_base", "balance"), P.get("daily_soft", False)
    kind, every, first = (P["payout"] + (0,))[:3] if P["payout"][0] == "every" else (P["payout"][0], 0, 0)
    win_n, win_min = (P["payout"][1], P["payout"][2]) if P["payout"][0] == "windays" else (0, 0.0)
    cap = P.get("cap", np.inf) / size
    min_pay = P.get("min_pay", 0) / size
    buffer = P.get("buffer", 0.0)
    best = P.get("best_day")
    SC = P.get("scaling") if scaling else None
    cap_mult = SC["cap_total"] / max(P["max_alloc"], size) if SC else 1.0
    stops_room = max(1, round(ml / risk)) if risk > 0 else 10
    er = eval_risk or risk                                   # risk while passing the challenge
    stops_room_e = max(1, round(ml / er)) if er > 0 else 10
    nets, fees_paid, got_funded, n_pay, first_pay_day, breaches, attempts = [], [], [], [], [], [], []
    month_cash = np.zeros((paths, months))
    month_mult = np.zeros((paths, months))                  # account size multiple at month end (0 = evaluating)
    ph_days = np.full((paths, len(P["phases"])), np.nan)     # first attempt: trading days per phase
    first_ok = np.zeros(paths, bool)
    funded_day = np.full(paths, np.nan)
    mults = np.ones(paths)

    for pth in range(paths):
        idx = np.empty(H, np.int64)
        i = int(rng.integers(n))
        for j in range(H):
            if j % block == 0:
                i = int(rng.integers(n))
            idx[j] = i
            i = (i + 1) % n
        mc = month_cash[pth]
        cash, spent, funded_ever, pays, fp, nb, tries = 0.0, 0.0, False, 0, -1, 0, 1
        state, ph = "eval", 0
        if start_funded:                   # "year 2": already funded, this account's fee already spent
            funded_ever, tries, state = True, 0, "funded"
            funded_day[pth] = 0
        else:
            cash, spent = -(fee + monthly), fee + monthly
            mc[0] -= fee + monthly
        mult, split = 1.0, P["split"]
        rev_t, rev_prof, rev_pays = 0, 0.0, 0
        attempt, ph_start = 1, 0

        def fresh():
            return dict(bal=1.0, eq=1.0, hw=1.0, floor=1.0 - ml, days=0, pdays=0, best=0.0, since=0, wins=0,
                        prof=0.0, pw=0)
        a = fresh()
        sub_clock = 0
        for t in range(H):
            m = t // 21
            month_mult[pth, m] = mult if state == "funded" else 0.0
            real, low, close, traded = D[idx[t]]
            if state == "eval" and monthly:
                sub_clock += 1
                if sub_clock % 21 == 0:
                    cash -= monthly
                    spent += monthly
                    mc[m] -= monthly
            room = a["eq"] - a["floor"]
            rk, sr = (er, stops_room_e) if state == "eval" else (risk, stops_room)
            r = max(floor_frac * rk, min(rk, max(0.0, room / sr))) if shrink else rk   # floor: never below
            start = a["bal"]
            dfloor = -np.inf
            if dl:
                base = max(start, a["eq"]) if dbase == "max" else start
                dfloor = base - dl
            lowv, realv, closev = start + r * low, start + r * real, start + r * close
            breach = lowv <= a["floor"]
            if not breach and lowv <= dfloor:
                if dsoft:
                    realv = closev = dfloor                     # stopped at the limit, account survives
                else:
                    breach = True
            if breach:
                nb += 1
                tries += 1
                cash -= fee + monthly
                spent += fee + monthly
                mc[m] -= fee + monthly
                state, ph, a = "eval", 0, fresh()
                sub_clock = 0
                mult, split = 1.0, P["split"]
                rev_t, rev_prof, rev_pays = 0, 0.0, 0
                attempt, ph_start = attempt + 1, t + 1
                continue
            day_pnl = realv - start
            a["bal"], a["eq"] = realv, closev
            a["days"] += int(traded > 0)
            a["pdays"] += int(day_pnl >= P.get("profit_day_min", 1e9))
            a["best"] = max(a["best"], day_pnl)
            if dd in ("eod", "eod_reset"):                       # trailing floor follows end-of-day balance
                a["hw"] = max(a["hw"], a["bal"])
                f = a["hw"] - ml
                if lock is not None:
                    f = min(f, 1.0 + lock)
                a["floor"] = max(a["floor"], f)
            if state == "eval":
                target = P["phases"][ph]
                prof = a["bal"] - 1.0
                ok = prof >= target and a["days"] >= P.get("min_days", 0) and \
                    a["pdays"] >= P.get("min_profit_days", 0)
                if ok and best:
                    ok = a["best"] <= best * max(prof, target)
                if ok:
                    if attempt == 1:
                        ph_days[pth, ph] = t + 1 - ph_start
                    ph += 1
                    ph_start = t + 1
                    a = fresh()
                    if ph == len(P["phases"]):
                        state, funded_ever = "funded", True
                        first_ok[pth] |= attempt == 1
                        if np.isnan(funded_day[pth]):
                            funded_day[pth] = t + 1
                        cash -= act
                        spent += act
                        mc[m] -= act
                        sub_clock = 0
                continue
            # ---------------------------------------------------------- funded
            a["since"] += 1
            a["wins"] += int(day_pnl >= win_min)
            a["pw"] += int(day_pnl >= P["pay_wins"][1]) if P.get("pay_wins") else 0
            a["prof"] += day_pnl
            rev_t += 1
            rev_prof += day_pnl
            if SC and rev_t >= SC["every"]:                     # scaling review
                if rev_prof >= SC["min_profit"] and rev_pays >= SC["min_payouts"] and mult < cap_mult:
                    mult = min(cap_mult, mult + SC["step"])     # +25% of the INITIAL balance (FTMO table)
                    split = SC.get("split", split)
                rev_t, rev_prof, rev_pays = 0, 0.0, 0
            due = (kind == "every" and a["since"] >= (first if pays == 0 else every)) or \
                  (kind == "windays" and a["wins"] >= win_n)
            if not due or (P.get("pay_wins") and a["pw"] < P["pay_wins"][0]):
                continue                                        # pay_wins: n days >= x per payout cycle
            avail = a["bal"] - max(1.0, 1.0 + buffer if buffer else 1.0)
            if best and a["best"] > best * max(a["bal"] - 1.0, 1e-12):
                continue                                        # consistency not met yet: keep trading
            amt = min(cap, P.get("share", 1.0) * avail)
            if amt < min_pay or amt <= 0:
                continue
            got = amt * split * mult
            if pays == 0 and P.get("refund"):
                got += fee
            cash += got
            mc[m] += got
            pays += 1
            rev_pays += 1
            fp = t if fp < 0 else fp
            a["bal"] -= amt
            a["eq"] -= amt
            a["since"], a["wins"], a["best"], a["pw"] = 0, 0, 0.0, 0
            if dd == "eod_reset":                               # FTMO 1-Step: trail restarts after a payout
                a["hw"], a["floor"] = a["bal"], a["bal"] - ml
        nets.append(cash)
        fees_paid.append(spent)
        got_funded.append(funded_ever)
        n_pay.append(pays)
        first_pay_day.append(fp)
        breaches.append(nb)
        attempts.append(tries)
        mults[pth] = mult
    nets = np.asarray(nets) * size
    fpd = np.asarray(first_pay_day, float)
    out = dict(ok=True, risk=risk, net_mean=float(nets.mean()), net_median=float(np.median(nets)),
               net_p10=float(np.percentile(nets, 10)), net_p90=float(np.percentile(nets, 90)),
               loss_prob=float((nets < 0).mean()), fees=float(np.mean(fees_paid) * size),
               funded=float(np.mean(got_funded)), payouts=float(np.mean(n_pay)),
               first_pay_months=float(np.median(fpd[fpd >= 0]) / 21) if (fpd >= 0).any() else np.nan,
               attempts=float(np.mean(attempts)), breaches=float(np.mean(breaches)))
    if detail:
        out.update(month_cash=month_cash * size, phase_days=ph_days, first_attempt_ok=first_ok,
                   funded_day=funded_day, first_pay_day=fpd, size_mult=mults, month_mult=month_mult)
    return out


def firm_table(daily: pd.DataFrame, risks: List[float], programs: Optional[List[str]] = None, months: int = 12,
               paths: int = 1500, cls: Optional[str] = None, shrink: bool = True) -> pd.DataFrame:
    """Every program x risk: the year's net (per account and at the firm's max allocation), next to the
    zero-edge twin (same days, average profit removed) - what the rules alone would pay a coin flip."""
    rows = []
    for name, P in catalog.PROGRAMS.items():
        if (programs and name not in programs) or (cls and P["cls"] != cls):
            continue
        n_acc = max(1, int(P["max_alloc"] // P["size"]))
        for r in risks:
            a = lifecycle(daily, r, P, months, paths, shrink=shrink)
            if not a.get("ok"):
                continue
            z = lifecycle(daily, r, P, months, paths, shrink=shrink, zero_edge=True, seed=32)
            rows.append({"program": name, "risk": r, "net/yr": a["net_mean"], "median/yr": a["net_median"],
                         "p10": a["net_p10"], "p90": a["net_p90"], "P(loss)": a["loss_prob"],
                         "twin net/yr": z["net_mean"], "edge adds/yr": a["net_mean"] - z["net_mean"],
                         "funded": a["funded"], "payouts": a["payouts"], "first pay (mo)": a["first_pay_months"],
                         "evals bought": a["attempts"], "fees": a["fees"], "accounts": n_acc,
                         "per month (max alloc)": a["net_mean"] * n_acc / months})
    return pd.DataFrame(rows)


def table(daily: pd.DataFrame, risks: List[float], rules_name: str = "ftmo_2step", paths: int = 3000,
          account: float = 100_000, shrink: bool = True) -> pd.DataFrame:
    """shrink: the bot's rule of cutting risk as the account nears the max-loss floor
    (event strategies). Position strategies are sized by leverage instead."""
    rules = catalog.PROP_RULES[rules_name]
    rows = []
    for r in risks:
        a = simulate(daily, r, rules, paths=paths, shrink=shrink)
        z = simulate(daily, r, rules, paths=paths, zero_edge=True, seed=22, shrink=shrink)
        if not a.get("ok"):
            continue
        rows.append({"risk": f"{r:.2%}", "pass both": a["pass_all"], "zero-edge twin": z["pass_all"],
                     "edge adds": a["pass_all"] - z["pass_all"], "fail phase 1": a["fail_phase1"],
                     "days to pass": a["median_days_to_pass"],
                     "funded yr income": a["funded_income_mean"] * account,
                     "twin income": z["funded_income_mean"] * account,
                     "yrs with $0": a["funded_zero_income"], "funded breach": a["funded_breach"]})
    return pd.DataFrame(rows)
