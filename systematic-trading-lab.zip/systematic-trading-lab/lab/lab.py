"""
lab.py - the one command for data, backtests and verdicts.

  python lab.py fetch gold silver us500 --source mt5 alpaca yahoo   pull the longest history each source has
  python lab.py fetch-all                                          EVERY symbol on the MT5 account (D1/H1/M5)
  python lab.py fetch-proxies                                      Alpaca 2016+ for the ETFs/stocks behind FTMO CFDs
  python lab.py search discover|select|confirm|further|report       the strategy search (see search.py)
  python lab.py import-archive                                     fold ftmo_live/bars into the MT5 cache
  python lab.py data [gold ...]                                    what's cached, quality, do sources agree
  python lab.py list                                               strategies and instruments
  python lab.py test golden_ratio                                  full verdict on the development data
  python lab.py test golden_ratio --final                          ... including the vault (do this ONCE)
  python lab.py sweep golden_ratio --grid ema=10,20,30 rsi=10,14   try variants, measure overfitting (PBO)
  python lab.py registry [family]                                  every variant you've ever tested
  python lab.py selftest [--quick]                                 prove the tool works (unit tests + error rates)

Common options for test/sweep:
  --instruments gold silver   --source mt5   --venue ftmo   --from 2020-01-01 --to 2026-01-01
  --set ema=25 target_pct=0.02     override params for this run
  --fast                           skip neighbours / other sources (quick look; verdict marks them N/A)
"""
from __future__ import annotations

import argparse
import itertools
import json
import logging
import math
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import catalog          # noqa: E402
import data as dmod     # noqa: E402
import engine           # noqa: E402
import prop             # noqa: E402
import report           # noqa: E402
import stats            # noqa: E402
import strategies       # noqa: E402,F401  (registers the strategies)

RESULTS = ROOT / "results"
REGISTRY = RESULTS / "registry.csv"
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 30)
pd.set_option("display.max_rows", 200)


# ------------------------------------------------------------------- registry

def registry() -> pd.DataFrame:
    if REGISTRY.exists():
        return pd.read_csv(REGISTRY)
    return pd.DataFrame(columns=["time", "family", "kind", "code", "params_hash", "params", "source", "instruments",
                                 "period", "final", "trades", "mean_r", "sharpe", "sr_daily", "days", "dsr",
                                 "timing_p", "verdict"])


def record(row: dict) -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    reg = registry()
    reg = pd.concat([reg, pd.DataFrame([row])], ignore_index=True)
    reg.to_csv(REGISTRY, index=False)


def trials_for(family: str, code: str, ph: str, sr_daily: float) -> tuple:
    """(distinct variants tried incl. this one, variance of their daily Sharpe)."""
    reg = registry()
    reg = reg[(reg["family"] == family) & (reg["kind"].isin(["test", "sweep"]))]
    srs = {}
    for r in reg.itertuples(index=False):
        srs[(r.code, r.params_hash)] = float(r.sr_daily)
    srs[(code, ph)] = sr_daily
    vals = np.array(list(srs.values()), dtype=float)
    return len(vals), float(vals.var(ddof=1)) if len(vals) > 1 else 0.0


def vault_clean(family: str, code: str, ph: str) -> bool:
    reg = registry()
    seen = reg[(reg["family"] == family) & (reg["final"].astype(str) == "True")]
    return not any((r.code, r.params_hash) != (code, ph) for r in seen.itertuples(index=False))


# -------------------------------------------------------------------- evaluate

def parse_set(items: Optional[List[str]]) -> dict:
    out = {}
    for it in items or []:
        k, v = it.split("=", 1)
        try:
            out[k] = json.loads(v)
        except ValueError:
            out[k] = v
    return out


def evaluate(name: str, instruments=None, source=None, venue=None, params=None, final=False, start=None, end=None,
             fast=False, record_it=True, kind="test", trials_override=None, quiet=False, data_override=None,
             write=True, do_prop=True, out_dir=None, alpha=None) -> dict:
    strat = engine.REGISTRY[name]
    instruments = instruments or strat.instruments
    source = source or strat.source
    venue = venue or strat.venue
    params = dict(strat.params, **(params or {}))
    t0 = time.time()
    say = (lambda *a: None) if quiet else (lambda *a: print(*a, flush=True))
    say(f"\n{name}: {', '.join(instruments)} on {source} ({venue} costs), "
        f"{'FINAL - includes the vault' if final else 'development data (vault locked)'}")
    markets, info = engine.prepare_markets(strat, instruments, source, venue, final, start, end, data_override)
    if not markets:
        raise SystemExit(f"no data - run: python lab.py fetch {' '.join(instruments)} --source {source}")
    run_ = engine.run(strat, params=params, markets=markets, info=info)
    say(f"  {len(run_.trades):,} trades simulated ({time.time() - t0:.0f}s)")
    quality = {}
    for inst, mk in markets.items():
        q = dmod.quality(mk.sig, strat.timeframe, mk.meta)
        quality[inst] = q
    look = engine.lookahead_check(strat, run_)
    null = None
    if look:
        say("  LOOKAHEAD found - skipping the rest, results can't be trusted")
    elif strat.mode == "event" and len(run_.trades):
        say("  random-entry comparison ...")
        null = engine.null_trades(run_, catalog.RULES["null_draws"])
    elif strat.mode == "position" and len(run_.daily):
        say("  random-timing comparison ...")
        run_.info["timing"] = stats.position_timing(run_, 200 if not fast else 60)
    d = stats.daily_series(run_)
    x = d.to_numpy()
    sr_d = float(x.mean() / x.std(ddof=1)) if len(x) > 2 and x.std() > 0 else 0.0
    code, ph = strat.fingerprint(params)
    trials = trials_override or trials_for(name, code, ph, sr_d)
    neighbours = None
    if strat.grid and not fast and not look:
        say("  parameter neighbours ...")
        neighbours = run_neighbours(strat, params, markets, info)
    cross = None
    if not fast and data_override is None and not look:
        cross = run_cross(strat, params, instruments, source, final, start, end, say)
    vs = None
    if final:
        starts = [pd.Timestamp(v) for v in info.get("vault", {}).values() if v]
        vs = min(starts) if starts else None
    clean = vault_clean(name, code, ph) if final else True
    a = stats.assess(run_, null=null, lookahead=look, data_quality=quality, trials=trials, neighbours=neighbours,
                     cross=cross, vault_start=vs, vault_clean=clean, final=final, alpha=alpha)
    ptab = None
    if do_prop and len(run_.daily) > 60 and a.verdict not in ("BROKEN",):
        say("  prop-firm simulation ...")
        if strat.mode == "event":
            risks = [0.0025, 0.005, 0.0075, 0.01]
        else:
            vol = x.std(ddof=1) * math.sqrt(stats.ANN) if len(x) > 2 else 0
            risks = [v / vol for v in (0.04, 0.06, 0.08, 0.10)] if vol > 0 else []
        ptab = prop.table(run_.daily, risks, paths=1500 if fast else 3000, shrink=strat.mode == "event")
        if strat.mode == "position" and len(ptab):
            ptab["risk"] = [f"{v:.0%} vol" for v in (0.04, 0.06, 0.08, 0.10)][: len(ptab)]
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = Path(out_dir or RESULTS) / f"{name}_{'final' if final else 'dev'}_{stamp}.html" if write else None
    settings = dict(strategy=name, instruments=", ".join(instruments), source=source, venue=venue,
                    params=json.dumps(params), timeframe=strat.timeframe, session=strat.session, tz=strat.tz,
                    exits=vars(strat.exits), mode=strat.mode, direction=strat.direction,
                    period=f"{run_.period[0]:%Y-%m-%d} to {run_.period[1]:%Y-%m-%d}", final=final,
                    code_hash=code, params_hash=ph, skipped=run_.skipped, data_quality={k: v["level"] for k, v in quality.items()})
    if write:
        report.write_html(path, f"{name} - {a.verdict}", strat.description, settings, a, run_, null, ptab,
                          neighbours, cross, vs)
    title = f"{name}  |  {', '.join(instruments)}  |  {source}/{venue}  |  {run_.period[0]:%Y-%m}..{run_.period[1]:%Y-%m}"
    say(report.console(title, a, ptab, path))
    if record_it:
        tm = a.core.get("timing") or {}
        record(dict(time=datetime.now().isoformat(timespec="seconds"), family=name, kind=kind, code=code,
                    params_hash=ph, params=json.dumps(params), source=source, instruments=" ".join(instruments),
                    period=settings["period"], final=final, trades=len(run_.trades), mean_r=a.core.get("mean_r"),
                    sharpe=a.core.get("sharpe"), sr_daily=sr_d, days=len(x), dsr=a.core.get("dsr"),
                    timing_p=tm.get("p"), verdict=a.verdict))
    return dict(assessment=a, run=run_, null=null, prop=ptab, path=path, neighbours=neighbours, cross=cross)


def run_neighbours(strat, params, markets, info) -> pd.DataFrame:
    rows = []
    for k, vals in strat.grid.items():
        for v in vals:
            if params.get(k) == v:
                continue
            r = engine.run(strat, params=dict(params, **{k: v}), markets=markets, info=dict(info))
            x = stats.daily_series(r).to_numpy()
            rows.append(dict(param=k, value=v, trades=len(r.trades),
                             mean_r=float(r.trades["r_net"].mean()) if len(r.trades) else np.nan,
                             sharpe=stats.sharpe(x)))
    return pd.DataFrame(rows)


def run_cross(strat, params, instruments, source, final, start, end, say) -> Optional[pd.DataFrame]:
    rows = []
    for src in catalog.SOURCES:
        if src == source:
            continue
        ok = []
        for inst in instruments:
            try:
                sig, exe, meta = dmod.load(inst, src, strat.timeframe)
            except (FileNotFoundError, KeyError):
                continue
            if (sig.index[-1] - sig.index[0]).days >= 365:
                ok.append(inst)
        if not ok:
            continue
        venue = "alpaca" if src == "alpaca" else strat.venue
        say(f"  same rules on {src} data ({', '.join(ok)}) ...")
        try:
            r = engine.run(strat, instruments=ok, source=src, venue=venue, params=params, final=final,
                           start=start, end=end)
        except RuntimeError:
            continue
        for inst, g in r.trades.groupby("inst"):
            rows.append(dict(source=src, inst=inst, symbol=r.markets[inst].symbol, trades=len(g),
                             mean_r=float(g["r_net"].mean()), win=float((g["r_net"] > 0).mean()),
                             years=round((r.period[1] - r.period[0]).days / 365.25, 1)))
    return pd.DataFrame(rows) if rows else None


# ----------------------------------------------------------------------- sweep

def sweep(name: str, grid: Dict[str, list], **kw) -> None:
    strat = engine.REGISTRY[name]
    keys = list(grid)
    combos = [dict(zip(keys, vals)) for vals in itertools.product(*[grid[k] for k in keys])]
    print(f"\nsweep {name}: {len(combos)} variants on development data")
    instruments = kw.get("instruments") or strat.instruments
    source = kw.get("source") or strat.source
    venue = kw.get("venue") or strat.venue
    markets, info = engine.prepare_markets(strat, instruments, source, venue, False, kw.get("start"), kw.get("end"))
    cols, rows = {}, []
    base = dict(strat.params, **(kw.get("params") or {}))
    for k, c in enumerate(combos):
        p = dict(base, **c)
        r = engine.run(strat, params=p, markets=markets, info=dict(info))
        d = stats.daily_series(r)
        x = d.to_numpy()
        sr_d = float(x.mean() / x.std(ddof=1)) if x.std() > 0 else 0.0
        code, ph = strat.fingerprint(p)
        cols[json.dumps(c)] = d
        rows.append(dict(variant=json.dumps(c), trades=len(r.trades), mean_r=float(r.trades["r_net"].mean())
                         if len(r.trades) else np.nan, sharpe=stats.sharpe(x)))
        record(dict(time=datetime.now().isoformat(timespec="seconds"), family=name, kind="sweep", code=code,
                    params_hash=ph, params=json.dumps(p), source=source, instruments=" ".join(instruments),
                    period=f"{r.period[0]:%Y-%m-%d} to {r.period[1]:%Y-%m-%d}", final=False, trades=len(r.trades),
                    mean_r=rows[-1]["mean_r"], sharpe=rows[-1]["sharpe"], sr_daily=sr_d, days=len(x), dsr=np.nan,
                    timing_p=np.nan, verdict="(sweep)"))
        print(f"  {k + 1}/{len(combos)} {c}: {rows[-1]['trades']} trades, Sharpe {rows[-1]['sharpe']:.2f}")
    res = pd.DataFrame(rows).sort_values("sharpe", ascending=False)
    M = pd.DataFrame(cols).fillna(0.0)
    pb = stats.pbo(M)
    print("\n" + res.to_string(index=False))
    print(f"\nPBO (chance the best in-sample variant is below median out of sample): "
          f"{pb['pbo']:.0%}   in-sample Sharpe of the winner {pb.get('is_sharpe', np.nan):.2f} -> "
          f"out of sample {pb.get('oos_sharpe', np.nan):.2f}")
    if pb["pbo"] == pb["pbo"] and pb["pbo"] > 0.5:
        print("  -> more likely than not that choosing the best variant is just picking noise.")
    best = json.loads(res.iloc[0]["variant"])
    print(f"\nfull verdict on the best variant {best} (deflated for all {len(combos)} variants + earlier ones):")
    evaluate(name, instruments, source, venue, dict(base, **best), False, kw.get("start"), kw.get("end"),
             fast=kw.get("fast", False))


# ------------------------------------------------------------------------- CLI

def main() -> None:
    for stream in (sys.stdout, sys.stderr):          # Windows consoles/pipes: never crash on a symbol
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fetch")
    f.add_argument("instruments", nargs="+")
    f.add_argument("--source", nargs="+", default=list(catalog.SOURCES))
    f.add_argument("--tf", nargs="+")
    f.add_argument("--full", action="store_true", help="re-download everything, not just new bars")
    fa = sub.add_parser("fetch-all", help="every tradable symbol on the logged-in MT5 account")
    fa.add_argument("--tf", nargs="+", default=["D1", "H1", "M5"])
    fa.add_argument("--only", nargs="+", help="symbols or classes (fx index metal energy agri crypto stock)")
    fa.add_argument("--skip", nargs="+", help="classes to skip")
    fp = sub.add_parser("fetch-proxies", help="Alpaca 2016+ history for the ETFs/stocks behind FTMO's CFDs")
    fp.add_argument("--tf", nargs="+", default=["M5", "D1"])
    fp.add_argument("--no-stocks", action="store_true")
    se = sub.add_parser("search", help="the strategy search: discover / select / confirm / status")
    se.add_argument("stage", choices=["discover", "select", "confirm", "further", "final", "report", "status"])
    se.add_argument("--workers", type=int, default=0)
    se.add_argument("--classes", nargs="+")
    se.add_argument("--families", nargs="+")
    se.add_argument("--ids", nargs="+", help="confirm only these finalists (F01 F07 ...)")
    se.add_argument("--prop", action="store_true", help="include the prop-firm simulation in confirm")
    se.add_argument("--final", action="store_true", help="report: use the vault-included results")
    se.add_argument("--risk", type=float, help="report: risk per trade, e.g. 0.005")
    ia = sub.add_parser("import-archive")
    ia.add_argument("folder", nargs="?", default=str(ROOT.parent / "ftmo_live" / "bars"))
    dd = sub.add_parser("data")
    dd.add_argument("instruments", nargs="*")
    sub.add_parser("list")
    for nm in ("test", "sweep"):
        t = sub.add_parser(nm)
        t.add_argument("strategy")
        t.add_argument("--instruments", nargs="+")
        t.add_argument("--source")
        t.add_argument("--venue")
        t.add_argument("--from", dest="start")
        t.add_argument("--to", dest="end")
        t.add_argument("--set", nargs="+")
        t.add_argument("--fast", action="store_true")
        if nm == "test":
            t.add_argument("--final", action="store_true")
        else:
            t.add_argument("--grid", nargs="+", required=True)
    rg = sub.add_parser("registry")
    rg.add_argument("family", nargs="?")
    st = sub.add_parser("selftest")
    st.add_argument("--quick", action="store_true")
    a = ap.parse_args()

    if a.cmd == "fetch":
        rep = dmod.fetch(a.instruments, a.source, a.tf, a.full)
        print(rep.to_string(index=False) if len(rep) else "nothing fetched")
    elif a.cmd == "fetch-all":
        rep = dmod.fetch_all(a.tf, a.only, skip_classes=a.skip)
        if len(rep):
            rep["first"] = pd.to_datetime(rep["first"])
            summ = rep.groupby(["cls", "tf"]).agg(symbols=("symbol", "nunique"), earliest=("first", "min"),
                                                  latest_start=("first", "max"), bars=("bars", "sum"))
            print(summ.to_string())
        print("done - run it again any time; it only adds what's new")
    elif a.cmd == "fetch-proxies":
        rep = dmod.fetch_proxies(a.tf, stocks=not a.no_stocks)
        print(rep.to_string(index=False) if len(rep) else "nothing fetched")
    elif a.cmd == "search":
        import search
        if a.stage == "discover":
            search.discover(a.workers, a.classes, a.families)
        elif a.stage == "select":
            search.select()
        elif a.stage == "confirm":
            search.confirm(a.ids, final=False, prop_too=a.prop)
        elif a.stage == "final":
            search.confirm(a.ids, final=True, prop_too=True)
        elif a.stage == "further":
            search.further(a.ids)
        elif a.stage == "report":
            search.write_report(a.ids, final=a.final, risk=a.risk)
        else:
            search.status()
    elif a.cmd == "import-archive":
        print(dmod.import_archive(Path(a.folder)).to_string(index=False))
    elif a.cmd == "data":
        inv = dmod.inventory()
        print(f"vault: everything from {dmod.vault_start().date()} on is held back until `test --final`\n")
        if a.instruments and len(inv):
            inv = inv[inv["instrument"].isin(a.instruments)]
        print(inv.to_string(index=False) if len(inv) else "cache is empty - run fetch")
        for inst in a.instruments or sorted(set(inv["instrument"])) if len(inv) else []:
            for r in inv[inv["instrument"] == inst].itertuples(index=False):
                q = dmod.quality(dmod.read(r.source, r.symbol, r.tf), r.tf, dmod.read_meta(r.source, r.symbol, r.tf))
                if q["issues"]:
                    print(f"  {r.source}:{r.symbol} {r.tf} [{q['level']}] " + "; ".join(q["issues"]))
            rec = dmod.reconcile(inst)
            if len(rec):
                print(f"\n  {inst}: do the sources agree (daily returns)?")
                print("  " + rec.to_string(index=False).replace("\n", "\n  "))
    elif a.cmd == "list":
        for k, s in engine.REGISTRY.items():
            print(f"{k:<22} {s.timeframe:<3} {s.mode:<8} {s.direction:<5} {s.source:<6} {', '.join(s.instruments)}")
            print(f"{'':<22} {s.description}\n")
        print("instruments:", ", ".join(catalog.INSTRUMENTS))
    elif a.cmd == "test":
        try:
            evaluate(a.strategy, a.instruments, a.source, a.venue, parse_set(a.set), a.final, a.start, a.end, a.fast)
        except FileNotFoundError as exc:
            print(f"\n  {exc}")
            sys.exit(2)
    elif a.cmd == "sweep":
        grid = {}
        for g in a.grid:
            k, v = g.split("=", 1)
            grid[k] = [json.loads(x) if x.replace(".", "", 1).replace("-", "", 1).isdigit() or x in ("true", "false")
                       else x for x in v.split(",")]
        sweep(a.strategy, grid, instruments=a.instruments, source=a.source, venue=a.venue, start=a.start,
              end=a.end, params=parse_set(a.set), fast=a.fast)
    elif a.cmd == "registry":
        reg = registry()
        if a.family:
            reg = reg[reg["family"] == a.family]
        print(reg.drop(columns=["params"]).to_string(index=False) if len(reg) else "no runs yet")
    elif a.cmd == "selftest":
        import selftest
        sys.exit(selftest.main(quick=a.quick))


if __name__ == "__main__":
    main()
