"""
search.py - the strategy search: documented strategy families x every instrument x timeframes,
under a discovery / confirmation / vault protocol that was fixed BEFORE any result existed.

  python lab.py search discover [--workers 6] [--classes fx index] [--families orb noise]
  python lab.py search select           fixed rules -> finalists (nothing else is looked at)
  python lab.py search confirm          finalists on unseen 2022-2025 data, full engine + verdict
  python lab.py search status           what has run

PROTOCOL (pre-registered 6 Oct 2026, before any search result existed)
  Discovery     every bar BEFORE 2022-01-01, every family x setting x instrument.
                FTMO's MT5 server only has real intraday history for index CFDs and oil from late 2021
                (before that its "5-minute" files hold one bar a day - cut automatically), so US index
                and energy CFDs are discovered on their Alpaca stand-ins from 2016 (SPY QQQ DIA IWM USO
                UNG, and the same US stocks FTMO lists), costed at FTMO's costs for that class.
                Fast screen: exits on 5-minute bars (daily bars for swing families), real per-bar
                spread, commission and swap. Proven identical to engine.py trade-for-trade (selftest).
  Selection     the fixed rules below pick at most 60 finalists, ranked by t-stat (Sharpe x
                sqrt(years)) so long, consistent evidence beats a short lucky streak.
  Confirmation  2022-01-01 to the vault date, through engine.py on FTMO's own CFDs: 1-minute exits
                where cached, random-entry comparison, robustness checks. "Is it real" is decided with
                false-discovery control across ALL finalists (Benjamini-Hochberg, q = 10%): at most ~1 in
                10 strategies called real is expected to be luck. Class-level finalists are confirmed on
                every FTMO instrument of the class, including ones with no discovery history.
  Vault         from the vault date (data/vault.json) on, opened once (`search final`), for the
                confirmed strategies only.

  Instrument level: trades >= 100, years >= 3, net Sharpe >= 0.8, PF >= 1.15, >= 60% of years
      positive, >= half its parameter neighbours profitable. Best 40 by t-stat, max 6 per family.
  Class level ("noise breakout on every index CFD"): every instrument of the class with >= 20
      trades pooled at 1R per trade; trades >= 200, pooled Sharpe >= 0.5, >= 55% of instruments
      positive, >= half the neighbours positive. Best 20 by t-stat, max 4 per family. A class
      result can't cherry-pick tickers.

  Cost feasibility (intraday families): median round-trip spread under 10% of the median session
      range, else the spread eats any intraday edge by construction - not run, and listed as such.
  FTMO gap rule (intraday families): no entries in the 2 hours before a market closure of 2h+.
  Swing families (daily bars, hold overnight/weekends) are meant for FTMO's Swing account type.
"""
from __future__ import annotations

import itertools
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import catalog
import data as dmod

try:
    from numba import njit
except ImportError:                                    # pragma: no cover
    njit = None

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "search"
DISCOVERY_END = pd.Timestamp("2022-01-01")
CONFIRM_START = DISCOVERY_END
MIN_BARS = 1500
WARMUP_DAYS = 420                                      # history before a period, for indicators only

# ---------------------------------------------------------------- sessions
# (time zone, open, close) of the main session each instrument's intraday families key off.
SESSIONS = {
    "us": ("America/New_York", "09:30", "16:00"),
    "de": ("Europe/Berlin", "09:00", "17:30"),
    "uk": ("Europe/London", "08:00", "16:30"),
    "jp": ("Asia/Tokyo", "09:00", "15:00"),
    "hk": ("Asia/Hong_Kong", "09:30", "16:00"),
    "au": ("Australia/Sydney", "10:00", "16:00"),
    "fx": ("Europe/London", "08:00", "17:00"),
    "metal": ("America/New_York", "08:20", "13:30"),
    "energy": ("America/New_York", "09:00", "14:30"),
    "agri": ("America/Chicago", "08:30", "13:20"),
    "crypto": ("UTC", "00:00", "23:55"),
}


def session_key(sym: str, cls: str, uni: dict) -> str:
    if (uni.get(sym) or {}).get("session"):
        return uni[sym]["session"]
    n = sym.split(".")[0].upper()
    if cls == "index":
        if n.startswith(("US", "DXY", "USTEC", "NAS", "SPX", "DJ", "SPY", "QQQ", "IWM", "DIA")):
            return "us"
        if n.startswith(("UK", "FTSE")):
            return "uk"
        if n.startswith(("JP", "NIK")):
            return "jp"
        if n.startswith(("HK", "CHINA", "CN")):
            return "hk"
        if n.startswith(("AUS", "AU")):
            return "au"
        return "de"
    if cls == "stock":
        cur = (uni.get(sym, {}) or {}).get("profit", "USD")
        return {"EUR": "de", "GBP": "uk", "GBX": "uk", "JPY": "jp", "HKD": "hk", "AUD": "au"}.get(cur, "us")
    if cls in ("metal", "energy", "agri", "fx", "crypto"):
        return cls
    return "us"


# Long-history stand-ins (Alpaca, 2016+) for FTMO CFDs whose MT5 intraday history only starts in 2021.
# Discovery runs on the proxy at FTMO's costs for that class; confirmation runs on the FTMO CFD itself.
PROXIES = {"SPY": ("index", "US500.cash"), "QQQ": ("index", "US100.cash"), "DIA": ("index", "US30.cash"),
           "IWM": ("index", "US2000.cash"), "USO": ("energy", "USOIL.cash"), "UNG": ("energy", "NATGAS.cash")}
NOT_PROXIES = {"GLD", "SLV", "TLT", "IAU", "GDX"}      # MT5 already has deep history for these markets


def proxy_twin(src: str, sym: str, uni: dict) -> Optional[str]:
    """The FTMO (MT5) symbol an Alpaca series stands in for."""
    if src != "alpaca":
        return sym
    if sym in PROXIES:
        return PROXIES[sym][1]
    for name, u in uni.items():
        if u.get("cls") == "stock" and _ticker(name) == sym:
            return name
    return None


_ticker = dmod.us_ticker


def dense_from(idx: pd.DatetimeIndex) -> Optional[pd.Timestamp]:
    """Where a bar series becomes real. Brokers often pad old intraday history with one bar a day;
    those stretches are cut. From the first month after which >= 90% of months have at least 40%
    of the typical (recent) monthly bar count."""
    if len(idx) < 1000:
        return None
    m = pd.Series(1, index=idx).resample("MS").sum()
    if len(m) < 3:
        return None
    typical = float(m.iloc[-24:].median())
    ok = (m >= 0.4 * typical).to_numpy()
    suffix = np.cumsum(ok[::-1])[::-1] / np.arange(len(ok), 0, -1)
    good = np.flatnonzero(ok & (suffix >= 0.9))
    return m.index[good[0]] if len(good) else None


# --------------------------------------------------------------- loading
def _read_range(src: str, sym: str, tf: str, start=None, end=None) -> Optional[pd.DataFrame]:
    p = dmod.cache_path(src, sym, tf)
    if not p.exists():
        return None
    flt = []
    if start is not None:
        flt.append(("time", ">=", pd.Timestamp(start)))
    if end is not None:
        flt.append(("time", "<", pd.Timestamp(end)))
    try:
        df = pd.read_parquet(p, filters=flt or None)
    except Exception:                                  # noqa: BLE001 - old file layout: read all, slice
        df = pd.read_parquet(p)
        df.index = pd.DatetimeIndex(df.index)
        if start is not None:
            df = df[df.index >= pd.Timestamp(start)]
        if end is not None:
            df = df[df.index < pd.Timestamp(end)]
    df.index = pd.DatetimeIndex(df.index).astype("datetime64[ns]")
    for c in dmod.COLS:
        if c not in df:
            df[c] = np.nan
    return df[dmod.COLS].astype(float)


def bars(src: str, sym: str, tf: str, start=None, end=None) -> Optional[pd.DataFrame]:
    """Signal bars for the search. D1 from the daily cache; everything intraday from 5-minute bars,
    extended back with 1-minute history where the 5-minute cache starts later; M15/H1 resampled."""
    if tf == "D1":
        df = _read_range(src, sym, "D1", start, end)
        return dmod.repair(df, "D1")[0] if df is not None and len(df) else None
    base = _read_range(src, sym, "M5", start, end)
    m1 = dmod.read_meta(src, sym, "M1")
    if m1.get("first"):
        b0 = base.index[0] if base is not None and len(base) else (pd.Timestamp(end) if end is not None else None)
        if b0 is None or pd.Timestamp(m1["first"]) < b0 - pd.Timedelta(days=20):
            one = _read_range(src, sym, "M1", start, b0)
            if one is not None and len(one):
                ext = dmod.resample(dmod.repair(one, "M1")[0], "M5")
                base = ext if base is None or not len(base) else pd.concat([ext[ext.index < base.index[0]], base])
    if base is None or not len(base):
        return None
    base = base[~base.index.duplicated(keep="last")].sort_index()
    real = dense_from(pd.DatetimeIndex(base.index))
    if real is not None:
        base = base[base.index >= real]
    if len(base) < 100:
        return None
    base = dmod.repair(base, "M5")[0]
    return base if tf == "M5" else dmod.resample(base, tf)


# ------------------------------------------------------------- the kernel
if njit is not None:
    @njit(cache=True)
    def _sim(o, h, l, c, kf, day, sig, stopd, tgtd, exl, exs, last, maxhold, nights, swl, sws, comm_frac,
             same_day):
        """Bid bars (ask = bid * kf). Signal at bar i's close -> fill at bar i+1's open. Stop/target
        checked on every bar (gap through a level fills at the open), exit signals fill at the next
        open, `last` bars flatten at their close, maxhold counts bars after the signal bar."""
        n = len(o)
        cap = n // 2 + 10
        e_i = np.empty(cap, np.int64)
        x_i = np.empty(cap, np.int64)
        dirs = np.empty(cap, np.int8)
        rnet = np.empty(cap, np.float64)
        spr_r = np.empty(cap, np.float64)
        why = np.empty(cap, np.int8)
        k = 0
        i = 0
        while i < n - 1:
            d = sig[i]
            if d == 0 or not (stopd[i] > 0):
                i += 1
                continue
            j0 = i + 1
            if same_day and day[j0] != day[i]:
                i += 1
                continue
            sd = stopd[i]
            entry = o[j0] * kf[j0] if d > 0 else o[j0]
            stop = entry - d * sd
            tg = tgtd[i]
            has_t = tg > 0
            target = entry + d * tg
            mh = maxhold[i]
            px = 0.0
            reason = -1
            j = j0
            while j < n:
                if j > j0:                               # gap through a level at this bar's open
                    po = o[j] if d > 0 else o[j] * kf[j]
                    if d * (po - stop) <= 0:
                        px = po
                        reason = 2
                        break
                    if has_t and d * (po - target) >= 0:
                        px = po
                        reason = 3
                        break
                if d > 0:
                    hs = l[j] <= stop
                    ht = has_t and h[j] >= target
                else:
                    hs = h[j] * kf[j] >= stop
                    ht = has_t and l[j] * kf[j] <= target
                if hs and ht:                            # both in one bar: the bar's shape decides
                    green = c[j] >= o[j]
                    if (green and d > 0) or ((not green) and d < 0):
                        px = stop
                        reason = 0
                    else:
                        px = target
                        reason = 1
                    break
                if hs:
                    px = stop
                    reason = 0
                    break
                if ht:
                    px = target
                    reason = 1
                    break
                if last[j]:
                    px = c[j] if d > 0 else c[j] * kf[j]
                    reason = 4
                    break
                if mh > 0 and j - i >= mh:
                    px = c[j] if d > 0 else c[j] * kf[j]
                    reason = 5
                    break
                if j + 1 < n and ((d > 0 and exl[j]) or (d < 0 and exs[j])):
                    j += 1
                    px = o[j] if d > 0 else o[j] * kf[j]
                    reason = 6
                    break
                j += 1
            if reason < 0:
                break                                    # still open when the data ends: dropped
            r = d * (px - entry) / sd
            r -= comm_frac * entry / sd
            nn = nights[j] - nights[j0]
            if nn > 0:
                rate = swl if d > 0 else sws
                r += nn * rate / 100.0 * entry / sd
            e_i[k] = j0
            x_i[k] = j
            dirs[k] = d
            rnet[k] = r
            spr_r[k] = (kf[j0] - 1.0) * entry / sd       # spread paid, in R (for the cost check)
            why[k] = reason
            k += 1
            if k >= cap:
                break
            # the next signal may come from the exit bar if the exit happened inside it
            i = j if reason in (0, 1, 2, 3, 6) else j + 1
        return e_i[:k], x_i[:k], dirs[:k], rnet[:k], spr_r[:k], why[:k]


# ---------------------------------------------------------- precompute
@dataclass
class Ctx:
    sym: str
    cls: str
    tf: str
    n: int
    t: np.ndarray
    o: np.ndarray
    h: np.ndarray
    l: np.ndarray
    c: np.ndarray
    v: np.ndarray
    kf: np.ndarray
    spread_bp: float
    skey: str
    in_sess: np.ndarray
    day: np.ndarray                 # session day id for in-session bars, -1 outside
    mfo: np.ndarray                 # minutes from session open (bar start)
    mtc: np.ndarray                 # minutes from bar end to session close
    first: np.ndarray               # first bar of the session
    last: np.ndarray                # last bar of the session (intraday families are flat here)
    open_s: np.ndarray
    prev_close: np.ndarray
    prev_range: np.ndarray
    datr: np.ndarray                # average session range, previous 14 sessions
    vwap: np.ndarray
    block: np.ndarray               # FTMO gap rule: no entry here
    nights: np.ndarray
    swl: float
    sws: float
    comm: float
    loc_min: np.ndarray             # minutes of day, session time zone
    lon_min: np.ndarray             # minutes of day, London
    lon_day: np.ndarray
    barmin: int
    contig: np.ndarray              # the next bar follows straight on (a fill is possible)
    cache: dict = field(default_factory=dict)


def _swap_and_costs(sym: str, cls: str, specs: dict, venue: str, c: np.ndarray):
    vs = catalog.VENUES[venue]
    vcls = vs["by_class"].get(cls, vs["by_class"]["other"])
    sl, ss = vs["swap"].get(cls, vs["swap"]["other"])
    spec = specs.get(sym) if venue == "ftmo" else None
    if spec and spec.get("swap_mode") in (1, 2, 3, 4, 5, 6) and spec.get("point"):
        import engine
        price = float(np.nanmedian(c[-2000:]))
        cst = engine.Costs(0, 0, sl, ss, 4, 0, "open", "17:00",
                           spec={k: spec[k] for k in ("swap_mode", "swap_long_raw", "swap_short_raw", "point",
                                                      "contract_size")})
        sl, ss = cst.swap_pct(price, 1), cst.swap_pct(price, -1)
    triple = int((spec or {}).get("triple_day", vcls.get("triple_day", 2)))
    return float(sl), float(ss), triple, 2 * vcls["commission_bp"] / 1e4, vcls


def gap_block(idx: pd.DatetimeIndex, barmin: int) -> np.ndarray:
    """FTMO gap rule: True for bars within 2h before a market closure of 2h+ (weekends, long breaks).
    Read off the bar stream - the schedule is known in advance, so this is not lookahead."""
    tt = idx.values.astype("datetime64[m]").astype(np.int64)
    block = np.zeros(len(idx), bool)
    if len(tt) < 2:
        return block
    gaps = np.diff(tt) - barmin
    close_starts = tt[:-1][gaps >= 120] + barmin
    if len(close_starts):
        k = np.searchsorted(close_starts, tt, side="left")
        ok = k < len(close_starts)
        nxt = np.where(ok, close_starts[np.clip(k, 0, len(close_starts) - 1)], 10 ** 15)
        block = (nxt - tt) <= 120 + barmin
    return block


def build_ctx(sym: str, cls: str, tf: str, df: pd.DataFrame, uni: dict, specs: dict, venue: str = "ftmo",
              min_bars: int = MIN_BARS, block_times: Optional[np.ndarray] = None) -> Optional[Ctx]:
    if df is None or len(df) < min_bars:
        return None
    import engine
    df = df[~df.index.duplicated()].sort_index()
    idx = pd.DatetimeIndex(df.index)
    n = len(idx)
    barmin = 1440 if tf == "D1" else dmod.tf_minutes(tf)
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    h = np.maximum.reduce([h, o, c])
    l = np.minimum.reduce([l, o, c])
    v = df["volume"].to_numpy(dtype=float) if "volume" in df else np.ones(n)
    v = np.where(np.isfinite(v) & (v > 0), v, 1.0)
    spr = df["spread_bp"].to_numpy(dtype=float) if "spread_bp" in df else np.full(n, np.nan)
    good = np.isfinite(spr) & (spr > 0)
    sl, ss, triple, comm, vcls = _swap_and_costs(sym, cls, specs, venue, c)
    med = float(np.median(spr[good])) if good.mean() > 0.5 else float(vcls["spread_bp"])
    spr = np.where(good, np.minimum(spr, 50 * med), med)
    kf = 1 + spr / 1e4
    key = session_key(sym, cls, uni)
    tz, so, sc = SESSIONS[key]
    so_m = int(so[:2]) * 60 + int(so[3:])
    sc_m = int(sc[:2]) * 60 + int(sc[3:])
    if tf == "D1":
        in_sess = np.ones(n, bool)
        day = np.arange(n, dtype=np.int64)
        mfo = np.zeros(n)
        mtc = np.full(n, 1e9)
        first = np.ones(n, bool)
        last = np.zeros(n, bool)
        loc_min = np.zeros(n)
        lon_min = np.zeros(n)
        lon_day = np.arange(n, dtype=np.int64)
        open_s = o.copy()
        prev_close = np.r_[np.nan, c[:-1]]
        rng = h - l
        prev_range = np.r_[np.nan, rng[:-1]]
        datr = pd.Series(rng).rolling(14, min_periods=5).mean().shift(1).to_numpy()
        vwap = (h + l + c) / 3
        block = np.zeros(n, bool)       # swing families: FTMO Swing account, weekends allowed
    else:
        loc = idx.tz_localize("UTC").tz_convert(tz).tz_localize(None) if tz != "UTC" else idx
        loc_min = np.asarray(loc.hour * 60 + loc.minute, dtype=float)
        wd = np.asarray(loc.dayofweek)
        if key == "crypto":
            in_sess = np.ones(n, bool)
        else:
            in_sess = (loc_min >= so_m) & (loc_min + barmin <= sc_m) & (wd < 5)
        dnum = np.asarray((loc.normalize() - pd.Timestamp("2000-01-01")).days, dtype=np.int64)
        day = np.where(in_sess, dnum, -1).astype(np.int64)
        mfo = loc_min - so_m
        mtc = sc_m - (loc_min + barmin)
        si = np.flatnonzero(in_sess)
        first = np.zeros(n, bool)
        last = np.zeros(n, bool)
        if len(si):
            ds = day[si]
            brk = ds[1:] != ds[:-1]
            first[si[np.r_[True, brk]]] = True
            last[si[np.r_[brk, True]]] = True
        sess = pd.DataFrame({"day": day[si], "o": o[si], "h": h[si], "l": l[si], "c": c[si],
                             "pv": ((h + l + c) / 3 * v)[si], "v": v[si]}, index=si)
        g = sess.groupby("day", sort=True)
        daily = pd.DataFrame({"open": g["o"].first(), "high": g["h"].max(), "low": g["l"].min(),
                              "close": g["c"].last()})
        daily["range"] = daily["high"] - daily["low"]
        daily["prev_close"] = daily["close"].shift(1)
        daily["prev_range"] = daily["range"].shift(1)
        daily["datr"] = daily["range"].rolling(14, min_periods=5).mean().shift(1)
        m = pd.Series(day)
        open_s = m.map(daily["open"]).to_numpy(dtype=float)
        prev_close = m.map(daily["prev_close"]).to_numpy(dtype=float)
        prev_range = m.map(daily["prev_range"]).to_numpy(dtype=float)
        datr = m.map(daily["datr"]).to_numpy(dtype=float)
        vwap = np.full(n, np.nan)
        if len(si):
            vwap[si] = (g["pv"].cumsum() / g["v"].cumsum()).to_numpy()
        lon = idx.tz_localize("UTC").tz_convert("Europe/London").tz_localize(None)
        lon_min = np.asarray(lon.hour * 60 + lon.minute, dtype=float)
        lon_day = np.asarray((lon.normalize() - pd.Timestamp("2000-01-01")).days, dtype=np.int64)
        if block_times is not None:          # schedule computed once on the full history (engine runs)
            block = np.isin(idx.values.astype("datetime64[ns]"), block_times)
        else:
            block = gap_block(idx, barmin)
    roll = engine.RollCal(idx[0], idx[-1] + pd.Timedelta(days=10), catalog.VENUES[venue]["rollover_ny"], triple)
    nights = roll(idx).astype(np.float64)
    step = np.diff(idx.values.astype("datetime64[m]").astype(np.int64))
    contig = np.r_[step == barmin, False] if tf != "D1" else np.ones(n, bool)
    return Ctx(sym, cls, tf, n, idx.values, o, h, l, c, v, kf, med, key, in_sess, day, np.asarray(mfo, float),
               np.asarray(mtc, float), first, last, open_s, prev_close, prev_range, datr, vwap, block, nights,
               sl, ss, comm, loc_min, lon_min, lon_day, barmin, contig)


# ------------------------------------------------------------- families
# Each returns (sig, stopd, tgtd, exit_long, exit_short, maxhold). sig = +1/-1/0 decided at the bar's
# close; stopd/tgtd are price distances from the fill (tgtd NaN = no target); maxhold in bars after the
# signal bar (0 = none). Intraday families are flat at the session's last bar.

def _first_per_day(mask: np.ndarray, day: np.ndarray) -> np.ndarray:
    out = np.zeros_like(mask)
    ix = np.flatnonzero(mask)
    if len(ix):
        d = day[ix]
        keep = np.r_[True, d[1:] != d[:-1]]
        out[ix[keep]] = True
    return out


def _floor_stop(sd, x: Ctx, frac=0.05):
    return np.maximum(sd, frac * np.nan_to_num(x.datr, nan=0.0))


def _none(x: Ctx):
    return np.full(x.n, np.nan)


def _z(x: Ctx):
    return np.zeros(x.n, bool)


def _or_levels(x: Ctx, m: int):
    key = ("or", m)
    if key not in x.cache:
        in_or = x.in_sess & (x.mfo < m)
        s = pd.DataFrame({"day": x.day[in_or], "h": x.h[in_or], "l": x.l[in_or]})
        g = s.groupby("day")
        dm = pd.Series(x.day)
        x.cache[key] = (dm.map(g["h"].max()).to_numpy(float), dm.map(g["l"].min()).to_numpy(float))
    return x.cache[key]


def f_orb(x: Ctx, p):
    """Opening-range breakout: first close outside the first `or_min` minutes' range, once a day."""
    m = p["or_min"]
    hi, lo = _or_levels(x, m)
    ok = x.in_sess & (x.mfo >= m) & (x.mtc >= 30) & ~x.block & np.isfinite(hi)
    up = ok & (x.c > hi)
    dn = ok & (x.c < lo)
    trig = _first_per_day(up | dn, x.day)
    sig = np.where(trig & up, 1, np.where(trig & dn, -1, 0)).astype(np.int8)
    rng = hi - lo
    sd = {"range": rng, "half": 0.5 * rng, "atr10": 0.1 * x.datr}[p["stop"]]
    sd = _floor_stop(sd, x)
    tg = sd * p["tgt"] if p["tgt"] else _none(x)
    return sig, sd, tg, _z(x), _z(x), np.zeros(x.n, np.int64)


def f_orb5c(x: Ctx, p):
    """Zarattini & Aziz (2023): trade the direction of the first 5-minute candle, stop a fraction of
    the daily range, target 10R (rarely hit), otherwise out at the close."""
    trig = x.first & x.in_sess & ~x.block
    d = np.sign(x.c - x.o).astype(np.int8)
    sig = np.where(trig, d, 0).astype(np.int8)
    sd = _floor_stop(p["atr"] * x.datr, x, 0.02)
    return sig, sd, sd * 10.0, _z(x), _z(x), np.zeros(x.n, np.int64)


def f_noise(x: Ctx, p):
    """Zarattini, Barbon & Aziz (2024) 'noise area': trade breaks out of the average intraday move
    band (same minute of day, previous `lookback` days), checked every `check` minutes; exit when
    price falls back inside max(band, VWAP); flat at the close."""
    lb, chk, mult = p["lookback"], p["check"], p["mult"]
    key = ("noise", lb)
    if key not in x.cache:
        move = np.abs(x.c / x.open_s - 1)
        key_t = (x.mfo + x.barmin).astype(int)
        m_ = x.in_sess
        s = pd.DataFrame({"day": x.day[m_], "t": key_t[m_], "mv": move[m_]})
        piv = s.pivot_table(index="day", columns="t", values="mv", aggfunc="last")
        sig_t = piv.rolling(lb, min_periods=max(5, lb // 2)).mean().shift(1)
        st = sig_t.stack()
        look = pd.Series(st.to_numpy(), index=pd.MultiIndex.from_arrays(
            [st.index.get_level_values(0), st.index.get_level_values(1)]))
        sigma = look.reindex(pd.MultiIndex.from_arrays([x.day, key_t])).to_numpy(float)
        x.cache[key] = (sigma, key_t)
    sigma, key_t = x.cache[key]
    sigma = sigma * mult
    ref_hi = np.fmax(x.open_s, x.prev_close)
    ref_lo = np.fmin(x.open_s, x.prev_close)
    ub, lbd = ref_hi * (1 + sigma), ref_lo * (1 - sigma)
    chkp = x.in_sess & (key_t % chk == 0) & (x.mfo + x.barmin >= chk) & np.isfinite(sigma)
    ok = chkp & ~x.block & (x.mtc >= x.barmin)          # at least one more session bar to fill in
    sig = np.where(ok & (x.c > ub), 1, np.where(ok & (x.c < lbd), -1, 0)).astype(np.int8)
    exl = chkp & (x.c < np.fmax(ub, x.vwap))
    exs = chkp & (x.c > np.fmin(lbd, x.vwap))
    sd = _floor_stop((ub - lbd) / 2, x)
    return sig, sd, _none(x), exl, exs, np.zeros(x.n, np.int64)


def f_vwapmr(x: Ctx, p):
    """Intraday mean reversion to VWAP: fade a k-sigma stretch from VWAP, target VWAP."""
    dev = x.c - x.vwap
    si = np.flatnonzero(x.in_sess & np.isfinite(dev))                 # spread of the stretch, session bars only
    sdv = np.full(x.n, np.nan)
    sdv[si] = pd.Series(dev[si]).rolling(100, min_periods=50).std().to_numpy()
    ok = x.in_sess & (x.mfo >= 30) & (x.mtc >= 60) & ~x.block & np.isfinite(sdv)
    sig = np.where(ok & (dev < -p["k"] * sdv), 1, np.where(ok & (dev > p["k"] * sdv), -1, 0)).astype(np.int8)
    sd = _floor_stop(np.abs(dev) * p["stop"], x)
    return sig, sd, np.abs(dev), _z(x), _z(x), np.zeros(x.n, np.int64)


def f_gap(x: Ctx, p):
    """Opening gap vs the previous session close: fade it back to the close, or follow it."""
    gap = x.open_s - x.prev_close
    big = np.abs(gap) > p["g"] * x.datr
    trig = x.first & x.in_sess & big & ~x.block
    dirn = -np.sign(gap) if p["mode"] == "fade" else np.sign(gap)
    sig = np.where(trig, dirn, 0).astype(np.int8)
    sd = _floor_stop(0.5 * np.abs(gap), x, 0.1)
    tg = np.abs(gap) if p["mode"] == "fade" else _none(x)
    return sig, sd, tg, _z(x), _z(x), np.zeros(x.n, np.int64)


def f_volbo(x: Ctx, p):
    """Volatility breakout (Williams/Crabel): open +- k x previous session range, once a day."""
    k = p["k"]
    up = x.in_sess & (x.c > x.open_s + k * x.prev_range) & ~x.block & (x.mtc >= 30)
    dn = x.in_sess & (x.c < x.open_s - k * x.prev_range) & ~x.block & (x.mtc >= 30)
    trig = _first_per_day(up | dn, x.day)
    sig = np.where(trig & up, 1, np.where(trig & dn, -1, 0)).astype(np.int8)
    sd = _floor_stop(k * x.prev_range, x, 0.1)
    return sig, sd, _none(x), _z(x), _z(x), np.zeros(x.n, np.int64)


def f_asian(x: Ctx, p):
    """Asian-range breakout at the London open (FX, metals): range 00:00-07:00 London,
    entries 07:00-12:00 London, once a day."""
    key = ("asian",)
    if key not in x.cache:
        in_r = x.lon_min < 7 * 60
        s = pd.DataFrame({"d": x.lon_day[in_r], "h": x.h[in_r], "l": x.l[in_r]})
        g = s.groupby("d")
        dm = pd.Series(x.lon_day)
        x.cache[key] = (dm.map(g["h"].max()).to_numpy(float), dm.map(g["l"].min()).to_numpy(float))
    hi, lo = x.cache[key]
    win = (x.lon_min >= 7 * 60) & (x.lon_min < 12 * 60) & ~x.block & np.isfinite(hi)
    up = win & (x.c > hi)
    dn = win & (x.c < lo)
    trig = _first_per_day(up | dn, x.lon_day)
    sig = np.where(trig & up, 1, np.where(trig & dn, -1, 0)).astype(np.int8)
    sd = np.where(win, _floor_stop(hi - lo, x), np.nan)              # the range is complete from 07:00
    tg = sd * p["tgt"] if p["tgt"] else _none(x)
    return sig, sd, tg, _z(x), _z(x), np.zeros(x.n, np.int64)


def _rsi(c, n):
    d = np.diff(c, prepend=c[0])
    g = pd.Series(np.clip(d, 0, None)).rolling(n).mean()
    l_ = pd.Series(np.clip(-d, 0, None)).rolling(n).mean()
    return (100 - 100 / (1 + g / l_.replace(0, np.nan))).to_numpy()


def _atr_bars(x: Ctx, n=14):
    pc = np.r_[x.c[0], x.c[:-1]]
    tr = np.maximum.reduce([x.h - x.l, np.abs(x.h - pc), np.abs(x.l - pc)])
    return pd.Series(tr).rolling(n, min_periods=n).mean().to_numpy()


def f_rsi2i(x: Ctx, p):
    """Connors RSI(2) mean reversion on intraday bars, out when RSI crosses 50 or at the close."""
    r = _rsi(x.c, 2)
    ok = x.in_sess & (x.mfo >= 30) & (x.mtc >= 30) & ~x.block
    sig = np.where(ok & (r < p["lo"]), 1, np.where(ok & (r > 100 - p["lo"]), -1, 0)).astype(np.int8)
    sd = _floor_stop(1.5 * _atr_bars(x), x)
    return sig, sd, _none(x), r > 50, r < 50, np.zeros(x.n, np.int64)


def _slot_stats(x: Ctx, slot_min: int, lb: int):
    """Per (session day, slot): trailing mean / t-stat of the same slot's return over the previous
    `lb` days (Heston, Korajczyk & Sadka 2010)."""
    key = ("slot", slot_min, lb)
    if key in x.cache:
        return x.cache[key]
    slot = (x.mfo // slot_min).astype(int)
    m_ = x.in_sess
    s = pd.DataFrame({"day": x.day[m_], "slot": slot[m_], "o": x.o[m_], "c": x.c[m_]})
    g = s.groupby(["day", "slot"])
    ret = np.log(g["c"].last() / g["o"].first()).unstack("slot")
    mu = ret.rolling(lb, min_periods=lb // 2).mean().shift(1)
    sdv = ret.rolling(lb, min_periods=lb // 2).std().shift(1)
    cnt = ret.rolling(lb, min_periods=lb // 2).count().shift(1)
    tstat = mu / (sdv / np.sqrt(cnt))
    x.cache[key] = (slot, mu, sdv, tstat)
    return x.cache[key]


def f_hks(x: Ctx, p):
    """Intraday periodicity (Heston, Korajczyk & Sadka 2010): a half-hour's return tends to repeat
    in the same half-hour on following days. Enter at the end of slot s-1 in the direction of slot s's
    trailing mean when its t-stat clears `t`; out after the slot."""
    slot_min = 30
    slot, mu, sdv, tstat = _slot_stats(x, slot_min, p["lookback"])
    nxt = slot + 1
    end_of_slot = x.in_sess & ((x.mfo + x.barmin) % slot_min == 0)          # by the clock, not the next bar
    mi = pd.MultiIndex.from_arrays([x.day, nxt])
    tv = tstat.stack().reindex(mi).to_numpy(float)
    sv = sdv.stack().reindex(mi).to_numpy(float)
    ok = end_of_slot & np.isfinite(tv) & (np.abs(tv) >= p["t"]) & ~x.block & (x.mtc >= slot_min)
    sig = np.where(ok, np.sign(tv), 0).astype(np.int8)
    sd = _floor_stop(2.0 * sv * x.c, x, 0.02)
    hold = max(1, slot_min // x.barmin)
    return sig, sd, _none(x), _z(x), _z(x), np.full(x.n, hold, np.int64)


SD_WINDOWS = {"asia": (0, 7 * 60), "london": (7 * 60, 12 * 60), "ny": (12 * 60, 16 * 60 + 30),
              "late": (16 * 60 + 30, 21 * 60)}


def f_sessdrift(x: Ctx, p):
    """Session drift: hold a fixed London-time window each day in the direction of that window's
    average return over the previous `lookback` days (traded when |t| >= 1). Time-of-day effect."""
    w0, w1 = SD_WINDOWS[p["window"]]
    lb = p["lookback"]
    key = ("sd", p["window"], lb)
    if key not in x.cache:
        inw = (x.lon_min >= w0) & (x.lon_min + x.barmin <= w1)
        s = pd.DataFrame({"d": x.lon_day[inw], "o": x.o[inw], "c": x.c[inw]})
        g = s.groupby("d")
        r = np.log(g["c"].last() / g["o"].first())
        r = r[g["c"].count() >= 0.8 * (w1 - w0) / x.barmin]       # only near-complete windows count
        mp = max(10, lb // 2)
        mu = r.rolling(lb, min_periods=mp).mean().to_numpy()      # includes that day: usable from the next
        sdv = r.rolling(lb, min_periods=mp).std().to_numpy()
        cnt = r.rolling(lb, min_periods=mp).count().to_numpy()
        x.cache[key] = (r.index.to_numpy(), mu / (sdv / np.sqrt(cnt)), sdv)
    days_c, tstat_c, sdv_c = x.cache[key]
    # signal bar: the bar that closes exactly at the window start (by the clock)
    start_bar = (x.lon_min + x.barmin) % 1440 == w0
    wday = x.lon_day + (1 if w0 == 0 else 0)                         # asia: the window is tomorrow's
    k = np.searchsorted(days_c, wday, side="left") - 1               # last COMPLETE window before that day
    has = k >= 0
    kk = np.clip(k, 0, None)
    tv = np.where(has, tstat_c[kk] if len(days_c) else np.nan, np.nan)
    sv = np.where(has, sdv_c[kk] if len(days_c) else np.nan, np.nan)
    ok = start_bar & np.isfinite(tv) & (np.abs(tv) >= 1.0) & ~x.block
    sig = np.where(ok, np.sign(tv), 0).astype(np.int8)
    sd = np.where(start_bar, _floor_stop(2.0 * sv * x.c, x, 0.02), np.nan)   # only defined where it can trade
    hold = (w1 - w0) // x.barmin
    return sig, sd, _none(x), _z(x), _z(x), np.full(x.n, hold, np.int64)


# --- daily (swing) families
def f_donch(x: Ctx, p):
    """Donchian channel trend following (Turtle-style): n-day breakout, exit on the n/2-day opposite
    breakout, 2 ATR stop."""
    n = p["n"]
    hh = pd.Series(x.h).rolling(n).max().shift(1).to_numpy()
    ll = pd.Series(x.l).rolling(n).min().shift(1).to_numpy()
    xh = pd.Series(x.h).rolling(max(2, n // 2)).max().shift(1).to_numpy()
    xl = pd.Series(x.l).rolling(max(2, n // 2)).min().shift(1).to_numpy()
    sig = np.where(x.c > hh, 1, np.where(x.c < ll, -1, 0)).astype(np.int8)
    return sig, 2.0 * _atr_bars(x, 20), _none(x), x.c < xl, x.c > xh, np.zeros(x.n, np.int64)


def f_rsi2d(x: Ctx, p):
    """Connors RSI(2) on daily bars with the 200-day trend filter; out above/below the 5-day MA or
    after 10 days."""
    r = _rsi(x.c, 2)
    ma200 = pd.Series(x.c).rolling(200, min_periods=150).mean().to_numpy()
    ma5 = pd.Series(x.c).rolling(5).mean().to_numpy()
    sig = np.where((r < p["lo"]) & (x.c > ma200), 1, np.where((r > 100 - p["lo"]) & (x.c < ma200), -1, 0)
                   ).astype(np.int8)
    return sig, 3.0 * _atr_bars(x, 14), _none(x), x.c > ma5, x.c < ma5, np.full(x.n, 10, np.int64)


def f_ibs(x: Ctx, p):
    """Internal bar strength: buy a close near the day's low (sell near the high), out at the next close."""
    ibs = (x.c - x.l) / np.where(x.h > x.l, x.h - x.l, np.nan)
    sig = np.where(ibs < p["thr"], 1, np.where(ibs > 1 - p["thr"], -1, 0)).astype(np.int8)
    if p.get("long_only"):
        sig = np.where(sig > 0, sig, 0).astype(np.int8)
    return sig, 2.0 * _atr_bars(x, 14), _none(x), _z(x), _z(x), np.ones(x.n, np.int64)


def f_tom(x: Ctx, p):
    """Turn of the month: long from the open of the `enter`-th last business day for `hold` days.
    Uses the calendar (known in advance), not the count of bars still to come."""
    d = pd.DatetimeIndex(x.t).normalize()
    me = (d + pd.offsets.MonthEnd(0))
    left = np.busday_count(d.values.astype("datetime64[D]"), me.values.astype("datetime64[D]"))
    me_bd = np.is_busday(me.values.astype("datetime64[D]"))
    left = left + me_bd.astype(int) - 1                  # business days after today in this month
    sig = np.where(left == p["enter"], 1, 0).astype(np.int8)        # fill on the enter-th last day
    return sig, 2.0 * _atr_bars(x, 14), _none(x), _z(x), _z(x), np.full(x.n, p["hold"], np.int64)


INTRADAY_CLASSES = ["index", "stock", "metal", "energy", "fx", "crypto", "agri"]
ALL_CLASSES = INTRADAY_CLASSES
# flat: out at the session's last bar. same_day: the fill must be in the signal's session.
# clock: the signal is the time of day / calendar -> random-entry comparison matches the month only.
FAMILIES: Dict[str, dict] = {
    "orb": dict(fn=f_orb, kind="intraday", tfs=["M5"], classes=INTRADAY_CLASSES,
                grid=dict(or_min=[15, 30, 60], stop=["range", "half", "atr10"], tgt=[0, 2])),
    "orb5c": dict(fn=f_orb5c, kind="intraday", tfs=["M5"], classes=INTRADAY_CLASSES,
                  grid=dict(atr=[0.05, 0.1, 0.2])),
    "noise": dict(fn=f_noise, kind="intraday", tfs=["M5"], classes=INTRADAY_CLASSES,
                  grid=dict(lookback=[14], check=[30, 60], mult=[0.75, 1.0, 1.5])),
    "vwapmr": dict(fn=f_vwapmr, kind="intraday", tfs=["M5", "M15"], classes=INTRADAY_CLASSES,
                   grid=dict(k=[2.0, 3.0], stop=[1.0, 2.0])),
    "gap": dict(fn=f_gap, kind="intraday", tfs=["M5"], classes=["index", "stock", "metal", "energy", "agri"],
                grid=dict(g=[0.25, 0.5], mode=["fade", "follow"])),
    "volbo": dict(fn=f_volbo, kind="intraday", tfs=["M5"], classes=INTRADAY_CLASSES,
                  grid=dict(k=[0.3, 0.5, 0.7])),
    "asian": dict(fn=f_asian, kind="intraday", tfs=["M5", "M15"], classes=["fx", "metal"],
                  grid=dict(tgt=[0, 1, 2])),
    "rsi2i": dict(fn=f_rsi2i, kind="intraday", tfs=["M15", "H1"], classes=INTRADAY_CLASSES,
                  grid=dict(lo=[5, 10])),
    "hks": dict(fn=f_hks, kind="intraday", tfs=["M5"], classes=INTRADAY_CLASSES,
                grid=dict(lookback=[20, 40], t=[1.5, 2.0]), clock=True),
    "sessdrift": dict(fn=f_sessdrift, kind="intraday", tfs=["M5"], classes=["index", "metal", "energy", "fx", "crypto"],
                      grid=dict(window=["asia", "london", "ny", "late"], lookback=[120, 250]),
                      flat=False, same_day=False, clock=True),
    "donch": dict(fn=f_donch, kind="swing", tfs=["D1"], classes=ALL_CLASSES, grid=dict(n=[20, 55, 100])),
    "rsi2d": dict(fn=f_rsi2d, kind="swing", tfs=["D1"], classes=ALL_CLASSES, grid=dict(lo=[5, 10])),
    "ibs": dict(fn=f_ibs, kind="swing", tfs=["D1"], classes=ALL_CLASSES,
                grid=dict(thr=[0.1, 0.2], long_only=[False, True])),
    "tom": dict(fn=f_tom, kind="swing", tfs=["D1"], classes=["index", "stock", "metal", "energy", "fx", "crypto"],
                grid=dict(enter=[1, 2], hold=[3, 5]), clock=True),
}
for _f in FAMILIES.values():
    _f.setdefault("flat", _f["kind"] == "intraday")
    _f.setdefault("same_day", _f["kind"] == "intraday")
    _f.setdefault("clock", False)


def configs(fam: str) -> List[dict]:
    g = FAMILIES[fam]["grid"]
    keys = list(g)
    return [dict(zip(keys, vals)) for vals in itertools.product(*[g[k] for k in keys])]


def neighbours(fam: str, p: dict) -> List[dict]:
    g = FAMILIES[fam]["grid"]
    out = []
    for k, vals in g.items():
        if len(vals) < 2:
            continue
        i = vals.index(p[k])
        for j in (i - 1, i + 1):
            if 0 <= j < len(vals):
                out.append(dict(p, **{k: vals[j]}))
    return out


def pkey(p: dict) -> str:
    return json.dumps(p, sort_keys=True)


def n_configs(classes: Optional[List[str]] = None) -> int:
    return sum(len(configs(f)) * len(F["tfs"]) for f, F in FAMILIES.items())


# ----------------------------------------------------------- one instrument
def _to_sim(xs: Ctx, xt: Ctx, out):
    """Signals computed on a coarser timeframe (xt) placed on the 5-minute bars (xs) that close them."""
    sig, sd, tg, exl, exs, mh = out
    if xt is xs:
        return out
    step = np.timedelta64(int(xt.barmin), "m")
    pos = np.searchsorted(xs.t, xt.t + step, side="left") - 1
    ok = (pos >= 0) & (xs.t[np.clip(pos, 0, None)] >= xt.t)
    pos = pos[ok]
    ratio = xt.barmin // xs.barmin

    def put(a, fill, dtype):
        z = np.full(xs.n, fill, dtype=dtype)
        z[pos] = np.asarray(a)[ok]
        return z
    return (put(sig, 0, np.int8), put(sd, np.nan, float), put(tg, np.nan, float), put(exl, False, bool),
            put(exs, False, bool), put(np.asarray(mh) * ratio, 0, np.int64))


def run_family(xs: Ctx, xt: Ctx, fam: str, p: dict):
    F = FAMILIES[fam]
    sig, sd, tg, exl, exs, mh = _to_sim(xs, xt, F["fn"](xt, p))
    sig = np.where(np.isfinite(sd) & (sd > 0) & xs.contig, sig, 0).astype(np.int8)
    sd = np.nan_to_num(sd, nan=0.0)
    tg = np.nan_to_num(tg, nan=-1.0)
    last = xs.last if F["flat"] else np.zeros(xs.n, bool)
    day = xs.day if F["same_day"] else np.zeros(xs.n, np.int64)
    res = _sim(xs.o, xs.h, xs.l, xs.c, xs.kf, day, sig, sd, tg, np.asarray(exl, bool), np.asarray(exs, bool),
               last, np.asarray(mh, np.int64), xs.nights, xs.swl, xs.sws, xs.comm, bool(F["same_day"]))
    return res, sd


def metrics(t_entry, t_exit, r, spr_r, lo: pd.Timestamp, hi: pd.Timestamp):
    n = len(r)
    if n == 0:
        return None
    days = pd.bdate_range(lo.normalize(), hi.normalize())
    xd = pd.DatetimeIndex(t_exit).normalize()
    pos = days.searchsorted(xd).clip(0, len(days) - 1)
    daily = np.bincount(pos, weights=r, minlength=len(days))
    sd = daily.std(ddof=1)
    yrs = len(days) / 261
    years = pd.Series(r).groupby(pd.DatetimeIndex(t_entry).year).sum()
    eq = np.cumsum(daily)
    dd = float((np.maximum.accumulate(np.r_[0, eq])[1:] - eq).max())
    gw, gl = r[r > 0].sum(), -r[r < 0].sum()
    sh = float(daily.mean() / sd * math.sqrt(261)) if sd > 0 else 0.0
    r15 = r - 0.5 * spr_r
    d15 = np.bincount(pos, weights=r15, minlength=len(days))
    sh15 = float(d15.mean() / d15.std(ddof=1) * math.sqrt(261)) if d15.std() > 0 else 0.0
    m = dict(trades=n, years=round(yrs, 2), mean_r=float(r.mean()), sum_r=float(r.sum()),
             win=float((r > 0).mean()), pf=float(gw / gl) if gl > 0 else 99.0, sharpe=sh,
             tstat=sh * math.sqrt(max(yrs, 1e-9)), sharpe_c15=sh15, spread_r=float(spr_r.mean()),
             pos_years=float((years > 0).mean()) if len(years) else 0.0, n_years=int(len(years)),
             max_dd_r=dd, tpy=n / yrs if yrs > 0 else 0.0,
             best_r=float(r.max()), worst_r=float(r.min()))
    return m, daily.astype(np.float32), days


def _uni() -> dict:
    p = dmod.DATA / "mt5" / "universe.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


def instrument_job(args) -> List[dict]:
    """Every family x setting x timeframe on one instrument's data in [start, end)."""
    src, sym, cls, fams, start, end = args
    uni = _uni()
    specs = dmod.mt5_specs()
    venue = "ftmo"                         # every series is costed as the FTMO CFD it stands for
    if src == "alpaca":
        uni = dict(uni, **{sym: dict(cls=cls, session="us")})
    rows: List[dict] = []
    fams = [f for f in fams if cls in FAMILIES[f]["classes"]]
    need = {tf for f in fams for tf in FAMILIES[f]["tfs"]}
    base = {"meta": dict(src=src, sym=sym, cls=cls)}
    xs = None
    if need - {"D1"}:
        m5 = bars(src, sym, "M5", start, end)
        if m5 is not None and len(m5) >= MIN_BARS:
            xs = build_ctx(sym, cls, "M5", m5, uni, specs, venue)
            ctxs = {"M5": xs}
            for tf in sorted(need - {"D1", "M5"}):
                ctxs[tf] = build_ctx(sym, cls, tf, dmod.resample(m5, tf), uni, specs, venue, min_bars=300)
            del m5
    if "D1" in need:
        d1 = bars(src, sym, "D1", start, end)
        xd = build_ctx(sym, cls, "D1", d1, uni, specs, venue, min_bars=300) if d1 is not None else None
    else:
        xd = None
    feasible, why = True, ""
    if xs is not None:
        rng_bp = float(np.nanmedian((xs.prev_range / xs.open_s)[xs.first] * 1e4))
        feasible = bool(np.isfinite(rng_bp) and xs.spread_bp < 0.10 * rng_bp)
        why = f"cost screen: spread {xs.spread_bp:.1f}bp vs session range {rng_bp:.0f}bp"
    for fam in fams:
        F = FAMILIES[fam]
        for tf in F["tfs"]:
            if F["kind"] == "swing":
                xsim = xt = xd
            else:
                xsim = xs
                xt = ctxs.get(tf) if xs is not None else None
            if xsim is None or xt is None:
                continue
            head = dict(src=src, sym=sym, cls=cls, fam=fam, tf=tf)
            if F["kind"] == "intraday" and not feasible:
                rows.append(dict(head, params="*", trades=0, note=why))
                continue
            lo, hi = pd.Timestamp(xsim.t[0]), pd.Timestamp(xsim.t[-1])
            for p in configs(fam):
                try:
                    (e_i, x_i, dirs, r, spr_r, why_), sd = run_family(xsim, xt, fam, p)
                except Exception as exc:          # noqa: BLE001
                    rows.append(dict(head, params=pkey(p), trades=0, note=f"error {type(exc).__name__}: {exc}"))
                    continue
                m = metrics(xsim.t[e_i], xsim.t[x_i], r, spr_r, lo, hi)
                if m is None:
                    rows.append(dict(head, params=pkey(p), trades=0))
                    continue
                mm, daily, days = m
                stop_bp = float(np.median(sd[e_i - 1] / xsim.o[e_i]) * 1e4) if len(e_i) else np.nan
                mm.update(head, params=pkey(p), first=str(lo.date()), last=str(hi.date()),
                          spread_bp=round(xsim.spread_bp, 2), stop_bp=round(stop_bp, 1),
                          long_share=float((dirs > 0).mean()),
                          exits=",".join(f"{k}:{int((why_ == c).sum())}" for k, c in
                                         (("stop", 0), ("tgt", 1), ("gap", 2), ("eod", 4), ("time", 5),
                                          ("sig", 6)) if (why_ == c).any()),
                          daily=daily, days0=str(days[0].date()))
                rows.append(mm)
    return rows


# ----------------------------------------------------------------- discover
def universe(classes: Optional[List[str]] = None, sources=("mt5", "alpaca")) -> List[Tuple[str, str, str]]:
    """(source, symbol, class) for every cached instrument that has intraday or daily bars."""
    out = []
    uni = _uni()
    seen = set()
    for src in sources:
        d = dmod.DATA / src
        if not d.exists():
            continue
        for mp in sorted(d.glob("*.meta.json")):
            try:
                m = json.loads(mp.read_text(encoding="utf-8"))
            except ValueError:
                continue
            sym = m.get("symbol")
            if not sym or (src, sym) in seen:
                continue
            seen.add((src, sym))
            if src == "mt5":
                cls = (uni.get(sym) or {}).get("cls") or m.get("cls") or catalog.classify_mt5("", sym)
            else:
                if "/" in sym or sym in NOT_PROXIES:
                    continue                    # crypto/metals: MT5 has the longer, tradable series
                cls = PROXIES[sym][0] if sym in PROXIES else "stock"
            if cls == "other" or (classes and cls not in classes):
                continue
            out.append((src, sym, cls))
    return out


def _write_daily(rows: List[dict], path: Path) -> None:
    daily = {}
    for r in rows:
        if "daily" in r:
            daily[f"{r['src']}|{r['sym']}|{r['fam']}|{r['tf']}|{r['params']}"] = (r.pop("daily"), r.pop("days0"))
    np.savez_compressed(path, **{f"d{k}": v[0] for k, v in enumerate(daily.values())},
                        keys=np.array(list(daily.keys())), starts=np.array([v[1] for v in daily.values()]))


def discover(workers: int = 0, classes: Optional[List[str]] = None, fams: Optional[List[str]] = None,
             sources=("mt5", "alpaca")) -> Path:
    if njit is None:
        raise SystemExit("the search needs numba:  pip install numba")
    OUT.mkdir(parents=True, exist_ok=True)
    fams = fams or list(FAMILIES)
    uni = universe(classes, sources)
    jobs = [(src, sym, cls, fams, None, DISCOVERY_END) for src, sym, cls in uni]
    workers = workers or max(1, min(4, (os.cpu_count() or 2) - 1))     # ~1-2 GB RAM per worker
    print(f"discovery: {len(jobs)} instruments x {len(fams)} families, bars before {DISCOVERY_END.date()}, "
          f"{workers} workers")
    print("  classes: " + ", ".join(f"{c} {sum(1 for j in uni if j[2] == c)}" for c in sorted({j[2] for j in uni})))
    rows, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(instrument_job, j): j for j in jobs}
        for k, f in enumerate(as_completed(futs)):
            j = futs[f]
            try:
                got = f.result()
            except Exception as exc:     # noqa: BLE001
                print(f"  {j[0]}:{j[1]}: FAILED {type(exc).__name__}: {exc}")
                continue
            rows += got
            done = sum(1 for g in got if g.get("trades", 0) > 0)
            best = max((g.get("tstat", -9) for g in got if g.get("trades", 0) >= 100), default=float("nan"))
            print(f"  [{k + 1}/{len(jobs)}] {j[0]}:{j[1]} ({j[2]}) {done} configs with trades"
                  f"{'' if best != best else f', best t {best:.1f}'}  ({(time.time() - t0) / 60:.1f} min)",
                  flush=True)
    _write_daily(rows, OUT / "discovery_daily.npz")
    tab = pd.DataFrame(rows)
    tab.to_csv(OUT / "discovery.csv", index=False)
    meta = dict(ran=str(pd.Timestamp.now())[:19], discovery_end=str(DISCOVERY_END.date()), instruments=len(jobs),
                configs=int((tab.get("trades", pd.Series(dtype=float)) > 0).sum()), families=fams,
                classes=sorted({j[2] for j in uni}))
    (OUT / "discovery_meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print(f"\ndone: {meta['configs']:,} configurations with trades -> {OUT / 'discovery.csv'}")
    print("next: python lab.py search select")
    return OUT / "discovery.csv"


# ------------------------------------------------------------------- select
RULES_I = dict(trades=100, years=3.0, sharpe=0.8, pf=1.15, pos_years=0.6, nb=0.5, top=40, per_family=6)
RULES_C = dict(trades=200, sharpe=0.5, breadth=0.55, nb=0.5, top=20, per_family=4, min_inst=3, inst_trades=20)


def _load_daily(path: Path) -> Dict[str, Tuple[np.datetime64, np.ndarray]]:
    """key -> (first business day, daily R array). Kept as plain arrays: aligning thousands of pandas
    Series is what made selection slow."""
    z = np.load(path, allow_pickle=False)
    keys, starts = list(z["keys"]), list(z["starts"])
    return {str(key): (np.datetime64(str(s0), "D"), z[f"d{k}"]) for k, (key, s0) in enumerate(zip(keys, starts))}


def class_table(tab: pd.DataFrame, daily: Dict[str, Tuple[np.datetime64, np.ndarray]]) -> pd.DataFrame:
    rows = []
    groups = tab.groupby(["fam", "tf", "params", "cls"])
    for k, ((fam, tf, params, cls), g) in enumerate(groups):
        if k % 500 == 0:
            print(f"  class level: {k:,}/{groups.ngroups:,} groups", flush=True)
        g = g[g.trades >= RULES_C["inst_trades"]]
        if len(g) < RULES_C["min_inst"]:
            continue
        ser = [daily.get(f"{r.src}|{r.sym}|{fam}|{tf}|{params}") for r in g.itertuples()]
        ser = [v for v in ser if v is not None]
        if not ser:
            continue
        d0 = min(v[0] for v in ser)
        offs = [int(np.busday_count(d0, v[0])) for v in ser]
        port = np.zeros(max(o + len(v[1]) for o, v in zip(offs, ser)))
        for o, v in zip(offs, ser):
            port[o:o + len(v[1])] += v[1]
        sd = port.std(ddof=1)
        yrs = len(port) / 261
        sh = float(port.mean() / sd * math.sqrt(261)) if sd > 0 else 0.0
        rows.append(dict(fam=fam, tf=tf, params=params, cls=cls, instruments=len(g),
                         symbols=" ".join(f"{r.src}:{r.sym}" for r in g.itertuples()), trades=int(g.trades.sum()),
                         sharpe=sh, tstat=sh * math.sqrt(yrs), breadth=float((g.mean_r > 0).mean()),
                         mean_r=float((g.mean_r * g.trades).sum() / g.trades.sum()), years=round(yrs, 1)))
    return pd.DataFrame(rows)


def select() -> pd.DataFrame:
    print("selection: reading discovery results ...", flush=True)
    tab = pd.read_csv(OUT / "discovery.csv")
    screened = len(tab)
    tab = tab[tab["trades"] > 0].copy()
    good = tab.set_index(["src", "sym", "fam", "tf", "params"])["sharpe"].to_dict()
    nb = []
    for r in tab.itertuples(index=False):
        keys = [(r.src, r.sym, r.fam, r.tf, pkey(q)) for q in neighbours(r.fam, json.loads(r.params))]
        vals = [good[k] for k in keys if k in good]
        nb.append(float(np.mean([v > 0 for v in vals])) if vals else 1.0)
    tab["nb_pos"] = nb
    R = RULES_I
    inst = tab[(tab.trades >= R["trades"]) & (tab.years >= R["years"]) & (tab.sharpe >= R["sharpe"]) &
               (tab.pf >= R["pf"]) & (tab.pos_years >= R["pos_years"]) & (tab.nb_pos >= R["nb"])]
    inst = inst.sort_values("tstat", ascending=False)
    inst = inst.groupby("fam").head(R["per_family"]).head(R["top"]).assign(level="instrument")
    print(f"  instrument level: {len(inst)} finalists; pooling instruments by class ...", flush=True)
    ct = class_table(tab, _load_daily(OUT / "discovery_daily.npz"))
    cl = pd.DataFrame()
    if len(ct):
        cg = ct.set_index(["fam", "tf", "params", "cls"])["sharpe"].to_dict()
        ct["nb_pos"] = [float(np.mean([cg.get((r.fam, r.tf, pkey(q), r.cls), -1) > 0
                                       for q in neighbours(r.fam, json.loads(r.params))] or [1.0]))
                        for r in ct.itertuples()]
        C = RULES_C
        cl = ct[(ct.trades >= C["trades"]) & (ct.sharpe >= C["sharpe"]) & (ct.breadth >= C["breadth"]) &
                (ct.nb_pos >= C["nb"])].sort_values("tstat", ascending=False)
        cl = cl.groupby("fam").head(C["per_family"]).head(C["top"]).assign(level="class")
        ct.to_csv(OUT / "class_level.csv", index=False)
    fin = pd.concat([inst, cl], ignore_index=True)
    fin.insert(0, "id", [f"F{k + 1:02d}" for k in range(len(fin))])
    fin.to_csv(OUT / "finalists.csv", index=False)
    print(f"{screened:,} rows screened ({len(tab):,} configurations with trades)")
    print(f"  instrument level: {len(inst)} finalists   class level: {len(cl)} finalists   -> {OUT / 'finalists.csv'}")
    show = [c for c in ("id", "level", "fam", "tf", "params", "sym", "cls", "instruments", "trades", "years",
                        "sharpe", "tstat", "pf", "mean_r", "breadth") if c in fin]
    if len(fin):
        print(fin[show].to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    print("next: python lab.py search confirm")
    return fin


# ------------------------------------------------------------------ confirm
_SIDE: Dict[str, dict] = {}          # per (strategy, instrument): universe, specs, gap-rule schedule


def make_strategy(fam: str, tf: str, params: dict, name: str, insts: List[str]):
    """A finalist as an engine Strategy. The signal function rebuilds the family's context from the
    signal bars it is given (instrument identity travels in the frame's attrs)."""
    import engine
    F = FAMILIES[fam]

    def fn(s: pd.DataFrame, p: dict, _fam=fam, _tf=tf):
        a = s.attrs
        if "sym" not in a:
            raise RuntimeError("search strategies need data loaded by search.confirm (attrs missing)")
        side = _SIDE.get(a.get("token"), {})
        x = build_ctx(a["sym"], a["cls"], _tf, s, side.get("uni", {}), side.get("specs", {}), a["venue"],
                      min_bars=0, block_times=side.get("block_times"))
        sig, sd, tg, exl, exs, mh = FAMILIES[_fam]["fn"](x, p)
        sig = np.where(np.isfinite(sd) & (sd > 0), sig, 0).astype(np.int8)
        if a.get("trade_from") is not None:
            sig = np.where(s.index >= pd.Timestamp(a["trade_from"]), sig, 0).astype(np.int8)
        if side.get("allowed_days") is not None:              # ex-ante day filter (further(): test C)
            days = s.index.values.astype("datetime64[D]")
            sig = np.where(np.isin(days, side["allowed_days"]), sig, 0).astype(np.int8)
        # levels exist only where a trade can start (elsewhere they are half-formed, e.g. an opening
        # range still building - harmless, but the lookahead check would rightly see them change)
        sd = np.where(sig != 0, sd, np.nan)
        tg = np.where(sig != 0, tg, np.nan)
        return pd.DataFrame({"entry": sig, "stop_dist": sd, "target_dist": tg, "exit_long": exl,
                             "exit_short": exs}, index=s.index)

    fn.__name__ = f"search_{fam}"
    hold = {"ibs": 1, "rsi2d": 10, "tom": params.get("hold", 0)}.get(fam, 0)
    if fam == "hks":
        hold = 30 // dmod.tf_minutes(tf)
    if fam == "sessdrift":
        w0, w1 = SD_WINDOWS[params["window"]]
        hold = (w1 - w0) // dmod.tf_minutes(tf)
    exits = engine.Exits(max_bars=hold + 1 if hold else None, exit_on_signal=True, broker_stops=True)
    st = engine.Strategy(name=name, fn=fn, timeframe=tf, params=dict(params), exits=exits, mode="event",
                         direction="both", tz="UTC", session=None, weekdays_only=False,
                         grid={k: v for k, v in F["grid"].items() if len(v) > 1}, instruments=insts,
                         source="mt5", venue="ftmo", description=f"search finalist: {fam} {tf} {params}",
                         null_match="month" if F["clock"] else "hour", flat_map={} if F["flat"] else None)
    st.search_family = fam
    engine.REGISTRY[name] = st
    return st


def confirm_data(st, members: List[Tuple[str, str, str]], start, end, light: bool):
    """data_override for the engine: signal bars with warm-up history, execution bars from `start`."""
    uni, specs = _uni(), dmod.mt5_specs()
    out = {}
    fam = st.search_family
    for src, sym, cls in members:
        inst = f"{src}:{sym}"
        lo = pd.Timestamp(start) - pd.Timedelta(days=WARMUP_DAYS)
        if st.timeframe == "D1":
            sig = bars(src, sym, "D1", lo, end)
            exe = bars(src, sym, "M5", start, end) if not light else None
            if exe is None or not len(exe):
                exe = sig[sig.index >= pd.Timestamp(start)] if sig is not None else None
                if exe is not None:
                    exe = exe.assign(dur_min=1440.0)
            else:
                exe = exe.assign(dur_min=5.0)
        else:
            sig = bars(src, sym, st.timeframe, lo, end)
            exe = None
            if not light:
                one = _read_range(src, sym, "M1", start, end)
                if one is not None and len(one) > 1000:
                    one = dmod.repair(one, "M1")[0]
                    m5 = bars(src, sym, "M5", start, end)
                    pre = m5[m5.index < one.index[0]] if m5 is not None else None
                    exe = pd.concat([pre.assign(dur_min=5.0), one.assign(dur_min=1.0)]) \
                        if pre is not None and len(pre) else one.assign(dur_min=1.0)
            if exe is None:
                exe = bars(src, sym, "M5", start, end)
                exe = exe.assign(dur_min=5.0) if exe is not None else None
        if sig is None or exe is None or len(sig) < 100 or len(exe) < 100:
            continue
        exe = exe[exe.index >= pd.Timestamp(start)]
        venue = "alpaca" if src == "alpaca" else "ftmo"
        bt = None
        if st.timeframe != "D1":
            bt = sig.index.values.astype("datetime64[ns]")[gap_block(sig.index, dmod.tf_minutes(st.timeframe))]
        token = f"{st.name}|{inst}"
        _SIDE[token] = dict(uni=uni, specs=specs, block_times=bt)       # attrs hold plain strings only
        sig.attrs = dict(sym=sym, cls=cls, venue=venue, trade_from=str(pd.Timestamp(start)), token=token)
        meta = dict(dmod.read_meta(src, sym, "M5") or dmod.read_meta(src, sym, "D1"), symbol=sym,
                    price_type="bid" if src == "mt5" else "trade", exec_tf="M1" if (exe["dur_min"] == 1).any() else
                    ("M5" if (exe["dur_min"] == 5).any() else "D1"), vault_start=str(dmod.vault_start()))
        out[inst] = (sig, exe, meta)
        if st.flat_map is not None:
            tz, _, sc = SESSIONS[session_key(sym, cls, uni)]
            st.flat_map[inst] = (sc, tz)
    return out


def _members(row) -> List[Tuple[str, str, str]]:
    """What a finalist is confirmed on: always the FTMO CFDs themselves. An Alpaca proxy's finalist is
    confirmed on its FTMO twin; a class finalist on EVERY FTMO instrument of the class."""
    uni = _uni()
    if row["level"] == "instrument":
        if row["src"] == "alpaca":
            twin = proxy_twin("alpaca", row["sym"], uni)
            if twin:
                return [("mt5", twin, row["cls"])]
        return [(row["src"], row["sym"], row["cls"])]
    got = universe([row["cls"]], sources=("mt5",))
    if got:
        return got
    out = []
    for m in str(row["symbols"]).split():
        src, sym = m.split(":", 1)
        tw = proxy_twin(src, sym, uni) if src == "alpaca" else sym
        out.append(("mt5", tw, row["cls"]) if tw else (src, sym, row["cls"]))
    return out


def confirm(ids: Optional[List[str]] = None, final: bool = False, prop_too: bool = False) -> pd.DataFrame:
    """Every finalist on data discovery never saw. Two passes: first each finalist's Sharpe on the new
    period (for the deflation), then the full verdict deflated for ALL finalists."""
    import engine
    import lab
    import stats
    fin = pd.read_csv(OUT / "finalists.csv")
    if ids:
        fin = fin[fin["id"].isin(ids)]
    end = None if final else dmod.vault_start()
    start = CONFIRM_START
    plan = []
    for row in fin.to_dict("records"):
        params = json.loads(row["params"])
        members = _members(row)
        name = f"S{row['id']}_{row['fam']}_{row['tf']}"
        insts = [f"{s}:{y}" for s, y, _ in members]
        plan.append((row, params, members, name, insts))
    print(f"confirmation: {len(plan)} finalists, {start.date()} -> {'today (VAULT OPEN)' if final else str(end.date())}")
    srs, pvals = {}, {}
    for row, params, members, name, insts in plan:                       # pass 1: Sharpe on new data
        st = make_strategy(row["fam"], row["tf"], params, name, insts)
        dov = confirm_data(st, members, start, end, light=True)
        if not dov:
            continue
        try:
            r = engine.run(st, instruments=list(dov), source="mt5", venue="ftmo", params=params, final=final,
                           data_override=dov)
        except RuntimeError:
            continue
        x = stats.daily_series(r).to_numpy()
        srs[name] = float(x.mean() / x.std(ddof=1)) if len(x) > 2 and x.std() > 0 else 0.0
        sk, ku = stats.moments(x) if len(x) > 2 else (0.0, 3.0)
        pvals[name] = 1 - stats.psr(srs[name], len(x), sk, ku, 0.0)
        print(f"  pass 1 {name}: {len(r.trades)} trades, Sharpe {stats.sharpe(x):.2f}, p {pvals[name]:.4f}",
              flush=True)
    alpha_bh, n_disc = bh_level(list(pvals.values()), FDR_Q, n_total=len(plan))
    print(f"\n  false-discovery control (Benjamini-Hochberg, q={FDR_Q:.0%}) over {len(plan)} finalists: "
          f"{n_disc} pass at p <= {alpha_bh:.4f}\n")
    trials = (1, 0.0)
    rows = []
    cdir = OUT / ("final" if final else "confirm")
    cdir.mkdir(parents=True, exist_ok=True)
    for row, params, members, name, insts in plan:                       # pass 2: full verdict
        if name not in srs:
            rows.append(dict(id=row["id"], name=name, verdict="NO DATA"))
            continue
        st = engine.REGISTRY[name]
        dov = confirm_data(st, members, start, end, light=len(members) > 8)
        res = lab.evaluate(name, list(dov), "mt5", "ftmo", params, final=final, data_override=dov,
                           trials_override=trials, kind="final" if final else "confirm", do_prop=prop_too,
                           out_dir=cdir, alpha=alpha_bh)
        a, run_ = res["assessment"], res["run"]
        tm = a.core.get("timing") or {}
        t = run_.trades
        rows.append(dict(id=row["id"], name=name, level=row["level"], fam=row["fam"], tf=row["tf"],
                         params=row["params"], instruments=" ".join(insts) if len(insts) <= 6 else f"{len(insts)} {row['cls']}",
                         trades=len(t), sharpe=a.core.get("sharpe"), mean_r=a.core.get("mean_r"),
                         pf=float(t.loc[t.r_net > 0, "r_net"].sum() / -t.loc[t.r_net < 0, "r_net"].sum())
                         if (t.r_net < 0).any() else np.nan,
                         p=1 - a.core.get("dsr", 0.5), p_needed=alpha_bh, timing_p=tm.get("p"), verdict=a.verdict,
                         disc_sharpe=row.get("sharpe"), report=str(res["path"])))
    out = pd.DataFrame(rows)
    out.to_csv(OUT / ("final.csv" if final else "confirmation.csv"), index=False)
    print("\n" + out.drop(columns=["report"], errors="ignore").to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    return out


FDR_Q = 0.10        # pre-registered: at most ~10% of the finalists called real are expected to be luck


def bh_level(pvals: List[float], q: float, n_total: Optional[int] = None) -> Tuple[float, int]:
    """Benjamini-Hochberg: the p-value level that keeps the expected share of false discoveries <= q.
    With nothing passing, the level is q/N (the strictest), so no finalist gets a free pass."""
    p = np.sort(np.asarray([v for v in pvals if v == v], float))
    n = max(len(p), n_total or 0)
    if n == 0:
        return q, 0
    ok = np.flatnonzero(p <= q * np.arange(1, len(p) + 1) / n)
    if not len(ok):
        return q / n, 0
    k = int(ok[-1]) + 1
    return q * k / n, k


def status() -> None:
    for f in ("discovery_meta.json", "discovery.csv", "finalists.csv", "confirmation.csv", "final.csv"):
        p = OUT / f
        if p.exists():
            info = f"{pd.Timestamp(p.stat().st_mtime, unit='s'):%Y-%m-%d %H:%M}"
            if f.endswith(".csv"):
                info += f", {sum(1 for _ in p.open(encoding='utf-8')) - 1:,} rows"
            print(f"  {f:<22} {info}")
        else:
            print(f"  {f:<22} not yet")
    u = universe()
    print(f"\n  instruments cached: {len(u)}  (" + ", ".join(
        f"{c} {sum(1 for x in u if x[2] == c)}" for c in sorted({x[2] for x in u})) + ")")
    print(f"  configurations per instrument: up to {n_configs()}")



# ------------------------------------------------------------------ further
FURTHER_PROTOCOL = """
Follow-up tests for what the confirmation called real - fixed 6 Oct 2026 after the confirmation and
BEFORE any of these ran:
  going forward  EDGE verdicts + LEANS YES that beat random entries (timing p < 0.05) - the _passed() rule
                 written before confirmation ran. Watch list: INSUFFICIENT DATA with Sharpe >= 0.5 and
                 timing p < 0.05 (too few trades to judge; tested, never put in the portfolio).
  A  cross-source  the same rules on Alpaca's prices for the same market, 2022 -> vault date, FTMO costs.
                   Catches a result that only exists in one broker's price feed.
  B  vault         each strategy on the vault year alone (vault date -> today), and 2022 -> today
                   combined with false-discovery control across the strategies going forward.
  C  breadth       the best volatility-breakout and best noise-area settings on EVERY FTMO US stock CFD,
                   traded only on days the stock's trailing 60-session average range ranks in the top 20%
                   of the universe (known before the day starts). Vault year only - the one period this
                   idea has not seen.
  portfolio      one setting per (family, instrument): the highest confirmation Sharpe; kept only if its
                 combined 2022 -> today result still passes AND its vault-year mean is above zero.
"""


def _range_ranks(members: List[Tuple[str, str, str]], start, end, lookback: int = 60) -> pd.DataFrame:
    """Per US-session day and stock: percentile of the trailing `lookback`-session average range
    ((high - low) / open), using only sessions BEFORE that day."""
    cols = {}
    for src, sym, cls in members:
        m5 = bars(src, sym, "M5", pd.Timestamp(start) - pd.Timedelta(days=WARMUP_DAYS), end)
        if m5 is None or len(m5) < 500:
            continue
        ny = m5.index.tz_localize("UTC").tz_convert("America/New_York").tz_localize(None)
        mins = ny.hour * 60 + ny.minute
        sess = (mins >= 570) & (mins < 960) & (ny.dayofweek < 5)
        g = m5[sess].groupby(pd.DatetimeIndex(ny[sess]).normalize())
        rng = (g["high"].max() - g["low"].min()) / g["open"].first()
        cols[f"{src}:{sym}"] = rng.rolling(lookback, min_periods=lookback // 2).mean().shift(1)
    tab = pd.DataFrame(cols)
    return tab.rank(axis=1, pct=True)


def further(ids: Optional[List[str]] = None, vol_top: float = 0.2) -> pd.DataFrame:
    import engine
    import lab
    import stats
    print(FURTHER_PROTOCOL)
    conf = pd.read_csv(OUT / "confirmation.csv")
    chosen = list(ids) if ids else list(_passed(conf)["id"])
    w = conf[(conf["verdict"] == "INSUFFICIENT DATA") & (conf["sharpe"] >= 0.5) & (conf["timing_p"] < 0.05)]
    watch = [i for i in w["id"] if i not in chosen]
    fin = pd.read_csv(OUT / "finalists.csv").set_index("id")
    vs = dmod.vault_start()
    fdir = OUT / "further"
    fdir.mkdir(parents=True, exist_ok=True)
    uni = _uni()
    rows = []

    def one(test, fid, members, start, end, final, extra=None, label=None):
        row = fin.loc[fid].to_dict()
        params = json.loads(row["params"])
        name = f"S{fid}_{row['fam']}_{row['tf']}_{test}"
        st = make_strategy(row["fam"], row["tf"], params, name, [f"{a}:{b}" for a, b, _ in members])
        dov = confirm_data(st, members, start, end, light=len(members) > 8)
        if not dov:
            rows.append(dict(test=test, id=fid, note="no data"))
            return
        if extra:
            for inst in dov:
                _SIDE[f"{st.name}|{inst}"].update(extra(inst))
        res = lab.evaluate(name, list(dov), "mt5", "ftmo", params, final=final, data_override=dov,
                           trials_override=(1, 0.0), kind=f"further-{test}", do_prop=False, out_dir=fdir,
                           fast=True, quiet=True)
        a, r = res["assessment"], res["run"]
        t = r.trades
        tm = a.core.get("timing") or {}
        x = stats.daily_series(r).to_numpy()
        rows.append(dict(test=test, id=fid, fam=row["fam"], params=row["params"], what=label or
                         " ".join(dov), period=f"{r.period[0]:%Y-%m-%d}..{r.period[1]:%Y-%m-%d}", trades=len(t),
                         mean_r=float(t["r_net"].mean()) if len(t) else np.nan, sharpe=stats.sharpe(x),
                         timing_p=tm.get("p"), verdict=a.verdict, report=str(res["path"])))
        rr = rows[-1]
        print(f"  {test} {fid} {row['fam']:<6} {rr['what'][:40]:<40} {rr['trades']:>5} trades  mean "
              f"{rr['mean_r']:+.3f}R  Sharpe {rr['sharpe']:+.2f}  vs random p {rr['timing_p'] if rr['timing_p'] is not None else float('nan'):.3f}  "
              f"{a.verdict}", flush=True)

    print(f"going forward: {', '.join(chosen)}   watch list: {', '.join(watch) or '-'}\n")
    # ---- A: cross-source
    print("A  cross-source (Alpaca prices, 2022 -> vault date)")
    stock_c = catalog.VENUES["ftmo"]["by_class"]
    for fid in chosen:
        row = fin.loc[fid]
        sym = proxy_twin("alpaca", row["sym"], uni) if row["src"] == "alpaca" else row["sym"]
        alp = row["sym"] if row["src"] == "alpaca" else next((k for k, v in PROXIES.items() if v[1] == sym),
                                                            dmod.us_ticker(sym))
        if row["level"] != "instrument" or not dmod.read_meta("alpaca", alp, "M5" if row["tf"] != "D1" else "D1"):
            rows.append(dict(test="A", id=fid, note="no Alpaca twin"))
            continue
        # Alpaca has trade prices, no spread: charge the FTMO twin's own median spread (last 2 years)
        tw = _read_range("mt5", sym, "M5", vs - pd.Timedelta(days=730), vs)
        med = float(np.nanmedian(tw["spread_bp"][tw["spread_bp"] > 0])) if tw is not None and len(tw) and \
            (tw["spread_bp"] > 0).any() else np.nan
        if not np.isfinite(med):                       # no spread recorded for the twin: the class default
            med = float(stock_c.get(row["cls"], stock_c["other"])["spread_bp"])
        catalog.VENUE_OVERRIDES.setdefault("ftmo", {})[f"alpaca:{alp}"] = dict(
            spread_bp=med, commission_bp=stock_c.get(row["cls"], stock_c["other"])["commission_bp"])
        one("A", fid, [("alpaca", alp, row["cls"])], CONFIRM_START, vs, False, label=f"alpaca:{alp} ({med:.1f}bp)")
    # ---- B: vault year alone, then 2022 -> today with FDR control
    print("\nB  vault year alone (" + str(vs.date()) + " -> today)")
    for fid in chosen + watch:
        one("B", fid, _members(dict(fin.loc[fid].to_dict(), id=fid)), vs, None, True)
    print("\nB  2022 -> today, false-discovery control across the strategies going forward")
    confirm(chosen, final=True, prop_too=False)
    # ---- C: breadth with the ex-ante volatility rule, vault year
    print(f"\nC  every FTMO US stock, only days in the top {vol_top:.0%} by trailing range (vault year)")
    stocks = [(a, b, c) for a, b, c in universe(["stock"], sources=("mt5",))
              if (uni.get(b) or {}).get("profit", "USD") == "USD"]
    ranks = _range_ranks(stocks, vs, None)
    allowed = {k: ranks.index[ranks[k] >= 1 - vol_top].values.astype("datetime64[D]") for k in ranks.columns}
    best = {}
    for fid in chosen:
        r = fin.loc[fid]
        if r["fam"] in ("volbo", "noise") and r["cls"] == "stock":
            c = conf.set_index("id").loc[fid, "sharpe"]
            if r["fam"] not in best or c > best[r["fam"]][1]:
                best[r["fam"]] = (fid, c)
    for fam, (fid, _) in best.items():
        one("C", fid, stocks, vs, None, True, extra=lambda inst: dict(allowed_days=allowed.get(inst, np.array(
            [], "datetime64[D]"))), label=f"{len(stocks)} US stocks, top {vol_top:.0%} range days")
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "further.csv", index=False)
    print("\n" + out.drop(columns=["report"], errors="ignore").to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\nnext: python lab.py search report --final")
    return out


# ------------------------------------------------------------------- report
RISKS = [0.0025, 0.005, 0.0075, 0.01]


def _passed(tab: pd.DataFrame) -> pd.DataFrame:
    """Finalists the confirmation called real: an EDGE verdict, or LEANS YES that beat random timing."""
    v = tab["verdict"].astype(str)
    keep = v.str.startswith("EDGE") | (v.eq("INCONCLUSIVE - LEANS YES") & (tab["timing_p"] < 0.05))
    return tab[keep]


def portfolio_runs(ids: List[str], final: bool):
    """Each chosen finalist through the engine on all data discovery never saw (to the vault date, or to
    today with final=True), then combined as one account at 1R per trade per strategy."""
    import engine
    fin = pd.read_csv(OUT / "finalists.csv").set_index("id")
    end = None if final else dmod.vault_start()
    runs, trades, markets = {}, [], {}
    for fid in ids:
        row = fin.loc[fid].to_dict()
        row["id"] = fid
        params = json.loads(row["params"])
        members = _members(row)
        name = f"S{fid}_{row['fam']}_{row['tf']}"
        st = make_strategy(row["fam"], row["tf"], params, name, [f"{s}:{y}" for s, y, _ in members])
        dov = confirm_data(st, members, CONFIRM_START, end, light=len(members) > 8)
        r = engine.run(st, instruments=list(dov), source="mt5", venue="ftmo", params=params, final=final,
                       data_override=dov)
        runs[fid] = (row, r)
        t = r.trades.copy()
        t["strategy"] = fid
        t["inst"] = fid + "|" + t["inst"]
        trades.append(t)
        for k, mk in r.markets.items():
            markets[f"{fid}|{k}"] = mk
    allt = engine.fix_types(pd.concat(trades, ignore_index=True)).sort_values("entry_time").reset_index(drop=True)
    daily = engine.equity_by_day(allt, markets)
    return runs, allt, daily


def _family_rules(fam: str, tf: str, params: dict) -> str:
    doc = " ".join((FAMILIES[fam]["fn"].__doc__ or fam).split())
    kind = FAMILIES[fam]["kind"]
    tail = ("Flat at the end of each instrument's main session; no overnight positions."
            if FAMILIES[fam]["flat"] else ("Holds overnight/over weekends (daily bars)." if kind == "swing"
                                           else "Fixed holding window, no overnight positions."))
    return f"{doc} Signal bars {tf}; settings {json.dumps(params)}. {tail}"


def write_report(ids: Optional[List[str]] = None, final: bool = False, risk: Optional[float] = None,
                 paths: int = 1500) -> Path:
    import report as rp
    import prop
    import stats
    if final and not ids and not ((OUT / "final.csv").exists() and (OUT / "further.csv").exists()):
        print("the follow-up tests haven't run yet - running `search further` first (20-40 min) ...")
        further()
    src = OUT / ("final.csv" if final else "confirmation.csv")
    if not src.exists():
        raise SystemExit(f"{src.name} not found - run `python lab.py search {'further' if final else 'confirm'}` first")
    conf = pd.read_csv(src)
    chosen = conf[conf["id"].isin(ids)] if ids else _passed(conf)
    if final and not ids and (OUT / "further.csv").exists():
        # portfolio rule (FURTHER_PROTOCOL): vault-year mean above zero, one setting per (family, instrument)
        fu = pd.read_csv(OUT / "further.csv")
        vault = fu[fu["test"] == "B"].set_index("id")["mean_r"]
        chosen = chosen[chosen["id"].map(lambda i: vault.get(i, -1) > 0)]
        cs = pd.read_csv(OUT / "confirmation.csv").set_index("id")["sharpe"]
        chosen = chosen.assign(_cs=chosen["id"].map(cs), _key=chosen["fam"] + "|" + chosen["instruments"].astype(str))
        chosen = chosen.sort_values("_cs", ascending=False).groupby("_key").head(1).drop(columns=["_cs", "_key"])
    if chosen.empty:
        raise SystemExit("no confirmed strategy to report - pass --ids to report specific finalists")
    ids = list(chosen["id"])
    runs, t, daily = portfolio_runs(ids, final)
    # daily R on every business day (combined account, 1R per trade per strategy)
    bd = prop.business_days(daily)
    dr = (bd["end_eq"] - bd["end_eq"].shift(1).fillna(0.0)).astype(float)
    swing = any(FAMILIES[r[0]["fam"]]["kind"] == "swing" for r in runs.values())
    insts = sorted({k.split("|", 1)[1] for k in t["inst"].unique()})
    fut_ok = (not swing) and all(catalog.futures_twin(i) for i in insts)
    progs = [n for n, P in catalog.PROGRAMS.items() if (P["swing_ok"] or not swing) and (P["cls"] == "cfd" or fut_ok)]
    ptab = prop.firm_table(daily, RISKS, programs=progs, paths=paths)
    best = ptab.sort_values("net/yr", ascending=False).groupby("program").head(1).sort_values("per month (max alloc)",
                                                                                               ascending=False)
    if risk is None:                          # the risk the FTMO 2-Step model pays best at (or the top program's)
        f = best[best.program.str.startswith("FTMO 2-Step")]
        risk = float((f if len(f) else best).iloc[0]["risk"]) if len(best) else 0.005
    R = t["r_net"].to_numpy()
    yr = t.assign(y=pd.DatetimeIndex(t["exit_time"]).year).groupby("y")["r_net"].agg(["sum", "size", "mean"])
    eq = np.cumsum(dr.to_numpy())
    low = (bd["min_eq"]).to_numpy()
    peak = np.maximum.accumulate(np.r_[0.0, eq])[1:]
    dd_r = float(np.max(peak - np.minimum(eq, low)))
    sr = stats.sharpe(dr.to_numpy())
    pf = float(R[R > 0].sum() / -R[R < 0].sum()) if (R < 0).any() else np.inf
    months = len(bd) / 21
    head = dict(trades=len(t), per_month=len(t) / months, win=float((R > 0).mean()), mean_r=float(R.mean()),
                sharpe=sr, pf=pf, dd_r=dd_r, best_r=float(R.max()), worst_r=float(R.min()),
                best_day=float(dr.max()), worst_day=float(dr.min()), years=months / 12)
    # ---------------------------------------------------------------- HTML
    title = f"Strategy report - {'vault included' if final else 'confirmation period'}"
    period = f"{pd.Timestamp(bd.index[0]).date()} to {pd.Timestamp(bd.index[-1]).date()}"
    P = [f"<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport "
         f"content='width=device-width,initial-scale=1'><title>Strategy report</title><style>{rp.CSS}</style></head>"
         f"<body><main><h1>{title}</h1><p class=sub>{len(ids)} strateg{'y' if len(ids) == 1 else 'ies'} on "
         f"{len(insts)} FTMO instrument{'s' if len(insts) != 1 else ''}, {period} - data the search never used to "
         f"choose them. Sized at {risk:.2%} of the account per trade (1R).</p>"]
    P.append('<div class="stats">' + "".join([
        rp._stat("Return per year", f"{dr.mean() * 252 * risk:+.1%}", f"annualised over {months / 12:.1f} years"),
        rp._stat("Sharpe (annual)", f"{sr:.2f}", "daily, combined account"),
        rp._stat("Profit factor", f"{pf:.2f}", f"{head['win']:.0%} winners"),
        rp._stat("Max drawdown", f"{dd_r * risk:.1%}", f"{dd_r:.1f}R incl. open trades"),
        rp._stat("Biggest win", f"{head['best_r'] * risk:+.2%}", f"{head['best_r']:+.2f}R one trade"),
        rp._stat("Biggest loss", f"{head['worst_r'] * risk:+.2%}", f"{head['worst_r']:+.2f}R one trade"),
        rp._stat("Worst day", f"{head['worst_day'] * risk:+.2%}", f"best day {head['best_day'] * risk:+.2%}"),
        rp._stat("Trades", f"{head['trades']:,}", f"{head['per_month']:.0f} per month")]) + "</div>")
    P.append(rp.line_chart(pd.DatetimeIndex(bd.index), {"account %": eq * risk * 100}, f"Cumulative return, % of "
                           f"account at {risk:.2%} per trade (no compounding: prop profits are withdrawn)"))
    P.append(rp.bar_chart([str(y) for y in yr.index], (yr["sum"] * risk * 100).to_numpy(), "Return by calendar year, %",
                          unit="%"))
    yt = pd.DataFrame({"trades": yr["size"], "return %": yr["sum"] * risk * 100, "R": yr["sum"],
                       "mean R/trade": yr["mean"]})
    yt.index.name = "year"
    P.append("<h2>Year by year</h2>" + rp._table(yt, "{:.2f}"))
    mon = dr.groupby(pd.DatetimeIndex(dr.index).to_period("M")).sum() * risk * 100
    mt = mon.to_frame("p").assign(y=mon.index.year, m=mon.index.month).pivot(index="y", columns="m", values="p")
    mt.columns = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][: len(mt.columns)] \
        if len(mt.columns) == 12 else [str(c) for c in mt.columns]
    mt.index.name = "month %"
    P.append("<h2>Month by month (% of account)</h2>" + rp._table(mt, "{:+.1f}"))
    # prop income
    P.append("<h2>What it would pay at each prop firm (12 months, live rules)</h2>"
             "<p class=note>Full account lifecycle, 1,500 replays of this history in 10-day blocks: buy the evaluation, "
             "pass or fail (and buy again), trade funded, paid on the firm's schedule with its split, caps, "
             "consistency rules and fee refund; a breach means starting over. Net = payouts minus every fee. "
             "'Zero-edge twin' is the same history with the average profit removed - what the rules alone would pay "
             "a coin flip. 'Max allocation' = as many identical accounts as the firm allows one person (they all win "
             "or lose together). Programs that don't allow this strategy's holding period are left out.</p>")
    P.append(rp._table(_fmt_prop(best).set_index("program")))
    P.append("<details><summary>every program at every risk level</summary>" +
             rp._table(_fmt_prop(ptab).set_index("program")) + "</details>")
    notes = "".join(f"<li><b>{html_escape(n)}</b>: {html_escape(catalog.PROGRAMS[n].get('note', ''))} "
                    f"<span class=note>({html_escape(catalog.PROGRAMS[n].get('src', ''))})</span></li>"
                    for n in best["program"])
    P.append(f"<ul class=note>{notes}</ul>")
    # strategies, rules, instruments
    P.append("<h2>The strategies and their exact rules</h2>")
    for fid, (row, r) in runs.items():
        cr = chosen[chosen["id"] == fid].iloc[0]
        tt = r.trades
        P.append(f'<div class=card><b>{fid} - {row["fam"]} {row["tf"]}</b> &nbsp; <span class=note>'
                 f'{html_escape(str(cr["verdict"]))}, Sharpe {cr["sharpe"]:.2f}, p {cr.get("p", np.nan):.4f}, '
                 f'beats random entries p {cr.get("timing_p", np.nan):.3f}</span>'
                 f'<p>{html_escape(_family_rules(row["fam"], row["tf"], json.loads(row["params"])))}</p>')
        rows = []
        for inst, g in tt.groupby("inst"):
            sym = inst.split(":", 1)[-1]
            tz, so, sc = SESSIONS[session_key(sym, row["cls"], _uni())]
            rows.append(dict(instrument=sym, cme_future=catalog.futures_twin(sym) or "-", session=f"{so}-{sc} {tz}",
                             trades=len(g), mean_r=g["r_net"].mean(), win=(g["r_net"] > 0).mean(),
                             long_share=(g["dir"] > 0).mean()))
        P.append(rp._table(pd.DataFrame(rows).set_index("instrument"), "{:.3f}") + "</div>")
    P.append("<h2>How these were found (and why it isn't curve-fitting)</h2><p class=note>" + html_escape(
        " ".join((__doc__ or "").split("PROTOCOL", 1)[-1].split())) + "</p>")
    P.append(f"<script>{rp.JS}</script></main></body></html>")
    out = OUT / f"report_{'final' if final else 'confirm'}_{pd.Timestamp.now():%Y%m%d-%H%M}.html"
    out.write_text("".join(P), encoding="utf-8")
    ptab.to_csv(OUT / "prop_income.csv", index=False)
    print(f"report: {out}")
    print(best[["program", "risk", "per month (max alloc)", "net/yr", "P(loss)", "twin net/yr"]].to_string(
        index=False, float_format=lambda v: f"{v:,.2f}"))
    return out


def _fmt_prop(tab: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({"program": tab["program"], "risk/trade": tab["risk"].map(lambda v: f"{v:.2%}")})
    money = ["per month (max alloc)", "net/yr", "median/yr", "p10", "p90", "twin net/yr", "edge adds/yr", "fees"]
    for c in ["per month (max alloc)", "accounts", "net/yr", "median/yr", "p10", "p90", "P(loss)", "twin net/yr",
              "edge adds/yr", "funded", "payouts", "first pay (mo)", "evals bought", "fees"]:
        if c not in tab:
            continue
        if c in money:
            out[c] = tab[c].map(lambda v: f"${v:,.0f}")
        elif c in ("P(loss)", "funded"):
            out[c] = tab[c].map(lambda v: f"{v:.0%}")
        elif c == "accounts":
            out[c] = tab[c].map(lambda v: f"{int(v)}")
        else:
            out[c] = tab[c].map(lambda v: "-" if v != v else f"{v:.1f}")
    return out


def html_escape(s: str) -> str:
    import html as _h
    return _h.escape(str(s))
