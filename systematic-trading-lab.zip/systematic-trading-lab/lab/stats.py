"""
stats.py - the evidence, and the verdict built from it.

How the verdict is reached (fixed in advance, see catalog.RULES):

  1. HARD STOPS   lookahead in the signals, or broken data  -> BROKEN
                  too few trades / days                     -> INSUFFICIENT DATA
  2. IS IT REAL?  Deflated Sharpe Ratio >= 95%: the Sharpe is tested against the
                  best Sharpe you'd expect from LUCK given every variant of this
                  strategy you have ever run (from the registry). Near-identical
                  variants barely raise the bar; genuinely different ones do.
  3. IS IT TIMING? Each trade is compared with random entries on the same market,
                  same month, same hour, same direction, same exits. If random
                  entries make the same money, the profit is the market's drift
                  (BETA), not the signal.
  4. CAN WE RULE IT OUT?  NO EDGE only if the whole 95% interval of the Sharpe is
                  below a level worth trading. Otherwise it's INCONCLUSIVE and the
                  report says how much more data would settle it. A promising
                  strategy is never killed just for missing significance.
  5. IS IT ROBUST? Years, halves, decay, instruments, costs, fill assumptions,
                  parameter neighbours, outlier dependence, other data sources, the
                  vault. Each is PASS / WARN / FAIL. The verdict tolerates WARNs and
                  at most one FAIL - one bad-looking number never sinks it alone.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from statistics import NormalDist
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import catalog
import engine

N01 = NormalDist()
R = catalog.RULES
ANN = 261.0                       # weekdays a year


# --------------------------------------------------------------- daily series

def daily_series(run_: engine.Run) -> pd.Series:
    """P&L per weekday (R for event strategies, notional fraction for position
    strategies), zero on weekdays with nothing happening."""
    d = run_.daily.astype(float)
    lo, hi = run_.period
    days = pd.bdate_range(lo.normalize(), hi.normalize())
    if d.empty:
        return pd.Series(0.0, index=days)
    eq = d["end_eq"].reindex(days.union(d.index)).ffill().fillna(0.0)
    eq = eq.reindex(days)
    return eq.diff().fillna(eq.iloc[0])


def per_day_trades(trades: pd.DataFrame, days: pd.DatetimeIndex, col: str = "r_net"
                   ) -> Tuple[np.ndarray, np.ndarray]:
    """Sum and count of trade R by entry weekday, aligned to `days`."""
    if trades.empty:
        return np.zeros(len(days)), np.zeros(len(days))
    ed = pd.DatetimeIndex(trades["entry_time"]).normalize()
    pos = days.get_indexer(ed)
    # weekend entries (crypto) go to the next weekday
    miss = pos < 0
    if miss.any():
        pos[miss] = np.clip(days.searchsorted(ed[miss]), 0, len(days) - 1)
    S = np.bincount(pos, weights=trades[col].to_numpy(dtype=float), minlength=len(days))
    C = np.bincount(pos, minlength=len(days)).astype(float)
    return S, C


# ------------------------------------------------------------------ bootstrap

def stationary_idx(n: int, B: int, L: float, rng: np.random.Generator) -> np.ndarray:
    """Politis-Romano stationary bootstrap indices (B x n): blocks of random
    length (mean L) keep losing streaks and volatility clusters together."""
    idx = np.empty((B, n), dtype=np.int32)
    idx[:, 0] = rng.integers(0, n, B)
    new = rng.random((B, n)) < 1.0 / L
    starts = rng.integers(0, n, (B, n))
    for t in range(1, n):
        idx[:, t] = np.where(new[:, t], starts[:, t], (idx[:, t - 1] + 1) % n)
    return idx


def sharpe(x: np.ndarray) -> float:
    s = np.std(x, ddof=1)
    return float(np.mean(x) / s * math.sqrt(ANN)) if s > 0 else 0.0


def moments(x: np.ndarray) -> Tuple[float, float]:
    m, s = np.mean(x), np.std(x)
    if s == 0:
        return 0.0, 3.0
    z = (x - m) / s
    return float(np.mean(z ** 3)), float(np.mean(z ** 4))


def psr(sr_d: float, T: int, skew: float, kurt: float, sr0_d: float = 0.0) -> float:
    """Probabilistic Sharpe Ratio (Bailey & Lopez de Prado), per-period Sharpe."""
    den = 1 - skew * sr_d + (kurt - 1) / 4 * sr_d ** 2
    if T < 3 or den <= 0:
        return 0.5
    return N01.cdf((sr_d - sr0_d) * math.sqrt(T - 1) / math.sqrt(den))


def expected_max_sr(var_sr: float, n_trials: int) -> float:
    """Sharpe the best of n_trials would show by luck alone (per period)."""
    if n_trials <= 1 or var_sr <= 0:
        return 0.0
    g = 0.5772156649
    return math.sqrt(var_sr) * ((1 - g) * N01.inv_cdf(1 - 1 / n_trials)
                                + g * N01.inv_cdf(1 - 1 / (n_trials * math.e)))


# ------------------------------------------------------------------- checks

@dataclass
class Check:
    name: str
    status: str            # PASS / WARN / FAIL / INFO / N/A
    value: str
    detail: str = ""


@dataclass
class Assessment:
    verdict: str
    headline: str
    reasons: List[str]
    core: dict
    checks: List[Check]
    tables: Dict[str, pd.DataFrame]
    series: Dict[str, pd.Series]
    extra: dict = field(default_factory=dict)


def _status_count(checks: List[Check]) -> Tuple[int, int]:
    return (sum(c.status == "FAIL" for c in checks), sum(c.status == "WARN" for c in checks))


def trade_stats(t: pd.DataFrame, months: float) -> dict:
    r = t["r_net"].to_numpy()
    if len(r) == 0:
        return {}
    wins, losses = r[r > 0], r[r <= 0]
    streak = longest = 0
    for x in r:
        streak = streak + 1 if x <= 0 else 0
        longest = max(longest, streak)
    sk, ku = moments(r)
    gave_back = ((t["r_net"] <= 0) & (t["mfe_r"] >= 1.0)).mean()
    held = pd.to_timedelta(pd.DatetimeIndex(t["exit_time"]) - pd.DatetimeIndex(t["entry_time"]))
    return dict(trades=len(r), trades_per_month=len(r) / max(months, 1e-9), win_rate=float((r > 0).mean()),
                avg_win=float(wins.mean()) if len(wins) else 0.0, avg_loss=float(losses.mean()) if len(losses) else 0.0,
                payoff=float(wins.mean() / -losses.mean()) if len(wins) and len(losses) and losses.mean() < 0 else np.nan,
                profit_factor=float(wins.sum() / -losses.sum()) if losses.sum() < 0 else np.inf,
                mean_r=float(r.mean()), median_r=float(np.median(r)), sd_r=float(r.std(ddof=1)) if len(r) > 1 else 0.0,
                skew=sk, best=float(r.max()), worst=float(r.min()), max_losing_streak=longest,
                long_share=float((t["dir"] > 0).mean()), avg_bars=float(t["bars_held"].mean()),
                avg_hold_hours=float(np.asarray(held.total_seconds()).mean() / 3600) if len(held) else 0.0,
                exit_mix=t["reason"].value_counts(normalize=True).round(3).to_dict(),
                out_of_session_exits=float((~t["exit_in_session"].astype(bool)).mean()),
                gap_exits=float(t["reason"].str.startswith("gap").mean()),
                avg_nights=float(t["nights"].mean()),
                cost_spread_r=float(t["spread_r"].mean()), cost_comm_r=float(t["comm_r"].mean()),
                cost_slip_r=float(t["slip_r"].mean()), swap_r=float(t["swap_r"].mean()),
                gross_r=float(t["r_mid"].mean()), losers_that_were_up_1r=float(gave_back),
                ambiguous=float(t["ambiguous"].mean()))


def equity_stats(daily: pd.Series) -> dict:
    x = daily.to_numpy()
    eq = np.cumsum(x)
    peak = np.maximum.accumulate(np.r_[0.0, eq])[1:]
    dd = eq - peak
    under = dd < 0
    longest = cur = 0
    for u in under:
        cur = cur + 1 if u else 0
        longest = max(longest, cur)
    down = x[x < 0]
    yrs = len(x) / ANN
    weekly = daily.resample("W").sum()
    monthly = daily.resample("ME").sum()
    return dict(sharpe=sharpe(x),
                sortino=float(x.mean() / np.sqrt(np.mean(np.minimum(x, 0) ** 2)) * math.sqrt(ANN)) if len(down) else np.inf,
                total=float(eq[-1]) if len(eq) else 0.0, per_year=float(eq[-1] / yrs) if yrs > 0 and len(eq) else 0.0,
                max_dd=float(-dd.min()) if len(dd) else 0.0, longest_dd_days=int(longest),
                calmar=float((eq[-1] / yrs) / -dd.min()) if len(dd) and dd.min() < 0 and yrs > 0 else np.inf,
                worst_day=float(x.min()) if len(x) else 0.0, worst_week=float(weekly.min()) if len(weekly) else 0.0,
                worst_month=float(monthly.min()) if len(monthly) else 0.0,
                positive_months=float((monthly > 0).mean()) if len(monthly) else 0.0,
                ulcer=float(np.sqrt(np.mean(dd ** 2))) if len(dd) else 0.0, years=yrs)


# ---------------------------------------------------------------- assessment

def assess(run_: engine.Run, *, null: Optional[pd.DataFrame], lookahead: List[str],
           data_quality: Dict[str, dict], trials: Tuple[int, float], neighbours: Optional[pd.DataFrame] = None,
           cross: Optional[pd.DataFrame] = None, vault_start: Optional[pd.Timestamp] = None,
           vault_clean: bool = True, final: bool = False, seed: int = 11,
           alpha: Optional[float] = None) -> Assessment:
    """alpha: significance level for "is it real" (default RULES alpha with the Sharpe deflated for every
    variant tried). The search's confirmation stage passes a Benjamini-Hochberg level across its
    finalists instead, with no extra deflation."""
    alpha = R["alpha"] if alpha is None else alpha
    rng = np.random.default_rng(seed)
    t = run_.trades
    d = daily_series(run_)
    days = d.index
    x = d.to_numpy()
    T = len(x)
    months = T / ANN * 12
    unit = "R" if run_.strat.mode == "event" else "x notional"
    reasons: List[str] = []
    checks: List[Check] = []
    tables: Dict[str, pd.DataFrame] = {}
    core: dict = dict(unit=unit, days=T, years=T / ANN, trades=len(t))

    # ---------------------------------------------------- bootstrap everything once
    B, L = R["bootstrap"], R["block_days"]
    idx = stationary_idx(T, B, L, rng) if T > 5 else None
    S, C = per_day_trades(t, days)
    if idx is not None:
        bx = x[idx]
        bm, bs = bx.mean(axis=1), bx.std(axis=1, ddof=1)
        bsh = np.where(bs > 0, bm / np.where(bs > 0, bs, 1) * math.sqrt(ANN), 0.0)
        bS, bC = S[idx].sum(axis=1), C[idx].sum(axis=1)
        bmr = np.where(bC > 0, bS / np.where(bC > 0, bC, 1), np.nan)
    else:
        bsh = bmr = np.array([0.0])
    sr = sharpe(x)
    sr_lo, sr_hi = np.percentile(bsh, [2.5, 97.5])
    mean_r = float(t["r_net"].mean()) if len(t) else 0.0
    mr_lo, mr_hi = np.nanpercentile(bmr, [2.5, 97.5]) if len(t) else (0.0, 0.0)
    core.update(sharpe=sr, sharpe_ci=(float(sr_lo), float(sr_hi)), mean_r=mean_r,
                mean_r_ci=(float(mr_lo), float(mr_hi)),
                p_boot=float((bsh <= 0).mean()))

    # ------------------------------------------------- deflated Sharpe (trials)
    sk, ku = moments(x)
    sr_d = float(np.mean(x) / np.std(x, ddof=1)) if T > 2 and np.std(x) > 0 else 0.0
    n_trials, var_sr = trials
    sr0 = expected_max_sr(var_sr, n_trials)
    core.update(psr=psr(sr_d, T, sk, ku, 0.0), dsr=psr(sr_d, T, sk, ku, sr0), trials=n_trials,
                sr0_annual=sr0 * math.sqrt(ANN), skew_daily=sk, kurt_daily=ku)
    sig = core["dsr"] >= 1 - alpha
    core["alpha"] = alpha

    # ------------------------------------------------------- timing vs random
    timing = None
    if null is not None and len(null) and len(t):
        timing = timing_test(t, null, days, idx, rng)
        core["timing"] = timing
    elif run_.strat.mode == "position" and null is not None:
        pass
    if run_.strat.mode == "position" and "timing" in run_.info:
        timing = run_.info["timing"]
        core["timing"] = timing

    # ------------------------------------------------------- stats & tables
    core["trade"] = trade_stats(t, months) if len(t) else {}
    core["equity"] = equity_stats(d)
    if len(t):
        tt = t.assign(year=pd.DatetimeIndex(t["entry_time"]).year)
        tables["by_year"] = tt.groupby("year").agg(trades=("r_net", "size"), total_r=("r_net", "sum"),
                                                   mean_r=("r_net", "mean"),
                                                   win=("r_net", lambda v: (v > 0).mean())).round(3)
        ins = t.groupby("inst").agg(trades=("r_net", "size"), mean_r=("r_net", "mean"), total_r=("r_net", "sum"),
                                    win=("r_net", lambda v: (v > 0).mean()), swap_r=("swap_r", "mean"),
                                    spread_r=("spread_r", "mean"))
        ins["se"] = t.groupby("inst")["r_net"].std(ddof=1) / np.sqrt(ins["trades"])
        tables["by_instrument"] = ins.round(3)
        tables["by_weekday"] = t.groupby(pd.DatetimeIndex(t["entry_time"]).dayofweek)["r_net"].agg(
            ["size", "mean"]).rename(index=dict(enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]))).round(3)
        tables["by_hour_utc"] = t.groupby(pd.DatetimeIndex(t["entry_time"]).hour)["r_net"].agg(["size", "mean"]).round(3)
        if (t["dir"] < 0).any() and (t["dir"] > 0).any():
            tables["by_direction"] = t.groupby("dir")["r_net"].agg(["size", "mean"]).rename(
                index={1: "long", -1: "short"}).round(3)
        tables["by_exit"] = t.groupby("reason")["r_net"].agg(["size", "mean"]).round(3)
        mon = d.resample("ME").sum()
        tables["monthly"] = mon.to_frame("pnl").assign(year=mon.index.year, month=mon.index.month).pivot(
            index="year", columns="month", values="pnl").round(2)
        if run_.info.get("walk_forward"):
            tables["walk_forward"] = pd.DataFrame(run_.info["walk_forward"])

    # ------------------------------------------------------------ hard stops
    bad_data = {k: v for k, v in data_quality.items() if v.get("level") == "BAD"}
    if lookahead:
        verdict = "BROKEN"
        reasons = ["the signals use future data: " + lookahead[0]] + lookahead[1:3]
        return Assessment(verdict, "Lookahead bug - results are fake until fixed.", reasons, core,
                          checks, tables, dict(daily=d))
    if bad_data:
        reasons = [f"{k}: {'; '.join(v['issues'])}" for k, v in bad_data.items()]
        return Assessment("BROKEN", "Bad data - fix or drop it before trusting anything.", reasons, core,
                          checks, tables, dict(daily=d))

    # ------------------------------------------------------- robustness checks
    if len(t):
        t_rob = position_rows(run_) if run_.strat.mode == "position" else None
        checks += robustness(run_, t, d, days, idx, S, C, rng, neighbours, cross, vault_start, final, vault_clean,
                             t_rob)
    fails, warns = _status_count(checks)
    core["robust_fails"], core["robust_warns"] = fails, warns

    # ------------------------------------------------------------- the verdict
    need = more_data_needed(sr, core["sr0_annual"], T, len(t), alpha)
    core["need"] = need
    too_few = (len(t) < R["min_trades"]) if run_.strat.mode == "event" else False
    if too_few or T < R["min_days"]:
        verdict = "INSUFFICIENT DATA"
        headline = (f"{len(t)} trades over {T / ANN:.1f} years - need at least {R['min_trades']} trades and "
                    f"{R['min_days']} trading days before anything can be concluded.")
        reasons.append(_need_text(need))
    elif sig and timing is not None and timing["p"] >= R["timing_alpha"] and \
            timing["random"] >= 0.5 * timing["real"]:
        verdict = "BETA - NO TIMING EDGE"
        headline = ("It made money, but random entries in the same markets, months and hours made about the "
                    "same. The profit is the market's drift in this period, not the signal.")
        reasons.append(f"timing edge {timing['edge']:+.3f} {timing.get('unit', unit + ' per trade')} vs random, "
                       f"95% [{timing['lo']:+.3f}, {timing['hi']:+.3f}], p={timing['p']:.2f}")
    elif sig and timing is not None and timing["p"] >= R["timing_alpha"]:
        verdict = "INCONCLUSIVE - LEANS YES"
        headline = (f"The profit is significant (Sharpe {sr:.2f}), but beating random entries isn't proven yet "
                    f"(p={timing['p']:.2f}) - it could still be the market's drift. Not an edge until the "
                    f"timing is shown; more data or a forward test settles it.")
        reasons.append(f"random entries made {timing['random']:+.3f}{unit}/trade vs the strategy's "
                       f"{timing['real']:+.3f}{unit}")
    elif sig:
        failed = [c.name for c in checks if c.status == "FAIL"]
        warned = [c.name for c in checks if c.status == "WARN"]
        if fails == 0 and warns <= R["max_warns_conclusive"]:
            if final and vault_clean:
                verdict = "EDGE - CONCLUSIVE"
                headline = "Real, robust edge: significant after every variant tried, beats random timing, survives the vault."
            else:
                verdict = "EDGE - STRONG"
                headline = ("Significant, beats random timing, and robust. Last step: run once with --final to "
                            "check it on the vault (data it has never seen).")
        elif fails <= R["max_soft_fails"]:
            verdict = "EDGE - PROBABLE"
            headline = ("Significant and beats random timing, but not clean on every robustness check. "
                        "Forward-test it small before risking a challenge.")
        else:
            verdict = "FRAGILE"
            headline = ("Significant on the whole sample, but it fails several robustness checks - most likely "
                        "fitted to this history or to one regime.")
        if failed:
            reasons.append("failed: " + ", ".join(failed))
        if warned:
            reasons.append("warnings: " + ", ".join(warned))
    elif sr_hi < R["sharpe_min"]:
        verdict = "NO EDGE"
        headline = (f"Conclusive: even the optimistic end of the 95% range (Sharpe {sr_hi:.2f}) is below "
                    f"{R['sharpe_min']:.2f}, the minimum worth trading.")
        if timing is not None and timing["p"] < R["timing_alpha"] and timing["edge"] > 0:
            reasons.append("the signal does time entries better than random, but costs/exits leave nothing")
    elif sr >= R["sharpe_min"] and timing is not None and timing["p"] >= R["timing_alpha"] and \
            timing["random"] >= 0.5 * timing["real"] and timing["real"] > 0:
        verdict = "INCONCLUSIVE - LOOKS LIKE BETA"
        headline = (f"Positive (Sharpe {sr:.2f}) but not proven, and random entries in the same markets and hours "
                    f"made {timing['random'] / timing['real']:.0%} of the same profit - so far it looks like "
                    f"the market's drift, not the signal.")
        reasons.append(_need_text(need))
    elif sr >= R["sharpe_min"]:
        verdict = "INCONCLUSIVE - LEANS YES"
        headline = (f"Promising but not proven yet: Sharpe {sr:.2f} (95% {sr_lo:.2f} to {sr_hi:.2f}) is worth "
                    f"trading if it holds, but the sample can't yet separate it from luck.")
        reasons.append(_need_text(need))
    else:
        verdict = "INCONCLUSIVE - LEANS NO"
        headline = (f"Not ruled out only because the sample is noisy. The best estimate, Sharpe {sr:.2f} "
                    f"(95% {sr_lo:.2f} to {sr_hi:.2f}), is below the {R['sharpe_min']:.2f} worth trading.")
        reasons.append(_need_text(need, sr))
        if timing is not None and timing["p"] < R["timing_alpha"] and timing["edge"] > 0:
            reasons.append(f"encouraging: entries beat random timing (p={timing['p']:.3f})")
    if alpha != R["alpha"] and n_trials <= 1:
        reasons.insert(0, f"Sharpe {sr:.2f} [95% {sr_lo:.2f}, {sr_hi:.2f}]; confidence it is above zero "
                          f"{core['dsr']:.2%}, needs {1 - alpha:.2%} (false-discovery control across the "
                          f"candidates tested together)")
    else:
        reasons.insert(0, f"Sharpe {sr:.2f} [95% {sr_lo:.2f}, {sr_hi:.2f}]; deflated Sharpe {core['dsr']:.1%} "
                          f"({n_trials} variant{'s' if n_trials != 1 else ''} tried; luck alone would give "
                          f"{core['sr0_annual']:.2f})")
    if timing is not None:
        tu = timing.get("unit", f"{unit}/trade")
        reasons.insert(1, f"vs random {'timing' if timing.get('unit') else 'entries'}: {timing['edge']:+.3f}{tu} "
                          f"[{timing['lo']:+.3f}, {timing['hi']:+.3f}], p={timing['p']:.3f}")
    if run_.info.get("assumed"):
        hint = " - `fetch --source mt5` replaces them with real values" if run_.markets and \
            next(iter(run_.markets.values())).source == "mt5" else ""
        reasons.append(f"{len(run_.info['assumed'])} cost inputs are assumptions (listed in the report){hint}")
    return Assessment(verdict, headline, reasons, core, checks, tables, dict(daily=d))


def _need_text(need: dict, sr: Optional[float] = None) -> str:
    if need.get("years") is None:
        return "no positive edge to measure - more data won't turn this into one"
    if sr is not None and sr < R["sharpe_min"]:
        return (f"even if the estimate is exactly right, Sharpe {sr:.2f} is too small to be worth trading "
                f"(it would take ~{need['years']:,.0f} years of data just to confirm it)")
    if need["more_years"] <= 0:
        return "the sample is already big enough for an edge of this size to show"
    if need["more_years"] > 10:
        return (f"an edge this small takes ~{need['years']:,.0f} years of data to prove - too slow to wait for; "
                f"a forward test won't settle it either. Trade it only accepting it may be noise.")
    return (f"at this Sharpe, about {need['more_years']:.1f} more years of data (~{need['more_trades']:,} trades) "
            f"would settle it - or forward-test it")


def more_data_needed(sr: float, sr0: float, T: int, n_trades: int, alpha: Optional[float] = None) -> dict:
    """Years of data for the observed Sharpe to clear the deflated bar with
    80% power (Sharpe-test approximation)."""
    eff = sr - sr0
    if eff <= 0:
        return dict(years=None)
    za, zb = N01.inv_cdf(1 - (R["alpha"] if alpha is None else alpha)), N01.inv_cdf(R["power"])
    years = ((za + zb) / eff) ** 2
    have = T / ANN
    per_year = n_trades / have if have > 0 else 0
    return dict(years=years, more_years=max(0.0, years - have), more_trades=int(max(0.0, years - have) * per_year))


# --------------------------------------------------------------------- timing

def timing_test(t: pd.DataFrame, null: pd.DataFrame, days: pd.DatetimeIndex, idx: Optional[np.ndarray],
                rng: np.random.Generator) -> dict:
    t = t.copy()
    t["_id"] = np.arange(len(t))
    nm = null.groupby("of")["r_net"].mean()
    have = t.index.isin(nm.index)
    tt = t[have]
    m_i = nm.reindex(tt.index).to_numpy()
    r_i = tt["r_net"].to_numpy()
    edge_i = r_i - m_i
    # p: real mean vs means of random entries drawn one per real trade
    nn = null[null["of"].isin(tt.index)].sort_values("of")
    vals = nn["r_net"].to_numpy()
    ofs = nn["of"].to_numpy()
    order = {k: j for j, k in enumerate(tt.index)}
    starts = np.zeros(len(tt), dtype=np.int64)
    counts = np.zeros(len(tt), dtype=np.int64)
    u, first, cnt = np.unique(ofs, return_index=True, return_counts=True)
    for k, f, c in zip(u, first, cnt):
        starts[order[k]], counts[order[k]] = f, c
    Bp = 4000
    draws = starts[None, :] + (rng.random((Bp, len(tt))) * counts[None, :]).astype(np.int64)
    null_means = vals[draws].mean(axis=1)
    real = r_i.mean()
    p = (1 + (null_means >= real).sum()) / (Bp + 1)
    # CI of the per-trade edge, block-bootstrapped by day
    S, C = per_day_trades(tt.assign(edge=edge_i), days, "edge")
    if idx is not None:
        bS, bC = S[idx].sum(axis=1), C[idx].sum(axis=1)
        be = np.where(bC > 0, bS / np.where(bC > 0, bC, 1), np.nan)
        lo, hi = np.nanpercentile(be, [2.5, 97.5])
    else:
        lo = hi = float("nan")
    return dict(real=float(real), random=float(m_i.mean()), edge=float(edge_i.mean()), lo=float(lo), hi=float(hi),
                p=float(p), n=int(len(tt)), draws=int(len(vals)), null_means=null_means)


def position_timing(run_: engine.Run, draws: int = 200, seed: int = 5) -> dict:
    """Position strategies: shift each instrument's position series in time by a
    random offset. Exposure, holding periods and turnover stay identical; only
    the alignment with the market is broken."""
    rng = np.random.default_rng(seed)
    real = daily_series(run_).to_numpy()

    def total(shift_of):
        pnl = []
        for inst, mk in run_.markets.items():
            s, frame = run_.frames[inst]
            f2 = frame.copy()
            f2["pos"] = np.roll(frame["pos"].to_numpy(), shift_of(len(frame)))
            _, bp = engine.run_positions(mk, run_.strat, s, f2)
            pnl.append(bp)
        return float(pd.concat(pnl, axis=1).fillna(0.0).sum(axis=1).sum()) / max(1, len(real))
    real_mean = total(lambda n: 0)                     # same arithmetic as the shifted copies
    out = np.asarray([total(lambda n: int(rng.integers(min(20, n // 3), max(21, n - 20))))
                      for _ in range(draws)])
    tol = 1e-12 * max(1.0, abs(real_mean))
    p = (1 + (out >= real_mean - tol).sum()) / (draws + 1)
    sd = out.std(ddof=1) if len(out) > 1 else 0.0       # spread of the shifted copies = the noise
    edge = real_mean - out.mean()
    k = 1e4                                                 # report in bp of notional per day
    return dict(real=float(real_mean * k), random=float(out.mean() * k), edge=float(edge * k),
                lo=float((edge - 1.96 * sd) * k), hi=float((edge + 1.96 * sd) * k), p=float(p), n=len(real),
                draws=draws, null_means=out * k, unit="bp/day")


# ----------------------------------------------------------------- robustness

def position_rows(run_: engine.Run) -> pd.DataFrame:
    """Position strategies: one row per instrument per day (bp of notional), so the
    year / half / decay / breadth / outlier checks look at daily P&L."""
    rows = []
    for inst, bp in (run_.bar_pnl or {}).items():
        dly = bp.resample("D").sum()
        dly = dly[dly.index.dayofweek < 5]
        rows.append(pd.DataFrame({"inst": inst, "entry_time": dly.index, "exit_time": dly.index,
                                  "r_net": dly.to_numpy() * 1e4}))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["inst", "entry_time", "r_net"])


def robustness(run_, t, d, days, idx, S, C, rng, neighbours, cross, vault_start, final, vault_clean,
               t_rob: Optional[pd.DataFrame] = None) -> List[Check]:
    out: List[Check] = []
    unit = "R" if run_.strat.mode == "event" else "bp"
    t_trades = t
    if t_rob is not None and len(t_rob):
        t = t_rob
    n = len(t_trades)
    yrs = len(d) / ANN
    mean_all = t["r_net"].mean()

    # sample size
    if run_.strat.mode == "event":
        st = "PASS" if n >= R["good_trades"] and yrs >= 2 else ("WARN" if n >= R["min_trades"] else "FAIL")
        out.append(Check("sample size", st, f"{n} trades, {yrs:.1f} yrs",
                         f"aim for {R['good_trades']}+ trades over 2+ years"))
    else:
        st = "PASS" if yrs >= 5 else ("WARN" if yrs >= 2 else "FAIL")
        out.append(Check("sample size", st, f"{yrs:.1f} years, {n} position changes",
                         "position strategies: aim for 5+ years of daily data"))

    # calendar years
    et = pd.DatetimeIndex(t["entry_time"])
    by_y = t.groupby(et.year)["r_net"].agg(["sum", "size"])
    by_y = by_y[by_y["size"] >= 10]
    if len(by_y) >= 3:
        frac = float((by_y["sum"] > 0).mean())
        st = "PASS" if frac >= 0.6 else ("WARN" if frac >= 0.4 else "FAIL")
        out.append(Check("years profitable", st, f"{int((by_y['sum'] > 0).sum())}/{len(by_y)}",
                         ", ".join(f"{y}: {s:+.1f}" for y, s in by_y["sum"].items())))
    else:
        out.append(Check("years profitable", "N/A", f"{len(by_y)} full years", "needs 3+ years with trades"))

    # halves
    mid = et.min() + (et.max() - et.min()) / 2
    halves = []
    for name, sub in (("first half", t[et < mid]), ("second half", t[et >= mid])):
        r = sub["r_net"].to_numpy()
        if len(r) > 5:
            se = r.std(ddof=1) / math.sqrt(len(r))
            halves.append((name, r.mean(), r.mean() + 1.96 * se))
    if len(halves) == 2:
        if all(m > 0 for _, m, _ in halves):
            st = "PASS"
        elif any(hi < 0 for _, _, hi in halves):
            st = "FAIL"
        else:
            st = "WARN"
        out.append(Check("both halves", st, " / ".join(f"{m:+.3f}" for _, m, _ in halves),
                         "mean per trade, first vs second half of the period"))

    # decay
    if n >= 60:
        yy = (et - et.min()).total_seconds().to_numpy() / (365.25 * 86400)
        r = t["r_net"].to_numpy()
        A = np.vstack([np.ones_like(yy), yy]).T
        coef, *_ = np.linalg.lstsq(A, r, rcond=None)
        resid = r - A @ coef
        se = math.sqrt(resid.var(ddof=2) / max(((yy - yy.mean()) ** 2).sum(), 1e-12))
        tstat = coef[1] / se if se > 0 else 0
        last = t[et >= et.min() + (et.max() - et.min()) * 2 / 3]["r_net"].mean()
        st = "WARN" if (tstat < -2 and last < 0.5 * mean_all) else "PASS"
        out.append(Check("edge decay", st, f"{coef[1]:+.3f}{unit}/yr (t={tstat:.1f})",
                         f"last third {last:+.3f} vs all {mean_all:+.3f}"))

    # instruments
    g = t.groupby("inst")["r_net"].agg(["mean", "size", "sum"])
    g = g[g["size"] >= 20]
    if len(g) >= 2:
        pos = float((g["mean"] > 0).mean())
        best = g["sum"].idxmax()
        loo = t[t.inst != best]["r_net"].mean()
        if pos >= 0.6 and loo > 0:
            st = "PASS"
        elif loo > 0 or pos >= 0.6:
            st = "WARN"
        else:
            st = "FAIL" if pos < 0.5 else "WARN"
        out.append(Check("instrument breadth", st, f"{int((g['mean'] > 0).sum())}/{len(g)} positive",
                         f"without the best one ({best}): {loo:+.3f}{unit}/trade"))
    else:
        out.append(Check("instrument breadth", "N/A", "1 instrument", "add more markets to test breadth"))

    # costs
    rows = []
    for m in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0):
        rows.append((m, float(engine.with_cost_mult(t_trades, m).mean())))
    cs = pd.Series(dict(rows))
    be = _breakeven(cs)
    st = "PASS" if cs[1.5] > 0 else ("WARN" if cs[1.0] > 0 else "FAIL")
    out.append(Check("cost headroom", st, f"break-even at {be:.1f}x costs" if np.isfinite(be) else "no break-even",
                     f"1x {cs[1.0]:+.3f}, 1.5x {cs[1.5]:+.3f}, 2x {cs[2.0]:+.3f} {unit}/trade"))
    run_.info["cost_curve"] = cs

    # fill assumption
    if run_.strat.mode == "event":
        amb = float(t_trades["ambiguous"].mean())
        pess = float(t_trades["r_pess"].mean())
        st = "PASS" if pess > 0 else ("WARN" if mean_all > 0 else "INFO")
        out.append(Check("fill assumption", st, f"{amb:.1%} trades ambiguous",
                         f"worst-case order {pess:+.3f}, best-case {t_trades['r_opt'].mean():+.3f} {unit}/trade"))

    # parameter neighbours
    if neighbours is not None and len(neighbours):
        center = sharpe(d.to_numpy())
        nb = neighbours["sharpe"].to_numpy()
        frac = float((nb > 0).mean())
        med = float(np.median(nb))
        if frac >= 0.7 and (center <= 0 or med >= 0.5 * center):
            st = "PASS"
        elif frac >= 0.5:
            st = "WARN"
        else:
            st = "FAIL"
        out.append(Check("parameter plateau", st, f"{int((nb > 0).sum())}/{len(nb)} neighbours profitable",
                         f"median neighbour Sharpe {med:.2f} vs this {center:.2f}"))
    else:
        if run_.strat.grid:
            out.append(Check("parameter plateau", "N/A", "skipped (--fast)", "run without --fast to test neighbours"))
        else:
            out.append(Check("parameter plateau", "N/A", "no grid", "add grid=... to the strategy to test it"))

    # outliers
    if n >= 50:
        k = max(1, int(round(n * 0.01)))
        trimmed = np.sort(t["r_net"].to_numpy())[:-k].mean()
        mon = d.resample("ME").sum()
        share = float(mon.max() / mon[mon > 0].sum()) if (mon > 0).any() else 0.0
        st = "PASS" if trimmed > 0 else "WARN"
        what = "trades" if run_.strat.mode == "event" else "instrument-days"
        out.append(Check("outlier dependence", st, f"without top {k} {what}: {trimmed:+.3f}{unit}",
                         f"best month = {share:.0%} of all positive months"))

    # regimes (information only)
    reg = regimes(run_, t_trades if run_.strat.mode == "event" else t)
    if reg is not None:
        run_.info["regimes"] = reg
        txt = "; ".join(f"{k}: {v:+.3f}" for k, v in reg["mean_r"].items())
        out.append(Check("market regimes", "INFO", f"{len(reg)} regimes", txt))

    # other data sources
    if cross is not None and len(cross):
        okc = cross[cross["trades"] >= 100]
        if len(okc):
            pos = int((okc["mean_r"] > 0).sum())
            st = "PASS" if pos >= math.ceil(len(okc) / 2) else "WARN"
            out.append(Check("other data sources", st, f"{pos}/{len(okc)} positive",
                             "; ".join(f"{r.source}:{r.inst} {r.mean_r:+.3f} ({r.trades})" for r in okc.itertuples())))
        else:
            out.append(Check("other data sources", "N/A", "too little", "alternate sources have <100 trades"))

    # vault
    if final and vault_start is not None:
        v = t[pd.DatetimeIndex(t["entry_time"]) >= vault_start]["r_net"].to_numpy()
        if run_.strat.mode == "position":
            v = d[d.index >= vault_start].to_numpy() * 1e4
        if len(v) >= 20:
            se = v.std(ddof=1) / math.sqrt(len(v))
            lo, hi = v.mean() - 1.96 * se, v.mean() + 1.96 * se
            st = "PASS" if v.mean() > 0 else ("FAIL" if hi < 0 else "WARN")
            note = "" if vault_clean else " - NOT CLEAN: this family was already judged on the vault"
            out.append(Check("vault (unseen data)", st, f"{v.mean():+.3f}{unit} over {len(v)} trades",
                             f"95% [{lo:+.3f}, {hi:+.3f}]{note}"))
        else:
            out.append(Check("vault (unseen data)", "N/A", f"{len(v)} trades", "too few trades in the vault"))

    # realism (information)
    tsd = trade_stats(t_trades, len(d) / ANN * 12)
    if run_.strat.mode == "event":
        out.append(Check("execution realism", "INFO",
                         f"{tsd['out_of_session_exits']:.0%} exits outside session, {tsd['gap_exits']:.1%} gap exits",
                         f"avg {tsd['avg_nights']:.1f} swap nights; costs/trade: spread {tsd['cost_spread_r']:.3f}, "
                         f"commission {tsd['cost_comm_r']:.3f}, swap {tsd['swap_r']:+.3f}"))
    return out


def _breakeven(cs: pd.Series) -> float:
    xs, ys = cs.index.to_numpy(dtype=float), cs.to_numpy()
    if ys[0] <= 0:
        return 0.0
    for k in range(1, len(xs)):
        if ys[k] <= 0:
            return float(xs[k - 1] + (xs[k] - xs[k - 1]) * ys[k - 1] / (ys[k - 1] - ys[k]))
    slope = (ys[-1] - ys[0]) / (xs[-1] - xs[0])
    return float(-ys[0] / slope) if slope < 0 else np.inf


def regimes(run_: engine.Run, t: pd.DataFrame) -> Optional[pd.DataFrame]:
    """Mean R by market trend (50-day) and volatility tercile (20-day) at entry."""
    rows = []
    for inst, mk in run_.markets.items():
        tt = t[t.inst == inst]
        if tt.empty:
            continue
        px = pd.Series(mk.bc, index=pd.DatetimeIndex(mk.t)).resample("D").last().dropna()
        if len(px) < 80:
            continue
        ret = np.log(px).diff()
        vol = ret.rolling(20).std()
        trend = px.pct_change(50)
        vq = vol.rank(pct=True)
        ed = pd.DatetimeIndex(tt["entry_time"]).normalize()
        k = px.index.searchsorted(ed) - 1
        ok = k >= 0
        kk = np.clip(k, 0, None)
        rows.append(pd.DataFrame({"r": tt["r_net"].to_numpy()[ok],
                                  "trend": np.where(trend.to_numpy()[kk][ok] > 0, "up-trend", "down-trend"),
                                  "vol": pd.cut(vq.to_numpy()[kk][ok], [0, 1 / 3, 2 / 3, 1.0001],
                                                labels=["low vol", "mid vol", "high vol"]).astype(str)}))
    if not rows:
        return None
    a = pd.concat(rows)
    out = pd.concat([a.groupby("trend")["r"].agg(trades="size", mean_r="mean"),
                     a.groupby("vol")["r"].agg(trades="size", mean_r="mean")])
    return out.round(3)


# --------------------------------------------------------------------- sweeps

def pbo(returns: pd.DataFrame, blocks: int = 10) -> dict:
    """Probability of Backtest Overfitting (Bailey et al., CSCV). Columns are
    configurations, rows days. Splits time into blocks, picks the best config on
    half of them and checks where it ranks on the other half - over every split.
    PBO = how often the in-sample winner is below median out of sample."""
    X = returns.to_numpy()
    T, K = X.shape
    if K < 2 or T < blocks * 10:
        return dict(pbo=np.nan, n=0)
    edges = np.linspace(0, T, blocks + 1).astype(int)
    parts = [np.arange(edges[i], edges[i + 1]) for i in range(blocks)]
    lam, deg = [], []
    for comb in itertools.combinations(range(blocks), blocks // 2):
        is_idx = np.concatenate([parts[i] for i in comb])
        oos_idx = np.concatenate([parts[i] for i in range(blocks) if i not in comb])

        def sh(Y):
            s = Y.std(axis=0, ddof=1)
            return np.where(s > 0, Y.mean(axis=0) / np.where(s > 0, s, 1), 0)
        s_is, s_oos = sh(X[is_idx]), sh(X[oos_idx])
        best = int(np.argmax(s_is))
        rank = (s_oos < s_oos[best]).sum() + 1
        w = rank / (K + 1)
        lam.append(math.log(w / (1 - w)))
        deg.append((s_is[best], s_oos[best]))
    lam = np.asarray(lam)
    deg = np.asarray(deg)
    return dict(pbo=float((lam < 0).mean()), n=len(lam),
                is_sharpe=float(deg[:, 0].mean() * math.sqrt(ANN)), oos_sharpe=float(deg[:, 1].mean() * math.sqrt(ANN)))
