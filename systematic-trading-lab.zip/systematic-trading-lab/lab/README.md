# lab - one tool for data, backtests and verdicts

Everything lives in this folder. New strategies are new **functions** in `strategies.py`, never new files.

```
lab.py          the command line
data.py         MT5 / Alpaca / Yahoo -> one checked cache (data/)
engine.py       turns signals into broker-realistic trades
stats.py        the evidence and the verdict
prop.py         FTMO challenge + funded-year simulator
report.py       console summary + one HTML report per run (results/)
catalog.py      instruments, costs, prop rules, the FIXED verdict thresholds
strategies.py   your strategies, one function each
selftest.py     proves the tool works: unit tests + measured error rates
```

## Quick start (PowerShell)

```powershell
cd systematic-trading-lab
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
cd lab
python lab.py selftest --quick                    # 1. prove the tool works on your machine (~5 min)
python lab.py import-archive                      # 2. the bot's 11 M5 archives, clock repaired
python lab.py fetch gold silver wti brent us500 us100 --source mt5 yahoo   # 3. more history
python lab.py data gold                           # 4. what's cached, quality, do sources agree
python lab.py test golden_ratio_rerank            # 5. a full verdict
```

`requirements.txt` covers numpy, pandas, pyarrow, numba, yfinance, MetaTrader5 (Windows) and requests.

**MT5**: the FTMO terminal must be open and logged in, with *Tools > Options > Charts > Max bars in chart = Unlimited*.
If several terminals are installed, `MT5_PATH` in `lab\.env` picks the FTMO one.
**Alpaca**: put `ALPACA_API_KEY` and `ALPACA_SECRET_KEY` in `lab\.env` (copy `.env.example`). Free accounts get
SIP minute bars from 2016 (15 min delayed); if SIP is refused it falls back to IEX automatically.
**Yahoo**: no setup. Daily bars go back decades; intraday is short (1h: 2 years, 5m: 60 days, 1m: 30 days) but the
cache keeps every bar, so fetching regularly builds a longer intraday history over time.

## Commands

| command | does |
|---|---|
| `fetch gold us500 --source mt5 alpaca yahoo [--tf M1 M5 H1 D1] [--full]` | longest history each source has; later runs only add new bars |
| `import-archive [folder]` | folds an older bot's `bars\*.pkl` archive into the MT5 cache and repairs its clock |
| `data [instrument...]` | inventory, quality problems, cross-source agreement |
| `list` | strategies and instruments |
| `test NAME [--instruments ...] [--source] [--venue] [--from] [--to] [--set k=v] [--fast]` | full verdict on development data |
| `test NAME --final` | the same, including the vault. Do this **once** per strategy, at the end |
| `sweep NAME --grid ema=10,20,30 rsi=10,14` | tries every combination, measures overfitting (PBO), then a full verdict on the best, deflated for all of them |
| `registry [NAME]` | every variant ever tested |
| `selftest [--quick]` | unit tests + calibration |

`source:SYMBOL` works anywhere an instrument does, e.g. `fetch yahoo:^VIX`.

## The strategy search (`search.py`)

Fourteen documented strategy families (opening-range breakout, first-candle ORB, noise-area breakout,
VWAP reversion, gap fade/follow, volatility breakout, Asian-range breakout, intraday RSI(2), intraday
periodicity, session drift, Donchian trend, daily RSI(2), IBS, turn-of-month) x every setting in a small
fixed grid x every instrument cached x 5m/15m/1h/daily. Protocol fixed before any result (top of `search.py`):

```powershell
pip install numba                       # once - the fast discovery kernel
python lab.py fetch-all                 # every FTMO symbol, D1/H1/M5 (hours; resumable)
python lab.py fetch-proxies             # Alpaca 2016+ for SPY QQQ DIA IWM USO UNG + FTMO's US stocks
python lab.py search discover           # everything on data before 2022 (one line per instrument)
python lab.py search select             # fixed rules -> results\search\finalists.csv
python lab.py search confirm            # finalists on 2022 -> vault date, full engine + verdict each
python lab.py search report             # the confirmed strategies as one account: yearly returns, Sharpe,
                                        #   PF, drawdown, biggest win/loss, exact symbols, monthly income per firm
python lab.py search final              # ONCE, for the confirmed strategies: opens the vault
python lab.py search report --final     # the same report including the vault year
python lab.py search status
```

* FTMO's MT5 server has real intraday history for index CFDs and oil only from late 2021; older "M5"
  bars are one-a-day padding and are cut. US index/energy CFDs are discovered on their Alpaca twins
  (2016+), priced at FTMO's costs, and confirmed on the FTMO CFDs themselves.
* Discovery uses a numba kernel that is tested to give exactly the engine's trades (selftest).
* Confirmation decides "real" with false-discovery control across all finalists (q = 10%), plus the
  same random-entry, robustness and lookahead checks as `test`.

### Prop-firm income model (`prop.lifecycle`, programs in `catalog.PROGRAMS`)

A year at each firm the way it really goes: buy the evaluation, pass or fail (and buy again), trade the
funded account, get paid on that firm's schedule (split, payout caps, consistency rules, minimums, fee
refund), lose the account on a breach and start again. Static, end-of-day trailing and FTMO 1-Step's
trailing-with-reset drawdowns are modelled. Every number sits next to a zero-edge twin. Only programs
that allow a fully automated bot on the funded account are listed (researched 6 Oct 2026; Alpha Capital,
Apex and Take Profit Trader ban it, FundedNext only allows it under $50K). Fees marked [3P] in the
catalogue came from third-party reviews - check them at checkout.

## The verdicts

| verdict | means | do |
|---|---|---|
| **EDGE - CONCLUSIVE** | significant after every variant you tried, beats random timing, robust, and holds on the vault | forward-test small, then trade it |
| **EDGE - STRONG** | all of the above except the vault isn't opened yet | run `--final` once |
| **EDGE - PROBABLE** | significant and beats random timing, but one robustness check fails | forward-test before risking a challenge |
| **FRAGILE** | significant on the whole sample, but fails several robustness checks | probably fitted to this history |
| **BETA - NO TIMING EDGE** | makes money, but random entries in the same markets/months/hours make about the same | the profit is the market's drift, not your signal |
| **INCONCLUSIVE - LEANS YES** | positive and worth trading if real, but not proven yet: either not significant, or significant without beating random timing | the report says how much more data settles it; forward-test |
| **INCONCLUSIVE - LOOKS LIKE BETA** | positive but not proven, and random entries made most of the profit | treat as drift unless more data says otherwise |
| **INCONCLUSIVE - LEANS NO** | can't be ruled out, but the best estimate is too small to be worth trading | drop it or rethink it |
| **NO EDGE** | even the optimistic end of the 95% range is below Sharpe 0.30 | conclusively not worth trading |
| **INSUFFICIENT DATA** | under 100 trades or 250 trading days | get more data |
| **BROKEN** | signals read future bars, or the data is bad | fix first - every other number is fake |

## How the verdict is reached (fixed in `catalog.RULES`, never tuned after seeing results)

1. **Hard stops**: the lookahead check cuts the data at random points and recomputes the signals. If a signal
   changes when later bars are attached, the strategy is reading the future: BROKEN. Bad data (clock shifted,
   broken bars, bad ticks): BROKEN.
2. **Is it real?** Deflated Sharpe Ratio >= 95%. The Sharpe is tested against the best Sharpe luck alone would
   give across *every variant of this strategy in the registry*. Near-identical variants barely raise the bar;
   genuinely different ones do. Comments and spacing don't count as new variants; logic changes do.
3. **Is it timing?** Every trade is compared with 20 random entries on the same market, in the same month and
   hour, same direction, same exits. Beating them (p < 5%) is what separates a signal from riding a trend, and
   no EDGE verdict is given without it.
4. **Can it be ruled out?** NO EDGE only when the whole 95% interval of the Sharpe is below 0.30. Missing
   significance alone is never a fail: that's INCONCLUSIVE, with the years/trades needed to settle it.
5. **Is it robust?** Years, halves, decay, instrument breadth, cost headroom (1.5x costs), fill assumption
   (worst-case order inside a bar), parameter neighbours, outlier dependence, other data sources, the vault.
   PASS / WARN / FAIL each. EDGE survives WARNs and at most one FAIL. **One weak number never sinks a strategy.**

Every interval uses a stationary block bootstrap by trading day, so losing streaks and volatility clusters stay together.

## Fill rules (each one was a hole in an earlier backtest)

* Signal on bar t -> fill at the **next bar's open**. If the market is shut by then, the trade is skipped.
* Longs buy the **ask** and sell the **bid** (shorts the reverse). MT5 bars carry the real spread per bar.
* Stops/targets are checked on **every execution bar, 24h**, like a broker holds them, unless the strategy says
  `broker_stops=False` (then only inside its session).
* A bar that **opens beyond the stop fills at the open**. Gaps are not capped at -1R.
* Exits run on the **finest data cached** (1-minute where you have it, 5-minute before that, spliced). Signal bars
  are spliced the same way, so a short 5-minute cache never cuts off years of 1-minute history.
* **Data repair on load** (the cache itself is never changed): high/low that don't contain open/close are widened
  (a Yahoo quirk), and *bad prints* are fixed: a jump that the next bar's open ignores (real moves carry into the
  next open, bad ticks don't), plus wild wicks on 0-spread MT5 rollover bars. Real crash days are left alone.
* **Swap** from MT5 is converted at each trade's own price (MT5 quotes many swaps in price points).
* Stop and target touched in the same bar: both outcomes are kept. The result uses the bar's shape, and the
  scorecard shows whether the verdict survives the worst-case order.
* **Swap** per rollover (17:00 New York) with the triple day; real values from MT5 when fetched, otherwise
  listed in the report as assumptions. Commission per side, optional stop slippage.
* Daily-loss checks in the prop sim use **intraday** equity: every open trade at its worst bid/ask per bar.

## Anti-overfitting discipline

* **Vault**: the newest 12 months of every dataset are locked, from ONE date for the whole lab (set on first run,
  stored in `data\vault.json`, shown by `python lab.py data`). `test` never sees it. `--final` opens it, and the registry
  remembers. A strategy changed after its vault was opened gets a "NOT CLEAN" vault result.
* **Registry** (`results\registry.csv`): every tested variant, used to deflate the Sharpe. Don't delete it to make
  results look better: that only fools you.
* **Walk-forward**: strategies that pick instruments (like `golden_ratio_rerank`) re-select every 6 months from the
  past 24 months only. Every traded trade is out of sample by construction.
* **Sweeps** report PBO, the probability that the best in-sample variant is below median out of sample.

## Writing a strategy

Copy one in `strategies.py`, rename the function, change the logic. Return a bool Series (enter), an int Series
(+1/-1/0), or a DataFrame with `entry` (+ optional `exit`, `stop_price`, `target_price`). Position strategies
return a target position -1..+1. Use only bars up to the current one (the lookahead check will catch you).
Put neighbour values in `grid=` for the plateau check.

## Calibration (measured by `selftest`, 100 synthetic 3-year markets per scenario, 5 Oct 2026)

| scenario | called EDGE | called NO EDGE | rest |
|---|---|---|---|
| random entries, flat market | 4% | 11% | inconclusive |
| random entries, rising market (drift) | 2% | 6% | inconclusive / beta |
| real planted edge, Sharpe ~2, ~170 trades | **93%** | **0%** | 6% "leans yes" |
| small real edge, Sharpe ~1 | 33% | **0%** | 44% "leans yes" |
| strategy that reads the future | 0% | 0% | **BROKEN 100%** |

So: luck gets called an edge about 2-4% of the time (the 5% significance level, by design); a real edge is
never called NO EDGE; a small real edge over 3 years is usually "not proven yet" rather than thrown away - which
is the honest answer for that much data. Re-run `python lab.py selftest` any time you change engine/stats code.

## Known limits (said plainly)

* Backtests can't see liquidity: no partial fills or market impact. Fine for retail size on liquid CFDs.
* MT5's per-bar spread is the spread the server recorded for the bar, not every tick. News spikes inside a bar are
  only partly seen.
* Yahoo continuous futures (`GC=F`, `CL=F`) are not roll-adjusted, so roll days show fake gaps (flagged).
  Prefer ETFs (GLD, USO, SPY) for long daily history.
* Stock universes from Alpaca/Yahoo only include companies that still exist (survivorship bias). Indices/ETFs are fine.
* The prop sim resamples history in 10-day blocks. It is only as representative as the history you give it.
* "Absolutely certain" doesn't exist. What this gives you is known error rates and a verdict that says
  INCONCLUSIVE instead of guessing.
