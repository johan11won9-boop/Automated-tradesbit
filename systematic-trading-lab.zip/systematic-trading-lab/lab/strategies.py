"""
strategies.py - every strategy is ONE function here. No new files, ever.

A strategy gets the signal bars (a DataFrame: open high low close volume
spread_bp, index = bar open time UTC, already cut to its session if it has one)
and its params, and returns ONE of:
    event mode:    a bool Series (True = enter in `direction`), or an int Series
                   (+1 long, -1 short, 0 nothing), or a DataFrame with 'entry' and
                   optionally 'exit' (bool), 'stop_price', 'target_price'
    position mode: a Series of target position, -1 .. +1 (fraction of notional)

Rules the tool enforces so you don't have to remember them:
  * signals may only use bars up to and including the current one (the
    lookahead check cuts the data at random points and re-runs you to prove it)
  * the engine fills at the NEXT bar's open, never at the signal bar's close
  * `grid` lists neighbour values for the parameter-plateau check - put the
    values either side of each parameter, not a search space

Add a strategy: copy one below, rename the function, change the logic. Its name
is the function name:  python lab.py test my_function
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from engine import Exits, WalkForward, strategy


# ------------------------------------------------------------------ helpers

def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    g = d.clip(lower=0).rolling(n).mean()
    l = (-d.clip(upper=0)).rolling(n).mean()
    return 100 - 100 / (1 + g / l.replace(0, np.nan))


def confirm(cond: pd.Series, bars: int) -> pd.Series:
    out = cond.copy()
    for k in range(1, bars):
        out &= cond.shift(k, fill_value=False)
    return out


def sweep_long(df: pd.DataFrame, lookback: int = 10, gap: int = 2) -> pd.Series:
    swing = df["low"].rolling(lookback - gap).min().shift(gap)
    return (df["low"] < swing) & (df["close"] > swing)


def local(index: pd.DatetimeIndex, tz: str) -> pd.DatetimeIndex:
    return index.tz_localize("UTC").tz_convert(tz).tz_localize(None)


# --------------------------------------------------- 1. the live FTMO bot

_GR = dict(ema=20, rsi=14, lo=35, hi=65, vol=20, confirm=2, sweep=False)
_GR_GRID = dict(ema=[15, 25], rsi=[10, 20], lo=[30, 40], hi=[60, 70], vol=[15, 30], confirm=[1, 3])


def _golden(df: pd.DataFrame, p: dict) -> pd.Series:
    c, v = df["close"], df["volume"]
    base = (c > ema(c, p["ema"])) & rsi(c, p["rsi"]).between(p["lo"], p["hi"]) & (v > v.rolling(p["vol"]).mean())
    ok = confirm(base.fillna(False), p["confirm"])
    if p.get("sweep"):
        ok &= sweep_long(df).fillna(False)
    return ok


@strategy(timeframe="M5", params=_GR, grid=_GR_GRID,
          exits=Exits(stop_pct=0.0075, target_pct=0.0375, max_bars=200),
          session=("13:30", "20:00"), tz="UTC", direction="long",
          instruments=["gold", "silver", "wti", "brent"], source="mt5", venue="ftmo",
          description="Golden ratio exactly as ftmo_live trades it today: the fixed 4-market book, "
                      "5R target, 200-bar limit, stops on the server 24h. NOTE: the book was picked on "
                      "this same history, so this run flatters it - golden_ratio_rerank is the honest one.")
def golden_ratio(df, p):
    return _golden(df, p)


@strategy(timeframe="M5", params=_GR, grid=_GR_GRID,
          exits=Exits(stop_pct=0.0075, target_pct=0.0375, max_bars=200),
          session=("13:30", "20:00"), tz="UTC", direction="long",
          instruments=["gold", "silver", "platinum", "wti", "brent", "natgas", "wheat", "corn", "soybean", "btc", "eth"],
          source="mt5", venue="ftmo",
          walk_forward=WalkForward(train_months=24, min_train_months=12, trade_months=6, top=6, metric="pf",
                                   min_trades=40, variants=[dict(sweep=False), dict(sweep=True)],
                                   max_cost_bp=8.5),
          description="The full golden ratio method: every 6 months re-rank all FTMO commodity charts on "
                      "the past 24 months (best sweep mode each, cost under 8.5bp), trade the top 6. "
                      "Every trade is out of sample.")
def golden_ratio_rerank(df, p):
    return _golden(df, p)


# ------------------------------------------- 2. intraday momentum (US index)

@strategy(timeframe="M5", params=dict(first_end="10:00", entry_bar="15:25"),
          exits=Exits(stop_pct=0.005, flat_at="16:00"),
          session=("09:30", "16:00"), tz="America/New_York", direction="both",
          instruments=["us500", "us100"], source="alpaca", venue="alpaca",
          description="Gao, Han, Li & Zhou (2018): the return from yesterday's close to 10:00 predicts "
                      "the last half hour. Enter at 15:30 New York in its direction, out by 16:00. "
                      "1R = 0.5% catastrophe stop.")
def intraday_momentum(df, p):
    loc = local(df.index, "America/New_York")
    date = loc.normalize()
    hm = loc.strftime("%H:%M")
    close = df["close"]
    first_end_bar = (pd.Timestamp(p["first_end"]) - pd.Timedelta(minutes=5)).strftime("%H:%M")
    at_first = pd.Series(close.where(hm == first_end_bar).to_numpy(), index=date).groupby(level=0).last()
    day_close = pd.Series(close.to_numpy(), index=date).groupby(level=0).last()
    r_first = at_first / day_close.shift(1) - 1
    sig = np.sign(r_first.reindex(date).to_numpy())
    out = pd.Series(0, index=df.index, dtype=np.int8)
    is_entry = (hm == p["entry_bar"])
    out[is_entry] = np.nan_to_num(sig[is_entry]).astype(np.int8)
    return out


# --------------------------------------------- 3. time-series momentum (daily)

@strategy(timeframe="D1", mode="position", direction="both",
          params=dict(lookback=252, vol_n=60, target_vol=0.10, rebalance=5),
          grid=dict(lookback=[126, 189, 315], vol_n=[40, 90]),
          instruments=["gold", "wti", "us500", "us100", "eurusd", "usdjpy"], source="yahoo", venue="ftmo",
          description="Moskowitz, Ooi & Pedersen (2012) time-series momentum: long if the last year was up, "
                      "short if down, sized to 10% volatility, rebalanced weekly.")
def ts_momentum(df, p):
    c = df["close"]
    ret = np.log(c).diff()
    vol = ret.rolling(p["vol_n"]).std() * np.sqrt(252)
    raw = np.sign(c / c.shift(p["lookback"]) - 1) * (p["target_vol"] / vol).clip(upper=1.0)
    keep = np.arange(len(c)) % p["rebalance"] == 0
    return raw.where(keep).ffill().fillna(0.0)


# ------------------------------------------------- 4. baselines (calibration)

@strategy(timeframe="D1", mode="position", direction="long", params={},
          instruments=["us500"], source="yahoo", venue="ftmo",
          description="Buy and hold. Should come out as BETA: it makes money in rising markets with no timing.")
def buy_and_hold(df, p):
    return pd.Series(1.0, index=df.index)


@strategy(timeframe="M5", params=dict(prob=0.004, seed=1),
          exits=Exits(stop_pct=0.0075, target_pct=0.0375, max_bars=200),
          session=("13:30", "20:00"), tz="UTC", direction="long",
          instruments=["gold", "silver", "wti", "brent"], source="mt5", venue="ftmo",
          description="Coin-flip entries with the golden ratio's exits. Never has a timing edge.")
def random_entries(df, p):
    # seeded per bar time so the lookahead check sees identical signals on cut data
    u = (pd.util.hash_array(df.index.asi8.astype(np.int64) + p["seed"]) % 1_000_003) / 1_000_003
    return pd.Series(u < p["prob"], index=df.index)
