"""
data.py - market data from MT5, Alpaca and Yahoo into one checked cache.

Every bar in the cache, whatever the source, looks the same:
    index      bar OPEN time, naive UTC (D1 bars: the trading date at 00:00)
    columns    open high low close volume spread_bp
    meta.json  source, symbol, timeframe, price_type (bid / trade / mid), adjusted,
               first/last bar, vault_start (fixed the first time the data is saved)

Sources and what they are best for:
    mt5     the venue you trade: real bid prices, real spread per bar, real swap.
            Server time is converted to UTC bar by bar (New York + 7h by default,
            so it is right in summer AND winter - the old bot archive was not).
    alpaca  US stocks/ETFs and crypto, 1-minute bars from 2016.
    yahoo   daily bars back decades (indices, futures, FX, ETFs); intraday is short
            (1h: 730 days, 5m: 60 days, 1m: 30 days) but the cache keeps growing
            every time you fetch.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import catalog

log = logging.getLogger("data")

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
COLS = ["open", "high", "low", "close", "volume", "spread_bp"]
TF_MIN = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}


def tf_minutes(tf: str) -> int:
    if tf not in TF_MIN:
        raise ValueError(f"unknown timeframe {tf} - use one of {', '.join(TF_MIN)}")
    return TF_MIN[tf]


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ----------------------------------------------------------------------- env

def load_env() -> Dict[str, str]:
    """lab/.env, then ftmo_live/.env (for MT5_PATH), then the real environment."""
    out: Dict[str, str] = {}
    for p in (ROOT.parent / "ftmo_live" / ".env", ROOT / ".env"):
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    out[k.strip()] = v.strip().strip('"').strip("'")
    out.update({k: v for k, v in os.environ.items() if k.startswith(("MT5_", "ALPACA_", "APCA_"))})
    return out


# --------------------------------------------------------------------- cache

def _safe(symbol: str) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in symbol)


def cache_path(source: str, symbol: str, tf: str) -> Path:
    return DATA / source / f"{_safe(symbol)}_{tf}.parquet"


def meta_path(source: str, symbol: str, tf: str) -> Path:
    return DATA / source / f"{_safe(symbol)}_{tf}.meta.json"


def read_meta(source: str, symbol: str, tf: str) -> dict:
    p = meta_path(source, symbol, tf)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            return {}
    return {}


def read(source: str, symbol: str, tf: str) -> Optional[pd.DataFrame]:
    p = cache_path(source, symbol, tf)
    if not p.exists():
        return None
    df = pd.read_parquet(p)
    df.index = pd.DatetimeIndex(df.index)
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Standard columns, float, sorted, no duplicate stamps, no empty prices."""
    df = df.copy()
    for c in COLS:
        if c not in df:
            df[c] = np.nan
    df = df[COLS].astype(float)
    df = df[~df.index.duplicated(keep="last")].sort_index()
    df = df.dropna(subset=["open", "high", "low", "close"])
    df = df[(df[["open", "high", "low", "close"]] > 0).all(axis=1)]
    df.index.name = "time"
    return df


SPIKE_FLOOR = {"M1": 0.005, "M5": 0.007, "M15": 0.01, "M30": 0.012, "H1": 0.015, "H4": 0.02, "D1": 0.03}


def repair(df: pd.DataFrame, tf: str) -> tuple:
    """Fix what is provably wrong, leave everything that could be real.

      * high/low that don't contain open/close (Yahoo daily quirk): widened to contain them
      * bad prints: a close that jumps away and the NEXT bar opens straight back at the
        previous close, ignoring it. A real move (crash days, tariff days) carries into the
        next open; a bad tick doesn't. The bad close is replaced by the next open.
    Returns (repaired frame, n_ohlc_fixed, n_bad_prints)."""
    if df is None or len(df) < 3:
        return df, 0, 0
    o = df["open"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float).copy()
    prev_c = np.r_[np.nan, c[:-1]]
    next_o = np.r_[o[1:], np.nan]
    with np.errstate(divide="ignore", invalid="ignore"):
        move = np.abs(np.log(c / prev_c))
        back = np.abs(np.log(next_o / c))
        stay = np.abs(np.log(next_o / prev_c))
    mad = pd.Series(move).rolling(500, min_periods=50).median().bfill().to_numpy()
    thr = np.maximum(12 * np.nan_to_num(mad, nan=0.0), SPIKE_FLOOR.get(tf, 0.01))
    bad = (move > thr) & (back > thr) & (stay < 0.25 * move)
    bad = np.nan_to_num(bad, nan=False).astype(bool)
    n_bad = int(bad.sum())
    if n_bad:
        c[bad] = next_o[bad]
        h = np.where(bad, np.maximum(o, c), h)
        l = np.where(bad, np.minimum(o, c), l)
    # MT5 bars with a spread of exactly 0 in a series that normally has one are not from the
    # live quote stream (vendor history at the daily rollover): their wicks are not trusted
    if "spread_bp" in df:
        spr = df["spread_bp"].to_numpy(dtype=float)
        zero = spr == 0
        if 0 < zero.mean() < 0.05 and np.nanmedian(spr[spr > 0]) > 0:
            with np.errstate(divide="ignore", invalid="ignore"):
                rng_ = np.log(h / l)
            wild = zero & (np.nan_to_num(rng_) > thr)
            if wild.any():
                h = np.where(wild, np.maximum(o, c), h)
                l = np.where(wild, np.minimum(o, c), l)
                n_bad += int((wild & ~bad).sum())
    hi = np.maximum.reduce([h, o, c])
    lo = np.minimum.reduce([l, o, c])
    n_ohlc = int(((hi > h + 1e-12) | (lo < l - 1e-12)).sum())
    if n_bad or n_ohlc:
        df = df.copy()
        df["close"], df["high"], df["low"] = c, hi, lo
    return df, n_ohlc, n_bad


def save(source: str, symbol: str, tf: str, fresh: pd.DataFrame, **meta) -> pd.DataFrame:
    """Merge fresh bars into the cache (fresh wins where both have a bar)."""
    fresh = clean(fresh)
    old = read(source, symbol, tf)
    if old is not None and not old.empty:
        keep_old = old[~old.index.isin(fresh.index)]
        merged = clean(pd.concat([keep_old, fresh]))
    else:
        merged = fresh
    p = cache_path(source, symbol, tf)
    p.parent.mkdir(parents=True, exist_ok=True)
    merged.to_parquet(p)
    m = read_meta(source, symbol, tf)
    m.update({k: v for k, v in meta.items() if v is not None})
    m.update(source=source, symbol=symbol, tf=tf, rows=int(len(merged)),
             first=str(merged.index[0]) if len(merged) else None,
             last=str(merged.index[-1]) if len(merged) else None,
             fetched_at=str(utcnow())[:19])
    meta_path(source, symbol, tf).write_text(json.dumps(m, indent=1), encoding="utf-8")
    return merged


def vault_start() -> pd.Timestamp:
    """ONE vault date for everything: the newest months of every dataset, fixed the
    first time the lab runs (data/vault.json) so it never moves. A portfolio's
    instruments are all held back from the same day."""
    p = DATA / "vault.json"
    if p.exists():
        try:
            return pd.Timestamp(json.loads(p.read_text(encoding="utf-8"))["vault_start"])
        except (ValueError, KeyError):
            pass
    months = catalog.RULES.get("vault_months", 12)
    v = (pd.Timestamp(utcnow()) - pd.DateOffset(months=months)).normalize().replace(day=1)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"vault_start": str(v.date()), "set_on": str(utcnow())[:10],
                             "note": "data from this date on is the vault: only `test --final` sees it"}),
                 encoding="utf-8")
    return v


def inventory() -> pd.DataFrame:
    rows = []
    for mp in sorted(DATA.glob("*/*.meta.json")):
        try:
            m = json.loads(mp.read_text(encoding="utf-8"))
        except ValueError:
            continue
        inst = catalog.instrument_of(m.get("source", ""), m.get("symbol", ""))
        first, last = pd.Timestamp(m["first"]), pd.Timestamp(m["last"])
        rows.append(dict(instrument=inst or "-", source=m["source"], symbol=m["symbol"], tf=m["tf"],
                         first=first.date(), last=last.date(),
                         years=round((last - first).days / 365.25, 1), rows=m["rows"],
                         price=m.get("price_type", "?")))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------ resample

def resample(df: pd.DataFrame, tf: str) -> pd.DataFrame:
    """Finer minute bars -> coarser (left-labelled, UTC clock). D1 is never built
    here - daily bars come from each source's own daily series."""
    if tf == "D1":
        raise ValueError("D1 must be fetched natively, not resampled")
    rule = f"{tf_minutes(tf)}min"
    g = df.resample(rule, label="left", closed="left")
    out = pd.DataFrame({"open": g["open"].first(), "high": g["high"].max(), "low": g["low"].min(),
                        "close": g["close"].last(), "volume": g["volume"].sum(min_count=1),
                        "spread_bp": g["spread_bp"].mean()})
    return out.dropna(subset=["open", "close"])


def infer_minutes(df: pd.DataFrame) -> int:
    if len(df) < 3:
        return 0
    d = np.diff(df.index.values[: min(len(df), 5000)]).astype("timedelta64[s]").astype(np.int64)
    d = d[d > 0]
    return int(np.median(d) // 60) if len(d) else 0


# ------------------------------------------------------------- MT5 (Windows)

def server_to_utc(server_epoch: np.ndarray, rule: str = "NY+7") -> pd.DatetimeIndex:
    """MT5 stamps bars in the broker's clock. 'NY+7' (FTMO and most MT5 brokers):
    server wall clock = New York wall clock + 7h, so it follows US daylight saving.
    'UTC+2' style rules are a fixed offset."""
    s = pd.to_datetime(np.asarray(server_epoch, dtype="int64"), unit="s")
    rule = rule.upper().replace(" ", "")
    if rule.startswith("NY"):
        hours = int(rule[2:] or 0)
        ny = (s - pd.Timedelta(hours=hours)).tz_localize(
            "America/New_York", ambiguous=np.ones(len(s), dtype=bool), nonexistent="shift_forward")
        return ny.tz_convert("UTC").tz_localize(None)
    if rule.startswith("UTC"):
        return s - pd.Timedelta(hours=int(rule[3:] or 0))
    raise ValueError(f"MT5_SERVER_TZ '{rule}' not understood (use NY+7 or UTC+2)")


class MT5Source:
    TF_CHUNK_DAYS = {"M1": 20, "M5": 90, "M15": 180, "M30": 365, "H1": 730, "H4": 2000, "D1": 10000}

    def __init__(self):
        import MetaTrader5 as mt5          # Windows only
        env = load_env()
        kw = {}
        if env.get("MT5_PATH"):
            kw["path"] = env["MT5_PATH"]
        if env.get("MT5_LOGIN"):
            kw.update(login=int(env["MT5_LOGIN"]), password=env.get("MT5_PASSWORD", ""),
                      server=env.get("MT5_SERVER", ""))
        if not mt5.initialize(**kw):
            raise RuntimeError(f"MT5 initialize failed {mt5.last_error()} - open the terminal and log in")
        self.mt5 = mt5
        self.rule = env.get("MT5_SERVER_TZ", "NY+7")
        ti = mt5.terminal_info()
        acct = mt5.account_info()
        self.server = getattr(acct, "server", "?")
        maxbars = int(getattr(ti, "maxbars", 0) or 0)
        if 0 < maxbars < 10_000_000:
            log.warning("MT5 'Max bars in chart' is %s - set it to Unlimited (Tools > Options > Charts) "
                        "or history will be cut short", f"{maxbars:,}")

    def resolve(self, symbol: str) -> Optional[str]:
        names = [s.name for s in (self.mt5.symbols_get() or [])]
        if symbol in names:
            hit = symbol
        else:
            base = symbol.split(".")[0].upper()
            up = {n.upper(): n for n in names}
            hit = up.get(symbol.upper()) or up.get(base) or next(
                (n for u, n in up.items() if u.startswith(base)), None)
        if hit:
            self.mt5.symbol_select(hit, True)
        return hit

    def specs(self, symbol: str) -> dict:
        i = self.mt5.symbol_info(symbol)
        if i is None:
            return {}
        t = self.mt5.symbol_info_tick(symbol)
        px = float(getattr(t, "bid", 0) or 0) or float(getattr(i, "bid", 0) or 0)
        if px <= 0:                                   # no live quote: use the last daily close
            r = self.mt5.copy_rates_from_pos(symbol, self.mt5.TIMEFRAME_D1, 0, 1)
            px = float(r[0]["close"]) if r is not None and len(r) else 0.0
        if px <= 0:
            px = float("nan")                         # swap % stays unknown -> venue default is used
        mode = int(i.swap_mode)
        csize = float(i.trade_contract_size or 1)

        def pct(v: float) -> Optional[float]:
            # swap value -> % of notional per night
            if mode == 1:          # points
                return v * float(i.point) / px * 100
            if mode in (2, 3, 4):  # money per lot (symbol/margin/deposit currency - USD assumed)
                return v / (px * csize) * 100
            if mode in (5, 6):     # annual interest %
                return v / 360.0
            return None
        return dict(name=symbol, point=float(i.point), digits=int(i.digits), contract_size=csize,
                    currency_profit=i.currency_profit, swap_mode=mode,
                    swap_long_raw=float(i.swap_long), swap_short_raw=float(i.swap_short),
                    swap_long_pct=pct(float(i.swap_long)), swap_short_pct=pct(float(i.swap_short)),
                    triple_day=int(getattr(i, "swap_rollover3days", 3) or 3) - 1,  # MT5: 0=Sun -> ours: 0=Mon
                    spread_now_bp=(float(i.spread) * float(i.point) / px * 1e4) if px else None,
                    volume_min=float(i.volume_min), volume_step=float(i.volume_step),
                    measured_at=str(utcnow())[:19], price=px)

    def fetch(self, symbol: str, tf: str, start: Optional[datetime] = None,
              expect_from: Optional[datetime] = None) -> pd.DataFrame:
        """expect_from: where a coarser timeframe's history starts. MT5 often hands out
        only recent bars until it has downloaded more; while we are still short of that
        date, empty answers are retried patiently instead of being taken as 'no more'."""
        mt5 = self.mt5
        tfc = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
               "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4,
               "D1": mt5.TIMEFRAME_D1}[tf]
        step = timedelta(days=self.TF_CHUNK_DAYS[tf])
        end = utcnow() + timedelta(days=1)
        floor = start or datetime(1990, 1, 1)
        parts, empty, got_any = [], 0, False
        while end > floor:
            lo = max(end - step, floor)
            raw = None
            short = expect_from is not None and lo > expect_from + timedelta(days=30)
            tries = 8 if short else 3
            for attempt in range(tries):       # the terminal may still be downloading history
                raw = mt5.copy_rates_range(symbol, tfc, lo, end)
                if raw is not None and len(raw):
                    break
                time.sleep(min(4.0, 0.5 * (attempt + 1)))
            if raw is None or not len(raw):
                empty += 1
                limit = 12 if short else 3
                if (got_any and empty >= limit) or (not got_any and empty >= max(4, limit)):
                    break
            else:
                empty, got_any = 0, True
                parts.append(pd.DataFrame(raw))
                print(f"    {symbol} {tf}: back to {lo.date()}  ({sum(len(p) for p in parts):,} bars)", end="\r")
            end = lo
        print()
        if expect_from is not None and tf != "D1":
            have_from = min((int(pp["time"].min()) for pp in parts), default=None)
            if have_from is None or pd.Timestamp(have_from, unit="s") > pd.Timestamp(expect_from) + pd.Timedelta(days=60):
                # last resort: ask for the newest N bars, which makes MT5 load deep history
                for n in (5_000_000, 2_000_000, 1_000_000, 500_000):
                    got = None
                    for attempt in range(4):
                        got = mt5.copy_rates_from_pos(symbol, tfc, 0, n)
                        if got is not None and len(got):
                            break
                        time.sleep(2.0)
                    if got is not None and len(got):
                        parts.append(pd.DataFrame(got))
                        break
        if not parts:
            return pd.DataFrame(columns=COLS)
        raw = pd.concat(parts).drop_duplicates("time").sort_values("time")
        if tf == "D1":
            idx = pd.to_datetime(raw["time"].astype("int64"), unit="s").dt.normalize()
            idx = pd.DatetimeIndex(idx)
        else:
            idx = server_to_utc(raw["time"].values, self.rule)
        vol = raw["tick_volume"].astype(float)
        if "real_volume" in raw and float(raw["real_volume"].sum()) > 0:
            vol = raw["real_volume"].astype(float)
        info = mt5.symbol_info(symbol)
        point = float(info.point) if info is not None else 0.0
        out = pd.DataFrame({"open": raw["open"].values, "high": raw["high"].values,
                            "low": raw["low"].values, "close": raw["close"].values,
                            "volume": vol.values,
                            "spread_bp": (raw["spread"].astype(float) * point / raw["close"] * 1e4).values},
                           index=idx)
        if tf != "D1":   # drop the bar still forming
            out = out[out.index + pd.Timedelta(minutes=tf_minutes(tf)) <= pd.Timestamp(utcnow())]
        return out


# ---------------------------------------------------------------- Alpaca REST

class AlpacaSource:
    BASE = "https://data.alpaca.markets"
    TF = {"M1": "1Min", "M5": "5Min", "M15": "15Min", "M30": "30Min", "H1": "1Hour", "H4": "4Hour", "D1": "1Day"}

    def __init__(self):
        import requests
        env = load_env()
        key = env.get("ALPACA_API_KEY") or env.get("APCA_API_KEY_ID") or env.get("ALPACA_KEY")
        sec = env.get("ALPACA_SECRET_KEY") or env.get("APCA_API_SECRET_KEY") or env.get("ALPACA_SECRET")
        if not key or not sec:
            raise RuntimeError("Alpaca keys missing - put ALPACA_API_KEY and ALPACA_SECRET_KEY in lab/.env")
        self.s = requests.Session()
        self.s.headers.update({"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": sec})
        self.feed = env.get("ALPACA_FEED", "sip")

    def _get(self, url: str, params: dict) -> dict:
        import requests
        for attempt in range(8):
            try:
                r = self.s.get(url, params=params, timeout=60)
            except (requests.ConnectionError, requests.Timeout) as exc:   # dropped connection / SSL EOF: retry
                if attempt == 7:
                    raise RuntimeError(f"Alpaca connection kept failing: {exc}") from exc
                time.sleep(2 + 2 * attempt)
                continue
            if r.status_code == 429:
                time.sleep(3 + attempt * 2)
                continue
            if r.status_code >= 500:
                time.sleep(2 + attempt)
                continue
            if r.status_code != 200:
                raise RuntimeError(f"Alpaca {r.status_code}: {r.text[:300]}")
            return r.json()
        raise RuntimeError("Alpaca kept rate-limiting - try again in a minute")

    def fetch(self, symbol: str, tf: str, start: Optional[datetime] = None) -> Tuple[pd.DataFrame, dict]:
        crypto = "/" in symbol
        url = (f"{self.BASE}/v1beta3/crypto/us/bars" if crypto else f"{self.BASE}/v2/stocks/bars")
        start = start or datetime(2015, 12, 1)
        end = utcnow() - timedelta(minutes=16)           # free plan: SIP is 15 min delayed
        rows: List[dict] = []
        feed = self.feed
        cur = start
        while cur < end:
            nxt = min(cur + timedelta(days=366), end)
            params = {"symbols": symbol, "timeframe": self.TF[tf], "limit": 10000,
                      "start": cur.strftime("%Y-%m-%dT%H:%M:%SZ"), "end": nxt.strftime("%Y-%m-%dT%H:%M:%SZ"),
                      "sort": "asc"}
            if not crypto:
                params.update(adjustment="all", feed=feed)
            token = None
            while True:
                if token:
                    params["page_token"] = token
                else:
                    params.pop("page_token", None)
                try:
                    js = self._get(url, params)
                except RuntimeError as exc:
                    if not crypto and feed == "sip" and ("subscription" in str(exc).lower() or "403" in str(exc)):
                        log.warning("Alpaca SIP not allowed on this plan - falling back to IEX (thinner volume)")
                        feed = "iex"
                        params["feed"] = feed
                        continue
                    raise
                for b in (js.get("bars") or {}).get(symbol, []) or []:
                    rows.append(b)
                token = js.get("next_page_token")
                if not token:
                    break
            print(f"    {symbol} {tf}: {nxt.date()}  ({len(rows):,} bars)", end="\r")
            cur = nxt
        print()
        if not rows:
            return pd.DataFrame(columns=COLS), dict(feed=feed)
        df = pd.DataFrame(rows)
        t = pd.to_datetime(df["t"], utc=True)
        if tf == "D1":
            idx = pd.DatetimeIndex(t.dt.tz_convert("America/New_York").dt.tz_localize(None).dt.normalize())
        else:
            idx = pd.DatetimeIndex(t.dt.tz_localize(None))
        out = pd.DataFrame({"open": df["o"].values, "high": df["h"].values, "low": df["l"].values,
                            "close": df["c"].values, "volume": df["v"].values, "spread_bp": np.nan},
                           index=idx)
        return out, dict(feed=feed)


# ---------------------------------------------------------------------- Yahoo

class YahooSource:
    def __init__(self):
        import yfinance as yf
        self.yf = yf

    def fetch(self, symbol: str, tf: str, start: Optional[datetime] = None) -> pd.DataFrame:
        t = self.yf.Ticker(symbol)
        kw = dict(auto_adjust=True, actions=False)
        if tf == "D1":
            frames = [t.history(period="max", interval="1d", **kw)]
        elif tf == "H1":
            frames = [t.history(period="730d", interval="1h", **kw)]
        elif tf in ("M5", "M15", "M30"):
            frames = [t.history(period="60d", interval=tf[1:] + "m", **kw)]
        elif tf == "M1":
            frames, end = [], utcnow()
            for k in range(4):                     # Yahoo serves 1m for the last ~30 days, 8 per call
                s, e = end - timedelta(days=7 * (k + 1)), end - timedelta(days=7 * k)
                try:
                    frames.append(t.history(start=s, end=e, interval="1m", **kw))
                except Exception as exc:      # noqa: BLE001 - older windows are refused, that's fine
                    log.info("yahoo %s 1m %s: %s", symbol, s.date(), exc)
        else:
            raise ValueError(f"Yahoo has no {tf} bars - fetch H1 and resample")
        frames = [f for f in frames if f is not None and len(f)]
        if not frames:
            return pd.DataFrame(columns=COLS)
        df = pd.concat(frames)
        idx = pd.DatetimeIndex(df.index)
        if tf == "D1":
            idx = (idx.tz_localize(None) if idx.tz is not None else idx).normalize()
        else:
            idx = idx.tz_convert("UTC").tz_localize(None) if idx.tz is not None else idx
        out = pd.DataFrame({"open": df["Open"].values, "high": df["High"].values, "low": df["Low"].values,
                            "close": df["Close"].values,
                            "volume": df["Volume"].values if "Volume" in df else np.nan,
                            "spread_bp": np.nan}, index=idx)
        if start is not None:
            out = out[out.index >= pd.Timestamp(start)]
        return out


def yahoo_kind(symbol: str) -> str:
    if symbol.endswith("=F"):
        return "future_continuous"        # NOT back-adjusted: roll days jump
    if symbol.endswith("=X"):
        return "fx_mid"
    if symbol.startswith("^"):
        return "index_untradable"
    return "etf_or_stock"


# ---------------------------------------------------------------- fetch API

DEFAULT_TFS = {"mt5": ["M1", "M5", "H1", "D1"], "alpaca": ["M1", "D1"], "yahoo": ["D1", "H1", "M5", "M1"]}


def fetch(instruments: List[str], sources: List[str], tfs: Optional[List[str]] = None,
          full: bool = False) -> pd.DataFrame:
    """Pull the longest history each source has, merge into the cache, check it."""
    report = []
    conns: Dict[str, object] = {}
    for src in sources:
        try:
            conns[src] = {"mt5": MT5Source, "alpaca": AlpacaSource, "yahoo": YahooSource}[src]()
        except Exception as exc:   # noqa: BLE001 - one missing source must not stop the others
            print(f"  {src}: not available - {exc}")
    specs_file = DATA / "mt5" / "specs.json"
    specs = json.loads(specs_file.read_text(encoding="utf-8")) if specs_file.exists() else {}
    for inst in instruments:
        syms_by_src = _symbols_for(inst)
        for src, conn in conns.items():
            for sym in syms_by_src.get(src, []):
                real = sym
                if src == "mt5":
                    real = conn.resolve(sym)
                    if not real:
                        print(f"  mt5: {sym} not offered on this account")
                        continue
                    specs[real] = conn.specs(real)
                for tf in (tfs or DEFAULT_TFS[src]):
                    old = read(src, real, tf)
                    since = None if (full or old is None or old.empty) else \
                        (old.index[-1] - pd.Timedelta(days=3)).to_pydatetime()
                    try:
                        if src == "alpaca":
                            df, extra = conn.fetch(real, tf, since)
                        else:
                            df, extra = conn.fetch(real, tf, since), {}
                    except Exception as exc:   # noqa: BLE001
                        print(f"  {src} {real} {tf}: FAILED - {exc}")
                        continue
                    if df is None or df.empty:
                        print(f"  {src} {real} {tf}: no data")
                        continue
                    price = {"mt5": "bid", "alpaca": "trade"}.get(src) or (
                        "mid" if yahoo_kind(real) == "fx_mid" else "trade")
                    merged = save(src, real, tf, df, price_type=price,
                                  adjusted=src in ("alpaca", "yahoo"),
                                  kind=yahoo_kind(real) if src == "yahoo" else src,
                                  server=getattr(conn, "server", None),
                                  tz_rule=getattr(conn, "rule", None), **extra)
                    q = quality(merged, tf, read_meta(src, real, tf))
                    report.append(dict(instrument=inst, source=src, symbol=real, tf=tf,
                                       first=merged.index[0].date(), last=merged.index[-1].date(),
                                       years=round((merged.index[-1] - merged.index[0]).days / 365.25, 1),
                                       bars=len(merged), quality=q["level"],
                                       issues="; ".join(q["issues"])[:120]))
                break    # first symbol that exists on this source is enough (alternates via --symbol)
    if specs:
        specs_file.parent.mkdir(parents=True, exist_ok=True)
        specs_file.write_text(json.dumps(specs, indent=1), encoding="utf-8")
    if "mt5" in conns:
        conns["mt5"].mt5.shutdown()
    return pd.DataFrame(report)


def fetch_all(tfs: Optional[List[str]] = None, only: Optional[List[str]] = None, refresh_days: float = 2.0,
              skip_classes: Optional[List[str]] = None) -> pd.DataFrame:
    """Every tradable symbol on the logged-in MT5 account: classify, save specs, and
    pull D1, H1 and M5 (coarse first, so finer timeframes know how deep history goes).
    Resumable: a symbol fetched in the last `refresh_days` is skipped."""
    tfs = tfs or ["D1", "H1", "M5"]
    tfs = sorted(tfs, key=lambda t: -TF_MIN[t])
    conn = MT5Source()
    mt5 = conn.mt5
    syms = mt5.symbols_get() or []
    uni_path = DATA / "mt5" / "universe.json"
    uni_path.parent.mkdir(parents=True, exist_ok=True)
    uni = json.loads(uni_path.read_text(encoding="utf-8")) if uni_path.exists() else {}
    for sy in syms:
        if int(getattr(sy, "trade_mode", 4) or 0) == 0:          # disabled for trading
            continue
        cls = catalog.classify_mt5(getattr(sy, "path", ""), sy.name)
        uni[sy.name] = dict(path=getattr(sy, "path", ""), cls=cls, desc=getattr(sy, "description", ""),
                            base=getattr(sy, "currency_base", ""), profit=getattr(sy, "currency_profit", ""),
                            digits=int(getattr(sy, "digits", 0) or 0),
                            contract_size=float(getattr(sy, "trade_contract_size", 0) or 0),
                            server=conn.server)
    uni_path.write_text(json.dumps(uni, indent=1), encoding="utf-8")
    names = sorted(uni)
    if only:
        names = [n for n in names if n in only or uni[n]["cls"] in only]
    if skip_classes:
        names = [n for n in names if uni[n]["cls"] not in skip_classes]
    print(f"  {len(names)} tradable symbols on {conn.server}: " +
          ", ".join(f"{c} {sum(uni[n]['cls'] == c for n in names)}" for c in sorted({uni[n]['cls'] for n in names})))
    specs_file = DATA / "mt5" / "specs.json"
    specs = json.loads(specs_file.read_text(encoding="utf-8")) if specs_file.exists() else {}
    rows = []
    for k, name in enumerate(names):
        m = read_meta("mt5", name, tfs[-1])
        if m.get("fetched_at") and (pd.Timestamp(utcnow()) - pd.Timestamp(m["fetched_at"])).days < refresh_days:
            continue
        print(f"[{k + 1}/{len(names)}] {name} ({uni[name]['cls']})")
        try:
            mt5.symbol_select(name, True)
            specs[name] = conn.specs(name)
            deepest = None
            for tf in tfs:
                old = read("mt5", name, tf)
                since = None if old is None or old.empty else (old.index[-1] - pd.Timedelta(days=3)).to_pydatetime()
                df = conn.fetch(name, tf, since, expect_from=None if since else deepest)
                if df is None or df.empty:
                    continue
                merged = save("mt5", name, tf, df, price_type="bid", adjusted=False, kind="mt5",
                              server=conn.server, tz_rule=conn.rule, cls=uni[name]["cls"])
                if deepest is None or merged.index[0] < pd.Timestamp(deepest):
                    deepest = merged.index[0].to_pydatetime()
                rows.append(dict(symbol=name, cls=uni[name]["cls"], tf=tf, first=merged.index[0].date(),
                                 last=merged.index[-1].date(), bars=len(merged)))
        except Exception as exc:     # noqa: BLE001 - one bad symbol must not stop the sweep
            print(f"    {name}: FAILED - {exc}")
        if k % 10 == 0:
            specs_file.write_text(json.dumps(specs, indent=1), encoding="utf-8")
    specs_file.write_text(json.dumps(specs, indent=1), encoding="utf-8")
    mt5.shutdown()
    return pd.DataFrame(rows)


PROXY_ETFS = ["SPY", "QQQ", "DIA", "IWM", "USO", "UNG"]


def us_ticker(name: str) -> str:
    """FTMO stock CFD name -> US ticker (AAPL, AAPL.US, AAPL.OQ, #AAPL -> AAPL; share classes like BRK.B kept)."""
    n = name.lstrip("#").upper()
    head, _, tail = n.partition(".")
    if len(tail) == 1 and tail.isalpha():
        return f"{head}.{tail}"
    return head.split("_")[0]


def fetch_proxies(tfs: Optional[List[str]] = None, stocks: bool = True) -> pd.DataFrame:
    """Alpaca 5-minute + daily history from 2016 for the US ETFs that stand in for FTMO's index and
    energy CFDs (whose MT5 intraday history only starts in 2021), and for every US stock CFD on the
    MT5 account. Needs fetch-all to have run first (it lists the account's stocks)."""
    uni_path = DATA / "mt5" / "universe.json"
    uni = json.loads(uni_path.read_text(encoding="utf-8")) if uni_path.exists() else {}
    syms = list(PROXY_ETFS)
    if stocks:
        for name, u in sorted(uni.items()):
            if u.get("cls") == "stock" and (u.get("profit") or "USD") == "USD":
                t = us_ticker(name)
                if t and t.replace(".", "").isalpha() and t not in syms:
                    syms.append(t)
        if not uni:
            print("  no MT5 universe yet (run fetch-all first) - fetching the ETFs only")
    print(f"  {len(syms)} Alpaca symbols: {' '.join(syms)}")
    return fetch([f"alpaca:{s}" for s in syms], ["alpaca"], tfs or ["M5", "D1"])


def _symbols_for(inst: str) -> Dict[str, List[str]]:
    """'gold' -> catalog symbols; 'yahoo:^GSPC' -> just that one."""
    if ":" in inst:
        src, sym = inst.split(":", 1)
        return {src: [sym]}
    if inst not in catalog.INSTRUMENTS:
        raise KeyError(f"unknown instrument '{inst}' - add it to catalog.INSTRUMENTS or use source:SYMBOL")
    d = catalog.INSTRUMENTS[inst]
    return {s: list(d.get(s, [])) for s in catalog.SOURCES}


def mt5_specs() -> dict:
    p = DATA / "mt5" / "specs.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


# ---------------------------------------------------- import the bot's archive

def import_archive(folder: Path) -> pd.DataFrame:
    """Fold ftmo_live/bars/*_M5.pkl into the MT5 cache, fixing its clock.

    The bot stamped every archived bar with the offset that applied on the day it
    was fetched (UTC+3, summer), so winter bars sit one hour early. Here the
    offset is detected month by month from the metals' daily break (server
    00:00-01:00) and every bar is re-converted with the correct New York + 7h rule."""
    files = sorted(Path(folder).glob("*_M5.pkl"))
    if not files:
        raise FileNotFoundError(f"no *_M5.pkl in {folder}")
    offsets = _archive_offsets(files)
    rep = []
    for f in files:
        sym = f.name[: -len("_M5.pkl")]
        df = pd.read_pickle(f)
        df.index = pd.DatetimeIndex(df.index)
        month = df.index.to_period("M")
        off_h = pd.Series(month.astype(str)).map(offsets).fillna(3).astype(int).values
        server = df.index + pd.to_timedelta(off_h, unit="h")
        epoch = (server - pd.Timestamp("1970-01-01")) // pd.Timedelta(seconds=1)
        df.index = server_to_utc(np.asarray(epoch), "NY+7")
        old = read("mt5", sym, "M5")
        if old is not None and not old.empty:          # a real MT5 fetch wins over the archive
            df = df[~df.index.isin(old.index)]
            df = pd.concat([old, df])
        merged = save("mt5", sym, "M5", df, price_type="bid", adjusted=False, kind="mt5",
                      tz_rule="NY+7", note="includes ftmo_live archive, clock repaired")
        rep.append(dict(symbol=sym, first=merged.index[0].date(), last=merged.index[-1].date(),
                        bars=len(merged), offset_used="+".join(sorted({f"{v}h" for v in set(off_h)}))))
    return pd.DataFrame(rep)


def _archive_offsets(files: List[Path]) -> Dict[str, int]:
    """month -> hours the archive subtracted, from the metals' daily break."""
    ref = next((f for f in files if f.name.startswith(("XAUUSD", "XAGUSD"))), files[0])
    df = pd.read_pickle(ref)
    df.index = pd.DatetimeIndex(df.index)
    d = df[df.index.dayofweek < 4]
    out = {}
    for m, g in d.groupby(d.index.to_period("M")):
        days = g.index.normalize().nunique()
        cnt = g.groupby(g.index.hour).size().reindex(range(24), fill_value=0)
        miss = [h for h in range(24) if cnt[h] < 0.2 * days * 12]
        if len(miss) == 1:                       # break at server 00:00 -> label = 24 - offset
            out[str(m)] = (24 - miss[0]) % 24
    return out


# ------------------------------------------------------------------- loading

def available(inst: str, source: str) -> List[Tuple[str, str]]:
    """(symbol, tf) pairs cached for an instrument on a source."""
    syms = _symbols_for(inst).get(source, [])
    out = []
    for p in sorted((DATA / source).glob("*.parquet")) if (DATA / source).exists() else []:
        m = read_meta(source, *_split_name(p))
        if m.get("symbol") in syms or (":" in inst and m.get("symbol") == inst.split(":", 1)[1]):
            out.append((m["symbol"], m["tf"]))
    return out


def _split_name(p: Path) -> Tuple[str, str]:
    stem = p.name[: -len(".parquet")]
    sym_safe, tf = stem.rsplit("_", 1)
    m = {}
    mp = p.with_name(f"{stem}.meta.json")
    if mp.exists():
        m = json.loads(mp.read_text(encoding="utf-8"))
    return m.get("symbol", sym_safe), tf


def load(inst: str, source: str, tf: str, symbol: Optional[str] = None
         ) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """(signal bars at tf, execution bars, meta).

    Signal bars: the cache at tf if present, else resampled from finer bars.
    Execution bars: the FINEST bars available at every point in time - e.g. 1-minute
    where MT5 has them and 5-minute before that - spliced so no history is lost.
    Each execution bar carries its own length (dur_min)."""
    cands = [symbol] if symbol else _symbols_for(inst).get(source, [])
    have: Dict[str, List[str]] = {}
    for p in (DATA / source).glob("*.parquet") if (DATA / source).exists() else []:
        sym, t = _split_name(p)
        have.setdefault(sym, []).append(t)
    for sym in cands:
        tfs = have.get(sym, [])
        if not tfs:
            continue
        if tf == "D1":
            if "D1" not in tfs:
                continue
            sig, n1, n2 = repair(read(source, sym, "D1"), "D1")
            sig = sig.assign(dur_min=1440.0)
            return sig, sig, dict(read_meta(source, sym, "D1"), exec_tf="D1", signal_tf="D1",
                                  vault_start=str(vault_start()), repaired=dict(ohlc=n1, bad_prints=n2))
        finer = sorted([t for t in tfs if t != "D1" and TF_MIN[t] <= TF_MIN[tf]], key=lambda t: TF_MIN[t])
        if not finer:
            continue
        pieces, used, upto, rep_counts = [], [], None, {}
        for t in finer:                                   # finest first, coarser only before it starts
            df = read(source, sym, t)
            if df is None or df.empty:
                continue
            df, n1, n2 = repair(df, t)
            rep_counts[t] = dict(ohlc=n1, bad_prints=n2)
            if upto is not None:
                df = df[df.index < upto]
                if df.empty:
                    continue
            pieces.append(df.assign(dur_min=float(TF_MIN[t])))
            used.append(f"{t} from {df.index[0].date()}")
            upto = df.index[0]
        exe = pd.concat(pieces).sort_index()
        exe = exe[~exe.index.duplicated(keep="first")]
        # signal bars: the native cache where it exists, and before it starts, bars
        # resampled from the finer history - so a short 5m cache never cuts off years of 1m data
        built = [resample(pc.drop(columns="dur_min"), tf) for pc in pieces]
        sig_res = pd.concat(built).sort_index() if built else None
        if tf in tfs:
            native, _, _ = repair(read(source, sym, tf), tf)
            if sig_res is not None and len(sig_res) and sig_res.index[0] < native.index[0]:
                sig = pd.concat([sig_res[sig_res.index < native.index[0]], native])
            else:
                sig = native
        else:
            sig = sig_res
        sig = sig[~sig.index.duplicated(keep="last")].sort_index()
        lo = max(sig.index[0], exe.index[0])
        sig, exe = sig[sig.index >= lo], exe[exe.index >= lo]
        meta = dict(read_meta(source, sym, finer[0]), exec_tf=finer[0], signal_tf=tf, exec_detail=", ".join(used),
                    vault_start=str(vault_start()), repaired=rep_counts)
        return sig, exe, meta
    raise FileNotFoundError(f"no cached {source} data for {inst} at {tf} or finer - run: "
                            f"python lab.py fetch {inst} --source {source}")


# ------------------------------------------------------------------- quality

def quality(df: pd.DataFrame, tf: str, meta: Optional[dict] = None) -> dict:
    """Everything that can be wrong with a bar series. level: OK / WARN / BAD."""
    meta = meta or {}
    issues, stats, bad = [], {}, False
    n = len(df)
    stats["bars"] = n
    if n < 50:
        return dict(level="BAD", issues=["fewer than 50 bars"], stats=stats)
    _, n_ohlc, n_bad = repair(df, tf)
    o, h, l, c = (df[k].values for k in ("open", "high", "low", "close"))
    stats["ohlc_repaired"], stats["bad_prints"] = n_ohlc, n_bad
    if n_ohlc:
        issues.append(f"{n_ohlc:,} bars with high/low not containing open/close - repaired on load "
                      f"({n_ohlc / n:.2%})")
    if n_bad:
        issues.append(f"{n_bad:,} bad prints (jump the next bar ignores) - repaired on load")
    bad |= (n_bad / n > 0.02) or (n_ohlc / n > 0.25)
    flat = (h == l) & (np.r_[False, np.diff(c) == 0])
    runs = pd.Series(flat).groupby((~pd.Series(flat)).cumsum()).sum()
    stats["stale_runs"] = int((runs >= 30).sum())
    if stats["stale_runs"]:
        issues.append(f"{stats['stale_runs']} stale stretches (30+ identical flat bars)")
    if meta.get("kind") == "future_continuous":
        issues.append("Yahoo continuous future: NOT roll-adjusted - roll days show fake gaps")
    if meta.get("kind") == "index_untradable":
        issues.append("cash index: not tradable, no spread/volume - use for long history only")
    if tf != "D1":
        mins = tf_minutes(tf)
        gaps = np.diff(df.index.values).astype("timedelta64[m]").astype(np.int64)
        wk = df.index[1:].dayofweek
        # the market's own nightly closure (e.g. US stocks/ETFs shut 8h every night) is not a gap:
        # only count breaks well beyond the usual longest break of a normal weekday
        day = pd.Series(gaps, index=df.index[1:].normalize())
        usual = float(day[(wk > 0) & (wk < 5)].groupby(level=0).max().median()) if len(day) else 0.0
        limit = max(6 * 60, 1.5 * usual if np.isfinite(usual) else 0.0)
        big = (gaps > limit) & ~((wk == 0) | (wk == 6)) & (gaps < 4 * 24 * 60)
        stats["midweek_gaps"] = int(big.sum())
        span_weeks = (df.index[-1] - df.index[0]).days / 7 if n > 1 else 0
        if big.sum() > 0.2 * span_weeks + 5:                    # up to ~10 holidays a year is normal (US)
            issues.append(f"{int(big.sum())} mid-week gaps over {limit / 60:.0f}h (missing data or holidays)")
        tzmsg = _clock_check(df)
        if tzmsg:
            issues.append(tzmsg)
            bad = True
    level = "BAD" if bad else ("WARN" if issues else "OK")
    return dict(level=level, issues=issues, stats=stats)


def _clock_check(df: pd.DataFrame) -> Optional[str]:
    """Market hours are fixed in local exchange time. If the bar-count profile by
    New York hour is shifted by an hour between summer and winter, the
    timestamps were converted with the wrong offset for part of the year."""
    if (df.index[-1] - df.index[0]).days < 300:
        return None
    ny = df.index.tz_localize("UTC").tz_convert("America/New_York")
    dst = np.array([bool(t.dst()) for t in ny[:: max(1, len(ny) // 20000)]])
    hrs = ny.hour.values[:: max(1, len(ny) // 20000)]
    if dst.all() or (~dst).all():
        return None
    s = np.bincount(hrs[dst], minlength=24).astype(float)
    w = np.bincount(hrs[~dst], minlength=24).astype(float)
    if s.sum() == 0 or w.sum() == 0:
        return None
    s, w = s / s.sum(), w / w.sum()
    if np.std(s) < 0.15 / 24:                  # trades evenly round the clock (crypto): nothing to align
        return None
    score = {k: np.corrcoef(s, np.roll(w, k))[0, 1] for k in (-1, 0, 1)}
    best = max(score, key=score.get)
    if best != 0 and score[best] - score[0] > 0.05:
        return (f"CLOCK: bar times shift {best:+d}h between summer and winter "
                f"- wrong timezone conversion for part of the year")
    return None


def reconcile(inst: str) -> pd.DataFrame:
    """Do the sources agree? Daily returns compared pairwise where they overlap."""
    series = {}
    for src in catalog.SOURCES:
        for sym in _symbols_for(inst).get(src, []):
            d = read(src, sym, "D1")
            if d is not None and len(d) > 30:
                series[f"{src}:{sym}"] = d["close"]
    rows = []
    keys = list(series)
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a, b = series[keys[i]], series[keys[j]]
            ra, rb = np.log(a).diff(), np.log(b).diff()
            both = pd.concat([ra, rb], axis=1, join="inner").dropna()
            if len(both) < 30:
                continue
            x, y = both.iloc[:, 0], both.iloc[:, 1]
            rows.append(dict(a=keys[i], b=keys[j], overlap_days=len(both),
                             from_=both.index[0].date(), corr=round(float(x.corr(y)), 3),
                             median_abs_diff_bp=round(float((x - y).abs().median() * 1e4), 1),
                             big_disagreements=int(((x - y).abs() > 0.02).sum())))
    return pd.DataFrame(rows)
