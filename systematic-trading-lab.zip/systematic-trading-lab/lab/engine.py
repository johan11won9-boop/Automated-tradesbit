"""
engine.py - turns a strategy's signals into the trades a broker would really give you.

Fill rules (every one of these was a hole in an earlier backtest):
  * A signal on bar t is filled at the OPEN of the first execution bar after t
    closes - never at t's close. If the market is shut by then, the trade is
    skipped (a live bot couldn't have taken it at that price).
  * Longs buy at the ASK and sell at the BID; shorts the other way round. MT5 bars
    are bid bars with the real spread per bar, so the ask is rebuilt bar by bar.
    Trade-price data (Alpaca/Yahoo) is treated as mid with the venue's spread.
  * Stops and targets are checked on EVERY execution bar, 24 hours a day, the way
    a broker holds them - unless the strategy says its stops are bot-managed
    (broker_stops=False), then only inside its session.
  * A bar that OPENS beyond the stop fills at that open (gaps are not capped at -1R).
  * Exits are simulated on the finest data cached (1-minute if you have it), so a
    5-minute strategy's stop and target are resolved minute by minute.
  * If a single execution bar touches both stop and target, the order is unknown.
    The engine records both outcomes; the primary result uses the bar's own
    shape (a green bar went down before up, a red bar up before down) and the
    stats show whether the verdict changes under the worst case.
  * Swap is charged per rollover (17:00 New York) with the triple day, commission
    per side, optional extra stop slippage. Every cost is kept as its own column so
    the cost-sensitivity check can scale it without re-running.
"""
from __future__ import annotations

import ast
import hashlib
import inspect
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

import catalog
import data as dmod

# ------------------------------------------------------------------ definitions


@dataclass
class Exits:
    stop_pct: Optional[float] = None       # 0.0075 = 0.75% from the fill
    target_pct: Optional[float] = None
    stop_atr: Optional[float] = None       # multiples of ATR(atr_n) on the signal bars
    target_atr: Optional[float] = None
    atr_n: int = 14
    max_bars: Optional[int] = None         # signal bars (session bars if the strategy has a
                                           # session), counting the signal bar - like the bot
    flat_at: Optional[str] = None          # "HH:MM" in the strategy's tz: out before this each day
    flat_weekend: bool = False             # out before the weekend
    broker_stops: bool = True              # False = bot-managed stops, only checked in session
    exit_on_signal: bool = False           # strategy returns an 'exit' column


@dataclass
class WalkForward:
    """Re-select which instruments (and which variant per instrument) to trade,
    using only the past. Every selected trade is out-of-sample by construction."""
    train_months: int = 24
    trade_months: int = 6
    min_train_months: int = 12
    top: int = 6
    metric: str = "pf"                     # pf / mean_r / sharpe
    min_trades: int = 40
    variants: List[dict] = field(default_factory=lambda: [{}])
    max_cost_bp: Optional[float] = None    # drop candidates whose median round-trip cost is above
    min_metric: Optional[float] = None     # e.g. 1.0 with pf = only trade what made money in training


@dataclass
class Strategy:
    name: str
    fn: Callable
    timeframe: str
    params: dict
    exits: Exits = field(default_factory=Exits)
    mode: str = "event"                    # event (entries + exits) / position (target -1..+1)
    direction: str = "long"                # long / short / both
    tz: str = "UTC"                        # time zone of session / flat_at
    session: Optional[Tuple[str, str]] = None   # signal bars restricted to this window (glued)
    weekdays_only: bool = True
    grid: Dict[str, list] = field(default_factory=dict)   # neighbours for the plateau check
    instruments: List[str] = field(default_factory=list)
    source: str = "mt5"
    venue: str = "ftmo"
    walk_forward: Optional[WalkForward] = None
    max_positions: Optional[int] = None
    one_per_group: bool = False            # e.g. never hold WTI and Brent together
    allow_overlap: bool = False            # more than one trade per instrument at a time
    description: str = ""
    null_match: str = "hour"               # random entries from the same month+hour, or "month" for
                                           # strategies whose signal IS the clock (time-of-day effects)
    flat_map: Optional[Dict[str, Tuple[str, str]]] = None   # per instrument (flat_at, tz): one strategy
                                                            # over markets with different sessions

    def fingerprint(self, params: Optional[dict] = None) -> Tuple[str, str]:
        """(code hash, params hash). Code is hashed from its syntax tree, so
        comments and spacing don't count as a new variant; logic changes do."""
        try:
            src = inspect.getsource(self.fn)
            tree = ast.dump(ast.parse(src.strip()), annotate_fields=False)
        except (OSError, TypeError, SyntaxError):
            tree = self.fn.__name__
        exits = repr(sorted(vars(self.exits).items()))
        wf = repr(vars(self.walk_forward)) if self.walk_forward else ""
        code = hashlib.sha1((tree + exits + wf + self.timeframe + repr(self.session) + self.direction
                             + self.mode).encode()).hexdigest()[:10]
        p = hashlib.sha1(repr(sorted((params or self.params).items())).encode()).hexdigest()[:10]
        return code, p


REGISTRY: Dict[str, Strategy] = {}


def strategy(**kw):
    """Decorator: @strategy(timeframe="M5", params=dict(...), exits=Exits(...), ...)"""
    def wrap(fn):
        REGISTRY[fn.__name__] = Strategy(name=fn.__name__, fn=fn, **kw)
        return fn
    return wrap


# ------------------------------------------------------------------------ costs


@dataclass
class Costs:
    spread_bp: float
    commission_bp: float
    swap_long_pct: float                   # % of notional per night (fallback / non-MT5)
    swap_short_pct: float
    triple_day: int
    stop_slip_bp: float
    tp_gap_fill: str
    rollover_ny: str
    assumed: List[str] = field(default_factory=list)
    spec: Optional[dict] = None            # MT5 swap spec: mode, raw long/short, point, contract size

    def swap_pct(self, price, d: int):
        """% of notional per night for a position in direction d at this price.
        MT5 'points' swaps are a fixed price amount, so their % depends on the price;
        interest swaps are an annual % (/360). Anything implausible (over 0.5% a
        night) falls back to the venue default."""
        fallback = self.swap_long_pct if d > 0 else self.swap_short_pct
        sp = self.spec
        if not sp:
            return fallback
        raw = sp["swap_long_raw"] if d > 0 else sp["swap_short_raw"]
        mode = sp.get("swap_mode")
        price = np.asarray(price, dtype=float)
        with np.errstate(divide="ignore", invalid="ignore"):
            if mode == 1:
                pct = raw * sp["point"] / price * 100
            elif mode in (2, 3, 4):
                pct = raw / (price * sp["contract_size"]) * 100
            elif mode in (5, 6):
                pct = np.full_like(price, raw / 360.0)
            else:
                return fallback
        pct = np.where(np.isfinite(pct) & (np.abs(pct) <= 0.5), pct, fallback)
        return float(pct) if pct.ndim == 0 else pct


def costs_for(inst: str, venue: str, source: str, symbol: str) -> Costs:
    v = catalog.VENUES[venue]
    cls = catalog.cls_of(inst)
    base = dict(v["by_class"].get(cls, v["by_class"]["other"]))
    base.update(catalog.VENUE_OVERRIDES.get(venue, {}).get(inst, {}))
    sl, ss = v["swap"].get(cls, v["swap"]["other"])
    assumed = [f"{inst}: swap long {sl:+.4f}%/night, short {ss:+.4f}%/night (assumed for {cls})"]
    raw = dmod.mt5_specs().get(symbol) if source == "mt5" and venue == "ftmo" else None
    spec = None
    if raw and raw.get("swap_mode") in (1, 2, 3, 4, 5, 6) and raw.get("point"):
        spec = {k: raw[k] for k in ("swap_mode", "swap_long_raw", "swap_short_raw", "point", "contract_size")}
        base["triple_day"] = raw.get("triple_day", base["triple_day"])
        assumed = []
    return Costs(spread_bp=base["spread_bp"], commission_bp=base["commission_bp"],
                 swap_long_pct=sl, swap_short_pct=ss, triple_day=int(base["triple_day"]),
                 stop_slip_bp=v["stop_slip_bp"], tp_gap_fill=v["tp_gap_fill"],
                 rollover_ny=v["rollover_ny"], assumed=assumed, spec=spec)


# ----------------------------------------------------------------------- market


def _hm(s: str) -> pd.Timedelta:
    h, m = (int(x) for x in s.split(":"))
    return pd.Timedelta(hours=h, minutes=m)


def session_mask(index: pd.DatetimeIndex, session: Optional[Tuple[str, str]], tz: str,
                 weekdays_only: bool = True) -> np.ndarray:
    if session is None:
        return np.ones(len(index), dtype=bool) if not weekdays_only else \
            np.asarray(_local(index, tz).dayofweek < 5)
    loc = _local(index, tz)
    tod = loc - loc.normalize()
    m = (tod >= _hm(session[0])) & (tod < _hm(session[1]))
    if weekdays_only:
        m &= loc.dayofweek < 5
    return np.asarray(m)


def _local(index: pd.DatetimeIndex, tz: str) -> pd.DatetimeIndex:
    if tz.upper() == "UTC":
        return index
    return index.tz_localize("UTC").tz_convert(tz).tz_localize(None)


class Market:
    """One instrument's execution bars as arrays, with bid and ask rebuilt."""

    def __init__(self, inst: str, symbol: str, source: str, sig: pd.DataFrame, exe: pd.DataFrame,
                 meta: dict, costs: Costs, strat: Strategy):
        self.inst, self.symbol, self.source, self.meta, self.costs = inst, symbol, source, meta, costs
        self.sig = sig
        self.exe_tf = meta.get("exec_tf", strat.timeframe)
        # a daily bar "closes" at 23:59 of its date - the same clock the signal side uses
        step = pd.Timedelta(hours=23, minutes=59) if self.exe_tf == "D1" else \
            pd.Timedelta(minutes=dmod.tf_minutes(self.exe_tf))
        self.t = exe.index.values.astype("datetime64[ns]")
        if "dur_min" in exe:                                   # spliced 1m/5m history: each bar its own length
            dur = np.minimum(exe["dur_min"].to_numpy(dtype=float), 1439.0)
            self.tc = self.t + (dur * 60e9).astype("timedelta64[ns]")
        else:
            self.tc = (exe.index + step).values.astype("datetime64[ns]")
        spr = exe["spread_bp"].to_numpy(dtype=float).copy()
        known = np.isfinite(spr) & (spr > 0)
        fallback = costs.spread_bp
        if meta.get("price_type") == "bid" and known.mean() > 0.5:
            med = float(np.nanmedian(spr[known]))
            spr[~known] = med
            spr = np.minimum(spr, 50 * med)                    # a corrupt spread field can't fill at 2x price
            self.spread_from_data = True
        else:
            spr[:] = fallback
            self.spread_from_data = False
        self.spr = (spr / 1e4).astype(np.float32)              # round trip, fraction
        o, h, l, c = (exe[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
        h = np.maximum.reduce([h, o, c])
        l = np.minimum.reduce([l, o, c])
        if meta.get("price_type") == "bid":
            kb = np.ones_like(o)
            kf = 1 + spr / 1e4
        else:                                                   # mid / trade prices
            kb = 1 - spr / 1e4 / 2
            kf = (1 + spr / 1e4 / 2) / kb
        # bid prices + one ask/bid factor per bar (ask = bid * kf): 5 float32 arrays instead of 8 float64
        self.bo, self.bh, self.bl, self.bc = ((x * kb).astype(np.float32) for x in (o, h, l, c))
        self.kf = kf.astype(np.float32)
        self.n = len(self.t)
        self.sess = session_mask(exe.index, strat.session, strat.tz, strat.weekdays_only)
        self.roll = RollCal(exe.index[0], exe.index[-1] + pd.Timedelta(days=40), costs.rollover_ny,
                            costs.triple_day)
        self._flat_cache: Dict[str, np.ndarray] = {}

    def ask(self, a, b=None):
        """Ask open/high/low/close: pass the bid array and an index or slice."""
        return a[b] * self.kf[b] if b is not None else a * self.kf

    def j_at_or_after(self, ts: np.datetime64) -> int:
        return int(np.searchsorted(self.t, ts, side="left"))

    def j_closing_by(self, ts: np.datetime64) -> int:
        return int(np.searchsorted(self.tc, ts, side="right")) - 1

    def flat_points(self, flat_at: Optional[str], tz: str, weekend: bool) -> np.ndarray:
        """Sorted execution-bar indices that are the last bar before a forced exit."""
        key = f"{flat_at}|{tz}|{weekend}"
        if key in self._flat_cache:
            return self._flat_cache[key]
        pts = []
        idx = pd.DatetimeIndex(self.t)
        if flat_at:
            loc = _local(idx, tz)
            days = pd.DatetimeIndex(np.unique(loc.normalize()))
            inst = days + _hm(flat_at)
            if tz.upper() != "UTC":
                inst = inst.tz_localize(tz, ambiguous=True, nonexistent="shift_forward") \
                    .tz_convert("UTC").tz_localize(None)
            j = np.searchsorted(self.tc, inst.values, side="right") - 1
            pts.append(j[j >= 0])
        if weekend:
            gap = (self.t[1:] - self.tc[:-1]) > np.timedelta64(30, "h")
            pts.append(np.flatnonzero(gap))
        out = np.unique(np.concatenate(pts)) if pts else np.array([], dtype=int)
        self._flat_cache[key] = out
        return out


class RollCal:
    """Swap nights: rollovers at roll_ny New York time Mon-Fri, the triple day
    counting 3 (7 a week). nights(a, b) = W(b) - W(a)."""

    def __init__(self, first: pd.Timestamp, last: pd.Timestamp, roll_ny: str, triple_day: int):
        self.roll = _hm(roll_ny)
        self.d0 = (first - pd.Timedelta(days=3)).normalize()
        cal = pd.date_range(self.d0, last.normalize() + pd.Timedelta(days=10), freq="D")
        wd = cal.dayofweek
        w = np.where(wd < 5, 1.0, 0.0)
        w[wd == triple_day] = 3.0
        self.cum = np.cumsum(w)

    def __call__(self, ts) -> np.ndarray:
        idx = pd.DatetimeIndex(np.atleast_1d(np.asarray(ts, dtype="datetime64[ns]")))
        ny = idx.tz_localize("UTC").tz_convert("America/New_York").tz_localize(None)
        roll_date = (ny - self.roll).normalize()        # date of the last rollover at or before t
        pos = np.asarray((roll_date - self.d0) // pd.Timedelta(days=1)).astype(int)
        return self.cum[np.clip(pos, 0, len(self.cum) - 1)]


def _prop_day(index: pd.DatetimeIndex, tz: str = "Europe/Prague") -> np.ndarray:
    loc = index.tz_localize("UTC").tz_convert(tz).tz_localize(None).normalize()
    return loc.values.astype("datetime64[D]")


# --------------------------------------------------------------------- signals


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(n, min_periods=n).mean()


def signal_bars(strat: Strategy, sig: pd.DataFrame) -> pd.DataFrame:
    if strat.session is None and not strat.weekdays_only:
        return sig
    if strat.timeframe == "D1":
        return sig[sig.index.dayofweek < 5] if strat.weekdays_only else sig
    return sig[session_mask(sig.index, strat.session, strat.tz, strat.weekdays_only)]


def compute_signals(strat: Strategy, s: pd.DataFrame, params: dict) -> pd.DataFrame:
    """Normalise whatever the strategy returns into a frame aligned to s:
    entry (-1/0/1) [+ exit, exit_long, exit_short, stop_price, target_price,
    stop_dist, target_dist (price distance from the actual fill)] or pos (-1..1)."""
    out = strat.fn(s, params)
    if strat.mode == "position":
        pos = out["pos"] if isinstance(out, pd.DataFrame) else out
        pos = pd.Series(pos, index=s.index).astype(float).fillna(0.0).clip(-1, 1)
        if strat.direction == "long":
            pos = pos.clip(lower=0)
        elif strat.direction == "short":
            pos = pos.clip(upper=0)
        return pd.DataFrame({"pos": pos})
    if isinstance(out, pd.DataFrame):
        f = out.reindex(s.index).copy()
        e = f["entry"]
    else:
        f = pd.DataFrame(index=s.index)
        e = out
    e = pd.Series(e, index=s.index)
    if e.dtype == bool or str(e.dtype) == "boolean":
        e = e.fillna(False).astype(bool).astype(int) * (-1 if strat.direction == "short" else 1)
    e = e.fillna(0).astype(float).round().clip(-1, 1).astype(np.int8)
    if strat.direction == "long":
        e = e.where(e > 0, 0)
    elif strat.direction == "short":
        e = e.where(e < 0, 0)
    f["entry"] = e.astype(np.int8)
    for col in ("exit", "exit_long", "exit_short"):
        if col in f:
            f[col] = f[col].fillna(False).astype(bool)
    return f


# ------------------------------------------------------------------ event fills

TRADE_COLS = ["inst", "symbol", "dir", "sig_time", "entry_time", "exit_time", "entry_px", "exit_px",
              "risk_frac", "r_mid", "spread_r", "comm_r", "slip_r", "swap_r", "r_net", "r_pess", "r_opt",
              "ambiguous", "reason", "nights", "bars_held", "mae_r", "mfe_r", "exit_in_session",
              "j0", "jx", "variant"]


_NUM = ["dir", "entry_px", "exit_px", "risk_frac", "r_mid", "spread_r", "comm_r", "slip_r", "swap_r", "r_net",
        "r_pess", "r_opt", "nights", "bars_held", "mae_r", "mfe_r", "j0", "jx", "variant"]


def fix_types(t: pd.DataFrame) -> pd.DataFrame:
    """Concatenating empty frames turns columns into objects; force real types."""
    t = t.copy()
    for c in _NUM:
        if c in t:
            t[c] = pd.to_numeric(t[c], errors="coerce")
    for c in ("dir", "bars_held", "j0", "jx", "variant"):
        if c in t:
            t[c] = t[c].fillna(0).astype(np.int64)
    for c in ("ambiguous", "exit_in_session"):
        if c in t:
            t[c] = t[c].astype(bool)
    for c in ("sig_time", "entry_time", "exit_time"):
        if c in t:
            t[c] = pd.to_datetime(t[c])
    return t


def _first_hit(mask_fn, j0: int, j1: int) -> int:
    """First index in [j0, j1] where mask is true, scanning in growing chunks
    (most trades end early, so this avoids touching the whole hold)."""
    size = 256
    j = j0
    while j <= j1:
        k = min(j1, j + size - 1)
        m = mask_fn(j, k)
        if m.any():
            return j + int(np.argmax(m))
        j = k + 1
        size *= 4
    return -1


def simulate_entry(mk: Market, strat: Strategy, s_index: pd.DatetimeIndex, sig_close: np.ndarray,
                   i: int, d: int, frame: pd.DataFrame, atr_arr: Optional[np.ndarray],
                   exit_idx: Optional[np.ndarray], max_delay: np.timedelta64,
                   variant: int = 0, levels: Optional[Tuple[float, float]] = None) -> Optional[dict]:
    """One trade from signal bar i in direction d. None if it can't be taken.
    levels = (stop distance, target distance) in price, overriding the frame (used by
    the random-entry comparison so random trades get the real trade's exits)."""
    ex = strat.exits
    c = mk.costs
    j0 = mk.j_at_or_after(sig_close[i])
    if j0 >= mk.n or mk.t[j0] - sig_close[i] > max_delay:
        return None
    # ---- time-based last bar
    jT = mk.n - 1
    open_at_end = True
    if ex.max_bars:
        L = i + ex.max_bars - 1
        if L < len(sig_close):
            jT = min(jT, mk.j_closing_by(sig_close[L]))
            open_at_end = False
    flat_at, flat_tz = ex.flat_at, strat.tz
    if strat.flat_map and mk.inst in strat.flat_map:
        flat_at, flat_tz = strat.flat_map[mk.inst]
    if flat_at or ex.flat_weekend:
        fp = mk.flat_points(flat_at, flat_tz, ex.flat_weekend)
        k = np.searchsorted(fp, j0, side="left")
        if k < len(fp) and fp[k] <= jT:
            jT, open_at_end = int(fp[k]), False
    jX = None
    if exit_idx is not None and len(exit_idx):
        k = np.searchsorted(exit_idx, i, side="right")
        if k < len(exit_idx):
            jx = mk.j_at_or_after(sig_close[exit_idx[k]])
            if jx <= jT:
                jX, jT, open_at_end = jx, jx, False
    if jT < j0:
        jT = j0
    # ---- fill and levels
    sp0 = float(mk.spr[j0])
    if d > 0:
        entry = float(mk.bo[j0]) * float(mk.kf[j0])
        mid_in = entry / (1 + sp0 / 2)
    else:
        entry = float(mk.bo[j0])
        mid_in = entry * (1 + sp0 / 2)
    stop = target = None
    sdist = tdist = np.nan
    if levels is not None:
        sdist, tdist = levels
    else:
        if "stop_dist" in frame:
            sdist = float(frame["stop_dist"].iat[i])
        if "target_dist" in frame:
            tdist = float(frame["target_dist"].iat[i])
    if np.isfinite(sdist) and sdist > 0:
        stop = entry - d * sdist
    elif "stop_price" in frame and np.isfinite(frame["stop_price"].iat[i]):
        stop = float(frame["stop_price"].iat[i])
    elif ex.stop_pct:
        stop = entry * (1 - d * ex.stop_pct)
    elif ex.stop_atr and atr_arr is not None and np.isfinite(atr_arr[i]):
        stop = entry - d * ex.stop_atr * atr_arr[i]
    if np.isfinite(tdist) and tdist > 0:
        target = entry + d * tdist
    elif "target_price" in frame and np.isfinite(frame["target_price"].iat[i]):
        target = float(frame["target_price"].iat[i])
    elif ex.target_pct:
        target = entry * (1 + d * ex.target_pct)
    elif ex.target_atr and atr_arr is not None and np.isfinite(atr_arr[i]):
        target = entry + d * ex.target_atr * atr_arr[i]
    if stop is not None and d * (entry - stop) <= 0:
        return None                                   # stop on the wrong side of the fill
    if stop is not None:
        risk = abs(entry - stop) / entry
    elif atr_arr is not None and np.isfinite(atr_arr[i]) and atr_arr[i] > 0:
        risk = atr_arr[i] / entry                     # no stop: 1R = one ATR
    else:
        risk = 0.01
    # ---- search for the exit
    bl, bh, bo, kf = mk.bl, mk.bh, mk.bo, mk.kf
    sess = mk.sess
    managed = not ex.broker_stops

    def hits(a, b):
        m = np.zeros(b - a + 1, dtype=bool)
        if d > 0:
            if stop is not None:
                m |= bl[a:b + 1] <= stop
            if target is not None:
                m |= bh[a:b + 1] >= target
        else:
            k = kf[a:b + 1]
            if stop is not None:
                m |= bh[a:b + 1] * k >= stop
            if target is not None:
                m |= bl[a:b + 1] * k <= target
        if managed:
            m &= sess[a:b + 1]
        return m

    jend = jT if jX is None else jX - 1
    j = _first_hit(hits, j0, jend) if (stop is not None or target is not None) and jend >= j0 else -1
    ambiguous, reason = False, ""
    alt = None
    slip = c.stop_slip_bp / 1e4
    if j >= 0:
        # gap through a level at this bar's open (not on the entry bar - the open IS the entry)
        gap_open = j > j0
        po = float(bo[j]) if d > 0 else float(bo[j] * kf[j])
        if gap_open and stop is not None and d * (po - stop) <= 0:
            px, reason = po, "gap_stop"
        elif gap_open and target is not None and d * (po - target) >= 0:
            px, reason = (po if c.tp_gap_fill == "open" else target), "gap_target"
        else:
            if d > 0:
                hs = stop is not None and bl[j] <= stop
                ht = target is not None and bh[j] >= target
            else:
                hs = stop is not None and bh[j] * kf[j] >= stop
                ht = target is not None and bl[j] * kf[j] <= target
            px_s = stop * (1 - d * slip) if stop is not None else None
            if hs and ht:
                ambiguous = True
                green = mk.bc[j] >= mk.bo[j]
                stop_first = green if d > 0 else not green     # O-L-H-C on green bars, O-H-L-C on red
                if stop_first:
                    px, reason, alt = px_s, "stop", target
                else:
                    px, reason, alt = target, "target", px_s
            elif hs:
                px, reason = px_s, "stop"
            else:
                px, reason = target, "target"
        jx = j
        exit_time = mk.t[j]
    else:
        if open_at_end and jX is None:
            return dict(open_at_end=True)
        jx = jT
        if jX is not None:
            px, reason, exit_time = (float(bo[jX]) if d > 0 else float(bo[jX] * kf[jX])), "exit_signal", mk.t[jX]
        else:
            px = float(mk.bc[jx]) if d > 0 else float(mk.bc[jx] * kf[jx])
            reason = "time"
            if flat_at or ex.flat_weekend:
                fp = mk.flat_points(flat_at, flat_tz, ex.flat_weekend)
                if jx in set(fp[max(0, np.searchsorted(fp, jx) - 1): np.searchsorted(fp, jx) + 1]):
                    reason = "flat"
            exit_time = mk.tc[jx]
    # ---- R accounting (all in units of the initial risk)
    spr_x = float(mk.spr[jx])

    def r_of(p_exit):
        m_out = p_exit * (1 + spr_x / 2) if d > 0 else p_exit / (1 + spr_x / 2)
        return d * (m_out - mid_in) / mid_in / risk, d * (p_exit - entry) / entry / risk

    r_mid, r_ba = r_of(px)
    spread_r = r_mid - r_ba
    slip_r = 0.0
    if reason == "stop" and slip:
        r_mid_noslip, _ = r_of(stop)
        slip_r = max(0.0, r_mid_noslip - r_mid)
        r_mid = r_mid_noslip
    comm_r = 2 * c.commission_bp / 1e4 / risk
    nights = float(mk.roll(exit_time)[0] - mk.roll(mk.t[j0])[0])
    swap_r = nights * c.swap_pct(mid_in, d) / 100 / risk
    r_net = r_mid - spread_r - slip_r - comm_r + swap_r
    if ambiguous:
        r_alt_mid, r_alt_ba = r_of(alt)
        r_alt = r_alt_mid - (r_alt_mid - r_alt_ba) - comm_r + swap_r
        r_pess, r_opt = (r_net, r_alt) if reason == "stop" else (r_alt, r_net)
    else:
        r_pess = r_opt = r_net
    # excursions (bid/ask aware)
    if d > 0:
        mae = (float(bl[j0:jx + 1].min()) - entry) / entry / risk
        mfe = (float(bh[j0:jx + 1].max()) - entry) / entry / risk
    else:
        mae = (entry - float((bh[j0:jx + 1] * kf[j0:jx + 1]).max())) / entry / risk
        mfe = (entry - float((bl[j0:jx + 1] * kf[j0:jx + 1]).min())) / entry / risk
    return dict(inst=mk.inst, symbol=mk.symbol, dir=d, sig_time=s_index[i], entry_time=mk.t[j0],
                exit_time=exit_time, entry_px=entry, exit_px=px, risk_frac=risk, r_mid=r_mid,
                spread_r=spread_r, comm_r=comm_r, slip_r=slip_r, swap_r=swap_r, r_net=r_net,
                r_pess=r_pess, r_opt=r_opt, ambiguous=ambiguous, reason=reason, nights=nights,
                bars_held=jx - j0 + 1, mae_r=min(mae, 0.0), mfe_r=max(mfe, 0.0),
                exit_in_session=bool(mk.sess[jx]), j0=j0, jx=jx, variant=variant)


def exit_indices(strat: Strategy, frame: pd.DataFrame) -> Dict[int, Optional[np.ndarray]]:
    """Signal-bar indices where an exit signal fires, per trade direction (+1 / -1).
    'exit' closes either side; 'exit_long' / 'exit_short' only their own."""
    if not strat.exits.exit_on_signal:
        return {1: None, -1: None}
    both = frame["exit"].to_numpy(bool) if "exit" in frame else np.zeros(len(frame), bool)
    out = {}
    for d, col in ((1, "exit_long"), (-1, "exit_short")):
        m = both | frame[col].to_numpy(bool) if col in frame else both
        out[d] = np.flatnonzero(m)
    return out


def run_events(mk: Market, strat: Strategy, s: pd.DataFrame, frame: pd.DataFrame,
               variant: int = 0) -> Tuple[pd.DataFrame, dict]:
    sig_step = pd.Timedelta(days=1) if strat.timeframe == "D1" else pd.Timedelta(minutes=dmod.tf_minutes(strat.timeframe))
    sig_close = (s.index + sig_step).values.astype("datetime64[ns]")
    if strat.timeframe == "D1":
        # a daily bar's close is the session close; the next fill is the next day's open
        sig_close = (s.index + pd.Timedelta(hours=23, minutes=59)).values.astype("datetime64[ns]")
        max_delay = np.timedelta64(4, "D")
    else:
        max_delay = np.timedelta64(int(sig_step.total_seconds()), "s")
    atr_arr = atr(s, strat.exits.atr_n).to_numpy() if (strat.exits.stop_atr or strat.exits.target_atr or not
                                                       strat.exits.stop_pct) else None
    exit_by_dir = exit_indices(strat, frame)
    ent = frame["entry"].to_numpy()
    rows, busy_until = [], np.datetime64("NaT")
    skipped = dict(market_shut=0, busy=0, open_at_end=0)
    s_index = s.index
    s_open = s.index.values.astype("datetime64[ns]")
    for i in np.flatnonzero(ent):
        # flat again once the previous trade is out: a signal counts if its bar CLOSES after the exit
        # (a stop hit inside a bar, then that bar's close signals again - a live bot would take it)
        if not strat.allow_overlap and not np.isnat(busy_until) and sig_close[i] <= busy_until:
            skipped["busy"] += 1
            continue
        tr = simulate_entry(mk, strat, s_index, sig_close, i, int(ent[i]), frame, atr_arr,
                            exit_by_dir[int(ent[i])], max_delay, variant)
        if tr is None:
            skipped["market_shut"] += 1
            continue
        if tr.get("open_at_end"):
            skipped["open_at_end"] += 1
            break
        rows.append(tr)
        busy_until = tr["exit_time"]
    return pd.DataFrame(rows, columns=TRADE_COLS), skipped


# --------------------------------------------------------------- position mode


def run_positions(mk: Market, strat: Strategy, s: pd.DataFrame, frame: pd.DataFrame
                  ) -> Tuple[pd.DataFrame, pd.Series]:
    """Target position decided at each signal bar's close, held from the next
    execution bar's open. Returns (segments as trades, per-execution-bar P&L as a
    fraction of notional at 1x)."""
    sig_step = pd.Timedelta(days=1) if strat.timeframe == "D1" else pd.Timedelta(minutes=dmod.tf_minutes(strat.timeframe))
    eff = (s.index + (pd.Timedelta(hours=23, minutes=59) if strat.timeframe == "D1" else sig_step)).values
    pos_sig = frame["pos"].to_numpy(dtype=float)
    k = np.searchsorted(eff, mk.t, side="right") - 1          # last decision in force at bar open
    p = np.where(k >= 0, pos_sig[np.clip(k, 0, None)], 0.0)
    kf = mk.kf.astype(float)
    mid_o = mk.bo.astype(float) * (1 + kf) / 2
    mid_c = mk.bc.astype(float) * (1 + kf) / 2
    prev_p = np.r_[0.0, p[:-1]]
    prev_c = np.r_[mid_o[0], mid_c[:-1]]
    pnl = prev_p * (mid_o / prev_c - 1) + p * (mid_c / mid_o - 1)
    turn = np.abs(p - prev_p)
    c = mk.costs
    cost = turn * (mk.spr.astype(float) / 2 + c.commission_bp / 1e4)
    w = mk.roll(mk.t)
    nights = np.diff(np.r_[w[0], w])
    rate = np.where(prev_p > 0, c.swap_pct(mid_o, 1), np.where(prev_p < 0, c.swap_pct(mid_o, -1), 0.0))
    swap = np.abs(prev_p) * rate * nights / 100
    net = pnl - cost + swap
    bar_pnl = pd.Series(net, index=pd.DatetimeIndex(mk.t))
    # segments of constant sign = "trades" for trade-level stats
    sign = np.sign(p)
    seg = np.r_[0, np.cumsum(sign[1:] != sign[:-1])]
    rows = []
    df = pd.DataFrame({"seg": seg, "sign": sign, "net": net, "gross": pnl, "cost": cost, "swap": swap,
                       "t": mk.t})
    for g, x in df[df.sign != 0].groupby("seg"):
        d = int(x.sign.iat[0])
        risk = 1.0                                   # position trades are in fractions of notional
        rows.append(dict(inst=mk.inst, symbol=mk.symbol, dir=d, sig_time=x.t.iat[0], entry_time=x.t.iat[0],
                         exit_time=x.t.iat[-1], entry_px=np.nan, exit_px=np.nan, risk_frac=risk,
                         r_mid=x.gross.sum() / risk, spread_r=x.cost.sum() / risk, comm_r=0.0, slip_r=0.0,
                         swap_r=x.swap.sum() / risk, r_net=x.net.sum() / risk, r_pess=x.net.sum() / risk,
                         r_opt=x.net.sum() / risk, ambiguous=False, reason="position", nights=0.0,
                         bars_held=len(x), mae_r=0.0, mfe_r=0.0, exit_in_session=True,
                         j0=int(x.index[0]), jx=int(x.index[-1]), variant=0))
    return pd.DataFrame(rows, columns=TRADE_COLS), bar_pnl


# -------------------------------------------------------------------- portfolio


def cap_positions(trades: pd.DataFrame, strat: Strategy) -> Tuple[pd.DataFrame, int]:
    """Max open positions / one per correlated group, first come first served."""
    if trades.empty or (not strat.max_positions and not strat.one_per_group):
        return trades, 0
    t = trades.sort_values(["entry_time", "inst"]).reset_index(drop=True)
    open_: List[Tuple[np.datetime64, str]] = []
    keep = np.zeros(len(t), dtype=bool)
    for k, row in enumerate(t.itertuples(index=False)):
        open_ = [(x, g) for x, g in open_ if x > row.entry_time]
        g = catalog.group_of(row.inst)
        if strat.max_positions and len(open_) >= strat.max_positions:
            continue
        if strat.one_per_group and any(gg == g for _, gg in open_):
            continue
        keep[k] = True
        open_.append((row.exit_time, g))
    return t[keep].reset_index(drop=True), int((~keep).sum())


def equity_by_day(trades: pd.DataFrame, markets: Dict[str, Market], mode: str = "event",
                  bar_pnl: Optional[Dict[str, pd.Series]] = None) -> pd.DataFrame:
    """Daily account path in R (event mode, 1R per trade) or in notional fractions
    (position mode). Columns: start_bal, min_eq, end_eq, end_bal - cumulative, by
    FTMO day (midnight Prague). min_eq uses every open trade's worst bid/ask in
    each execution bar, so the daily-loss rule is checked intraday."""
    if mode == "position":
        allp = pd.concat(bar_pnl.values(), axis=1).fillna(0.0).sum(axis=1) if bar_pnl else pd.Series(dtype=float)
        if allp.empty:
            return pd.DataFrame(columns=["start_bal", "min_eq", "end_eq", "end_bal", "trades"])
        eq = allp.cumsum()
        day = _prop_day(allp.index)
        g = pd.DataFrame({"eq": eq.values, "day": day}).groupby("day")["eq"]
        out = pd.DataFrame({"end_eq": g.last(), "min_eq": g.min()})
        out["start_bal"] = out["end_eq"].shift(1).fillna(0.0)
        out["min_eq"] = np.minimum(out["min_eq"], out["start_bal"])
        out["end_bal"] = out["end_eq"]
        out["trades"] = 0
        out.index = pd.DatetimeIndex(out.index)
        return out[["start_bal", "min_eq", "end_eq", "end_bal", "trades"]]
    if trades.empty:
        return pd.DataFrame(columns=["start_bal", "min_eq", "end_eq", "end_bal", "trades"])
    # Open P&L only exists while trades are open, so only those bars are built, then
    # bucketed to 5 minutes (worst bid/ask in the bucket for the intraday low).
    per_inst = []
    for inst, mk in markets.items():
        tt = trades[trades.inst == inst]
        if tt.empty:
            continue
        ts, ucs, uls = [], [], []
        for r in tt.itertuples(index=False):
            a, b = int(r.j0), int(r.jx)
            if b > a:
                sl = slice(a, b)
                if r.dir > 0:
                    uc = (mk.bc[sl].astype(float) - r.entry_px) / r.entry_px / r.risk_frac
                    ul = (mk.bl[sl].astype(float) - r.entry_px) / r.entry_px / r.risk_frac
                else:
                    k = mk.kf[sl].astype(float)
                    uc = (r.entry_px - mk.bc[sl] * k) / r.entry_px / r.risk_frac
                    ul = (r.entry_px - mk.bh[sl] * k) / r.entry_px / r.risk_frac
                ts.append(mk.t[sl])
                ucs.append(uc)
                uls.append(ul)
            ts.append(np.array([np.datetime64(r.exit_time, "ns")]))     # flat again from the exit
            ucs.append(np.zeros(1))
            uls.append(np.zeros(1))
        df = pd.DataFrame({"t": np.concatenate(ts), "uc": np.concatenate(ucs), "ul": np.concatenate(uls)})
        df = df.groupby("t", sort=True).sum()                            # overlapping trades add up
        b5 = df.index.floor("5min")
        g = df.groupby(b5)
        per_inst.append(pd.DataFrame({"uc": g["uc"].last(), "ul": g["ul"].min()}))
    G = np.unique(np.concatenate([x.index.values for x in per_inst])) if per_inst else np.array([], "datetime64[ns]")
    ex_t = trades["exit_time"].values.astype("datetime64[ns]")
    G = np.unique(np.concatenate([G, ex_t.astype("datetime64[ns]")]))
    tot_c = np.zeros(len(G))
    tot_l = np.zeros(len(G))
    for x in per_inst:
        k = np.searchsorted(x.index.values, G, side="right") - 1        # carry the last value (market shut)
        ok = k >= 0
        kk = np.clip(k, 0, None)
        tot_c += np.where(ok, x["uc"].to_numpy()[kk], 0.0)
        tot_l += np.where(ok, x["ul"].to_numpy()[kk], 0.0)
    order = np.argsort(ex_t)
    ex_t, ex_r = ex_t[order], trades["r_net"].to_numpy()[order]
    cum_r = np.r_[0.0, np.cumsum(ex_r)]
    realised = cum_r[np.searchsorted(ex_t, G, side="right")]
    eq_c = realised + tot_c
    eq_l = realised + tot_l
    day = _prop_day(pd.DatetimeIndex(G))
    df = pd.DataFrame({"day": day, "real": realised, "eq_c": eq_c, "eq_l": eq_l})
    g = df.groupby("day")
    out = pd.DataFrame({"end_bal": g["real"].last(), "end_eq": g["eq_c"].last(), "min_eq": g["eq_l"].min()})
    out["start_bal"] = out["end_bal"].shift(1).fillna(0.0)
    out["start_eq"] = out["end_eq"].shift(1).fillna(0.0)
    out["min_eq"] = np.minimum(out["min_eq"], out[["start_eq", "end_bal"]].min(axis=1))
    ent_day = pd.Series(_prop_day(pd.DatetimeIndex(trades["entry_time"]))).value_counts()
    out["trades"] = ent_day.reindex(out.index).fillna(0).astype(int).values
    out.index = pd.DatetimeIndex(out.index)
    return out[["start_bal", "min_eq", "end_eq", "end_bal", "trades"]]


# ---------------------------------------------------------------------- one run


@dataclass
class Run:
    strat: Strategy
    params: dict
    trades: pd.DataFrame
    daily: pd.DataFrame
    markets: Dict[str, Market]
    frames: Dict[str, Tuple[pd.DataFrame, pd.DataFrame]]     # inst -> (signal bars, signal frame)
    skipped: dict
    period: Tuple[pd.Timestamp, pd.Timestamp]
    info: dict
    bar_pnl: Optional[Dict[str, pd.Series]] = None


def prepare_markets(strat: Strategy, instruments: List[str], source: str, venue: str,
                    final: bool, start: Optional[str] = None, end: Optional[str] = None,
                    data_override: Optional[Dict[str, Tuple[pd.DataFrame, pd.DataFrame, dict]]] = None
                    ) -> Tuple[Dict[str, Market], dict]:
    markets, info = {}, dict(vault={}, data={}, assumed=[])
    for inst in instruments:
        if data_override and inst in data_override:
            sig, exe, meta = data_override[inst]
        else:
            sig, exe, meta = dmod.load(inst, source, strat.timeframe)
        symbol = meta.get("symbol", inst)
        vs = pd.Timestamp(meta["vault_start"]) if meta.get("vault_start") else None
        if start:
            sig, exe = sig[sig.index >= pd.Timestamp(start)], exe[exe.index >= pd.Timestamp(start)]
        if end:
            sig, exe = sig[sig.index < pd.Timestamp(end)], exe[exe.index < pd.Timestamp(end)]
        if vs is not None and not final:
            sig, exe = sig[sig.index < vs], exe[exe.index < vs]
        if len(sig):
            exe = exe[(exe.index >= sig.index[0]) & (exe.index <= sig.index[-1] + pd.Timedelta(days=45))]
        if len(sig) < 100 or len(exe) < 100:
            continue
        costs = costs_for(inst, venue, source, symbol)
        markets[inst] = Market(inst, symbol, source, sig, exe, meta, costs, strat)
        info["vault"][inst] = str(vs.date()) if vs is not None else None
        info["data"][inst] = dict(symbol=symbol, signal_tf=strat.timeframe,
                                  exec_tf=meta.get("exec_detail") or meta.get("exec_tf"),
                                  first=str(sig.index[0])[:16], last=str(sig.index[-1])[:16],
                                  spread="per-bar from data" if markets[inst].spread_from_data
                                  else f"{costs.spread_bp}bp venue default",
                                  price_type=meta.get("price_type"))
        info["assumed"] += costs.assumed
    return markets, info


def run(strat: Strategy, instruments: Optional[List[str]] = None, source: Optional[str] = None,
        venue: Optional[str] = None, params: Optional[dict] = None, final: bool = False,
        start: Optional[str] = None, end: Optional[str] = None,
        markets: Optional[Dict[str, Market]] = None, info: Optional[dict] = None,
        data_override=None) -> Run:
    instruments = instruments or strat.instruments
    source = source or strat.source
    venue = venue or strat.venue
    params = dict(strat.params, **(params or {}))
    if markets is None:
        markets, info = prepare_markets(strat, instruments, source, venue, final, start, end, data_override)
    if not markets:
        raise RuntimeError("no data for any instrument - run `python lab.py fetch ...` first")
    variants = strat.walk_forward.variants if strat.walk_forward else [{}]
    all_tr, frames, skipped, bar_pnl = [], {}, dict(market_shut=0, busy=0, open_at_end=0), {}
    for inst, mk in markets.items():
        s = signal_bars(strat, mk.sig)
        for vi, var in enumerate(variants):
            p = dict(params, **var)
            frame = compute_signals(strat, s, p)
            if vi == 0:
                frames[inst] = (s, frame)
            if strat.mode == "position":
                tr, bp = run_positions(mk, strat, s, frame)
                bar_pnl[inst] = bp
                sk = {}
            else:
                tr, sk = run_events(mk, strat, s, frame, variant=vi)
            for k, v in sk.items():
                skipped[k] += v
            all_tr.append(tr)
    trades = pd.concat(all_tr, ignore_index=True) if all_tr else pd.DataFrame(columns=TRADE_COLS)
    if strat.walk_forward and strat.mode == "event":
        trades, wf_log = walk_forward_select(trades, markets, strat.walk_forward)
        info = dict(info or {}, walk_forward=wf_log)
    trades = fix_types(trades)
    trades, capped = cap_positions(trades, strat)
    skipped["capped"] = capped
    trades = fix_types(trades).sort_values("entry_time").reset_index(drop=True)
    daily = equity_by_day(trades, markets, strat.mode, bar_pnl if strat.mode == "position" else None)
    lo = min(mk.t[0] for mk in markets.values())
    hi = max(mk.t[-1] for mk in markets.values())
    return Run(strat, params, trades, daily, markets, frames, skipped,
               (pd.Timestamp(lo), pd.Timestamp(hi)), info or {}, bar_pnl or None)


# --------------------------------------------------------------- walk-forward


def _metric(r: np.ndarray, metric: str) -> float:
    if len(r) == 0:
        return -np.inf
    if metric == "pf":
        gl = -r[r < 0].sum()
        return r[r > 0].sum() / gl if gl > 0 else np.inf
    if metric == "sharpe":
        return r.mean() / r.std(ddof=1) * np.sqrt(len(r)) if len(r) > 1 and r.std() > 0 else -np.inf
    return float(r.mean())


def walk_forward_select(trades: pd.DataFrame, markets: Dict[str, Market], wf: WalkForward
                        ) -> Tuple[pd.DataFrame, list]:
    if trades.empty:
        return trades, []
    first = min(pd.Timestamp(mk.t[0]) for mk in markets.values())
    last = max(pd.Timestamp(mk.t[-1]) for mk in markets.values())
    T = (first + pd.DateOffset(months=wf.min_train_months)).normalize()
    et = pd.DatetimeIndex(trades["entry_time"])
    xt = pd.DatetimeIndex(trades["exit_time"])
    keep, log = [], []
    while T < last:
        T2 = T + pd.DateOffset(months=wf.trade_months)
        lo = T - pd.DateOffset(months=wf.train_months)
        train = trades[(et >= lo) & (xt < T)]
        best: Dict[str, Tuple[float, int]] = {}
        for (inst, v), g in train.groupby(["inst", "variant"]):
            if len(g) < wf.min_trades:
                continue
            if wf.max_cost_bp is not None:
                mk = markets[inst]
                win = (mk.t >= np.datetime64(lo)) & (mk.t < np.datetime64(T)) & mk.sess
                cost = np.median(mk.spr[win]) * 1e4 if win.any() else np.inf
                cost += 2 * mk.costs.commission_bp
                if cost > wf.max_cost_bp:
                    continue
            m = _metric(g["r_net"].to_numpy(), wf.metric)
            if inst not in best or m > best[inst][0]:
                best[inst] = (m, int(v))
        ranked = sorted(best.items(), key=lambda kv: kv[1][0], reverse=True)[: wf.top]
        picks = {inst: v for inst, (m, v) in ranked if wf.min_metric is None or m > wf.min_metric}
        sel = trades[(et >= T) & (et < T2)]
        sel = sel[[picks.get(i) == v for i, v in zip(sel["inst"], sel["variant"])]]
        keep.append(sel)
        log.append(dict(window=f"{T.date()}..{T2.date()}",
                        picks=", ".join(f"{i}(v{v})" for i, v in picks.items()) or "none"))
        T = T2
    keep = [k for k in keep if len(k)]
    out = pd.concat(keep) if keep else trades.iloc[0:0]
    return fix_types(out.reset_index(drop=True)), log


# ------------------------------------------------------------- null & lookahead


def null_trades(run_: Run, draws: int, seed: int = 7) -> pd.DataFrame:
    """For every real trade, `draws` random entries on the same instrument, in the
    same calendar month and hour of day (or just the same month, for strategies whose
    signal is the clock), with the same exits: the real trade's stop and target
    distance and the strategy's own exit rule.

    Direction: a long-only (or short-only) strategy's random entries take its side.
    A strategy that trades both ways gets random entries whose longs/shorts are drawn
    in the SAME PROPORTION as its own trades that month on that market - so riding
    the month's trend is matched, and only picking the right days/moments counts.
    Answers: does the signal pick better moments than chance would?"""
    rng = np.random.default_rng(seed)
    strat = run_.strat
    rows = []
    if run_.trades.empty or strat.mode != "event":
        return pd.DataFrame(columns=TRADE_COLS + ["of"])
    for inst, g in run_.trades.groupby("inst"):
        mk = run_.markets[inst]
        s, frame = run_.frames[inst]
        sig_step = pd.Timedelta(days=1) if strat.timeframe == "D1" else pd.Timedelta(minutes=dmod.tf_minutes(strat.timeframe))
        sig_close = (s.index + (pd.Timedelta(hours=23, minutes=59) if strat.timeframe == "D1" else sig_step)
                     ).values.astype("datetime64[ns]")
        max_delay = np.timedelta64(4, "D") if strat.timeframe == "D1" else np.timedelta64(int(sig_step.total_seconds()), "s")
        atr_arr = atr(s, strat.exits.atr_n).to_numpy()
        empty = frame.iloc[:, 0:0]
        exit_by_dir = exit_indices(strat, frame)
        sdist = frame["stop_dist"].to_numpy(float) if "stop_dist" in frame else None
        tdist = frame["target_dist"].to_numpy(float) if "target_dist" in frame else None
        month = s.index.to_period("M").astype(str).to_numpy()
        hour = s.index.hour.to_numpy()
        keym = pd.Series(np.arange(len(s))).groupby(month).apply(lambda x: x.to_numpy()).to_dict()
        keyb = keym if strat.null_match == "month" else \
            pd.Series(np.arange(len(s))).groupby([month, hour]).apply(lambda x: x.to_numpy()).to_dict()
        pos = s.index.get_indexer(pd.DatetimeIndex(g["sig_time"]))
        dirs = g["dir"].to_numpy()
        both_ways = (dirs > 0).any() and (dirs < 0).any()
        mdirs = pd.Series(dirs, index=np.where(pos >= 0, month[np.clip(pos, 0, None)], "")).groupby(level=0) \
            .apply(lambda x: x.to_numpy()).to_dict() if both_ways else {}
        for tid, i, d in zip(g.index, pos, dirs):
            if i < 0:
                continue
            key = month[i] if strat.null_match == "month" else (month[i], hour[i])
            pool = keyb.get(key)
            if pool is None or len(pool) < 5:
                pool = keym.get(month[i])
            lv = None
            if sdist is not None or tdist is not None:
                lv = (sdist[i] if sdist is not None else np.nan, tdist[i] if tdist is not None else np.nan)
            mix = mdirs.get(month[i]) if both_ways else None
            got = 0
            for _ in range(draws * 3):
                if got >= draws:
                    break
                k = int(pool[rng.integers(len(pool))])
                dd = int(mix[rng.integers(len(mix))]) if mix is not None and len(mix) else int(d)
                tr = simulate_entry(mk, strat, s.index, sig_close, k, dd, empty, atr_arr, exit_by_dir[dd],
                                    max_delay, levels=lv)
                if tr is None or tr.get("open_at_end"):
                    continue
                tr["of"] = tid
                rows.append(tr)
                got += 1
    return pd.DataFrame(rows)


def lookahead_check(strat: Strategy, run_: Run, cuts: int = 12, seed: int = 3) -> List[str]:
    """Recompute signals on data cut off at random points. A signal at the cut
    must be identical with or without the future attached - if not, the
    strategy is reading data it couldn't have had."""
    rng = np.random.default_rng(seed)
    problems = []
    variants = strat.walk_forward.variants if strat.walk_forward else [{}]
    for inst, (s, frame_full) in list(run_.frames.items())[:3]:
        if len(s) < 600:
            continue
        for var in variants[:2]:
            p = dict(run_.params, **var)
            full = compute_signals(strat, s, p) if var else frame_full
            col = "pos" if strat.mode == "position" else "entry"
            pts = rng.integers(300, len(s) - 2, size=cuts)
            for cut in pts:
                part = compute_signals(strat, s.iloc[: cut + 1], p)
                a = part[col].iloc[-5:].to_numpy()
                b = full[col].iloc[cut - 4: cut + 1].to_numpy()
                if not np.allclose(a.astype(float), b.astype(float), equal_nan=True):
                    problems.append(f"{inst}: signal at {s.index[cut]} changes when later bars are added")
                    break
                for extra in ("exit", "exit_long", "exit_short", "stop_price", "target_price", "stop_dist",
                              "target_dist"):
                    if extra in full and extra in part:
                        x = part[extra].iloc[-5:].to_numpy(dtype=float)
                        y = full[extra].iloc[cut - 4: cut + 1].to_numpy(dtype=float)
                        if not np.allclose(x, y, equal_nan=True):
                            problems.append(f"{inst}: '{extra}' at {s.index[cut]} uses future bars")
                            break
    return sorted(set(problems))


def with_cost_mult(trades: pd.DataFrame, m: float) -> np.ndarray:
    """Net R if trading costs (spread, commission, slippage) were m times higher."""
    return (trades["r_mid"] - m * (trades["spread_r"] + trades["comm_r"] + trades["slip_r"])
            + trades["swap_r"]).to_numpy()
