"""
selftest.py - proves the tool works before you trust it with a decision.

  python lab.py selftest            full: unit tests + 3 x 100 synthetic markets (~15-25 min)
  python lab.py selftest --quick    unit tests + 3 x 30 markets (~5 min)

PART 1 - unit tests: every fill rule on hand-built bars where the right answer
is known exactly (stops, targets, gaps, same-bar ambiguity, next-open fills,
shut markets, time exits, session flats, swap nights incl. the triple day,
shorts, cost scaling, clock conversion, walk-forward using only the past,
lookahead detection, prop rules).

PART 2 - calibration: the full pipeline (engine, random-entry null, bootstrap,
deflated Sharpe, robustness, verdict) on synthetic markets where the truth is
known:
  noise   random walk, random entries      -> must NOT be called an edge (<=5%)
  drift   rising market, random entries    -> must NOT be called an edge (<=5%): that's BETA
  edge    a real, planted, modest edge     -> must NOT be called NO EDGE (<=5%): the over-pessimism test
                                              and how often it's caught (power) is reported
  peek    a strategy that reads the future -> must be BROKEN every time
"""
from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Callable, Dict, List, Tuple

import numpy as np
import pandas as pd

import catalog
import data as dmod
import engine
import prop
from engine import Exits, Strategy, WalkForward

RESULTS: List[Tuple[str, bool, str]] = []


def unit(fn: Callable) -> Callable:
    def wrapped():
        try:
            fn()
            RESULTS.append((fn.__name__, True, ""))
        except Exception as exc:     # noqa: BLE001
            RESULTS.append((fn.__name__, False, f"{type(exc).__name__}: {exc}"))
    wrapped.__name__ = fn.__name__
    UNITS.append(wrapped)
    return wrapped


UNITS: List[Callable] = []

# ------------------------------------------------------------------ helpers


def bars(rows: List[Tuple[str, float, float, float, float]], spread_bp: float = 0.0) -> pd.DataFrame:
    idx = pd.DatetimeIndex([pd.Timestamp(r[0]) for r in rows])
    df = pd.DataFrame({"open": [r[1] for r in rows], "high": [r[2] for r in rows], "low": [r[3] for r in rows],
                       "close": [r[4] for r in rows], "volume": 100.0, "spread_bp": spread_bp}, index=idx)
    return df


def one_trade(df: pd.DataFrame, entries: Dict[int, int], exits: Exits, tf: str = "M5", session=None, tz="UTC",
              price_type="bid", swap=(0.0, 0.0), triple=2, commission=0.0, direction="long") -> pd.DataFrame:
    sig = df.copy()
    ent = pd.Series(0, index=df.index, dtype=np.int8)
    for i, d in entries.items():
        ent.iloc[i] = d
    st = Strategy(name="_u", fn=lambda s, p: ent.reindex(s.index).fillna(0).astype(np.int8), timeframe=tf, params={},
                  exits=exits, session=session, tz=tz, weekdays_only=False, direction=direction)
    costs = engine.Costs(spread_bp=0.0, commission_bp=commission, swap_long_pct=swap[0], swap_short_pct=swap[1],
                         triple_day=triple, stop_slip_bp=0.0, tp_gap_fill="open", rollover_ny="17:00")
    mk = engine.Market("x", "X", "test", sig, df, dict(price_type=price_type, exec_tf=tf), costs, st)
    s = engine.signal_bars(st, sig)
    fr = engine.compute_signals(st, s, {})
    tr, _ = engine.run_events(mk, st, s, fr)
    return tr


def close(a, b, tol=1e-9):
    # prices are stored as float32 (7 significant digits) to keep 1-minute history in memory,
    # so allow a relative 1e-6 on top of the absolute tolerance
    assert abs(a - b) <= max(tol, 1e-6 * max(abs(a), abs(b))), f"{a} != {b}"


# ---------------------------------------------------------------- PART 1

T = "2024-03-05 "   # a Tuesday


@unit
def fills_at_next_open_not_signal_close():
    df = bars([(T + "14:00", 100, 100.2, 99.9, 100.1), (T + "14:05", 100.3, 100.4, 100.2, 100.3),
               (T + "14:10", 100.3, 100.4, 100.2, 100.3), (T + "14:15", 100.3, 100.4, 100.2, 100.3)])
    tr = one_trade(df, {0: 1}, Exits(max_bars=2))
    close(tr.entry_px.iat[0], 100.3)
    assert pd.Timestamp(tr.entry_time.iat[0]) == pd.Timestamp(T + "14:05")


@unit
def stop_is_minus_one_r_bid_ask_aware():
    # bid bars with a 10bp spread: buy at ask, stop triggers on the bid
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.05, 100, 100.02),
               (T + "14:10", 100.0, 100.0, 98.0, 98.5)], spread_bp=10)
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, target_pct=0.02))
    assert tr.reason.iat[0] == "stop"
    entry = 100 * 1.001
    close(tr.entry_px.iat[0], entry, 1e-9)
    close(tr.exit_px.iat[0], entry * 0.99, 1e-9)
    close(tr.r_net.iat[0], -1.0, 1e-9)
    assert tr.spread_r.iat[0] > 0


@unit
def target_pays_the_reward_multiple():
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.1, 99.9, 100),
               (T + "14:10", 100.5, 102.5, 100.4, 102)])
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, target_pct=0.02))
    assert tr.reason.iat[0] == "target"
    close(tr.r_net.iat[0], 2.0, 1e-9)


@unit
def gap_through_stop_fills_at_the_open():
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.1, 99.9, 100),
               ("2024-03-06 14:00", 97.0, 97.5, 96.5, 97.2)])
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, target_pct=0.02))
    assert tr.reason.iat[0] == "gap_stop", tr.reason.iat[0]
    close(tr.r_net.iat[0], -3.0, 1e-9)


@unit
def same_bar_stop_and_target_records_both_outcomes():
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.1, 99.9, 100),
               (T + "14:10", 100.2, 103, 98.5, 101)])   # green bar: low first -> stop
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, target_pct=0.02))
    assert bool(tr.ambiguous.iat[0])
    close(tr.r_pess.iat[0], -1.0, 1e-9)
    close(tr.r_opt.iat[0], 2.0, 1e-9)
    close(tr.r_net.iat[0], -1.0, 1e-9)


@unit
def shut_market_skips_the_signal():
    df = bars([(T + "14:00", 100, 100, 100, 100), ("2024-03-06 09:00", 100, 100.5, 99.5, 100),
               ("2024-03-06 09:05", 100, 100.5, 99.5, 100)])
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, max_bars=2))
    assert len(tr) == 0


@unit
def time_exit_after_max_bars_at_the_close():
    rows = [(f"{T}14:{m:02d}", 100, 100.1, 99.9, 100 + k * 0.01) for k, m in enumerate(range(0, 60, 5))]
    df = bars(rows)
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.05, target_pct=0.10, max_bars=4))
    assert tr.reason.iat[0] == "time"
    close(tr.exit_px.iat[0], df.close.iat[3])
    assert pd.Timestamp(tr.exit_time.iat[0]) == pd.Timestamp(T + "14:20")


@unit
def flat_at_session_end():
    rows = [(f"{T}19:{m:02d}", 100, 100.1, 99.9, 100) for m in range(30, 60, 5)] + \
           [(f"{T}20:{m:02d}", 100, 100.1, 99.9, 101) for m in range(0, 30, 5)]
    df = bars(rows)
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.05, flat_at="20:00"))
    assert pd.Timestamp(tr.exit_time.iat[0]) == pd.Timestamp(T + "20:00"), tr.exit_time.iat[0]
    assert tr.reason.iat[0] == "flat", tr.reason.iat[0]


@unit
def swap_nights_with_wednesday_triple():
    # Tue 14:00 UTC -> Thu 15:00 UTC crosses Tue (1) and Wed (3) rollovers = 4 nights
    rows = [("2024-03-05 14:00", 100, 100, 100, 100), ("2024-03-05 14:05", 100, 100.1, 99.9, 100),
            ("2024-03-07 15:00", 100, 100.1, 99.9, 100), ("2024-03-07 15:05", 100, 100.1, 99.9, 100)]
    df = bars(rows)
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, max_bars=3), swap=(-0.01, 0.0), triple=2)
    close(tr.nights.iat[0], 4.0)
    close(tr.swap_r.iat[0], 4 * -0.01 / 100 / 0.01, 1e-9)


@unit
def weekend_counts_once_when_triple_is_wednesday():
    rows = [("2024-03-08 14:00", 100, 100, 100, 100), ("2024-03-08 14:05", 100, 100.1, 99.9, 100),
            ("2024-03-11 15:00", 100, 100.1, 99.9, 100), ("2024-03-11 15:05", 100, 100.1, 99.9, 100)]
    tr = one_trade(bars(rows), {0: 1}, Exits(stop_pct=0.01, max_bars=3), swap=(-0.01, 0.0), triple=2)
    close(tr.nights.iat[0], 1.0)


@unit
def short_stop_uses_the_ask():
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.05, 99.95, 100),
               (T + "14:10", 100, 100.95, 99.9, 100.5)], spread_bp=10)
    tr = one_trade(df, {0: -1}, Exits(stop_pct=0.01, target_pct=0.02), direction="short")
    # sold at the bid 100; stop 101 is hit when the ASK (bid*1.001) reaches it: 100.95*1.001 = 101.05
    assert tr.reason.iat[0] == "stop", tr.reason.iat[0]
    close(tr.r_net.iat[0], -1.0, 1e-9)


@unit
def cost_multiplier_scales_only_trading_costs():
    df = bars([(T + "14:00", 100, 100, 100, 100), (T + "14:05", 100, 100.05, 100, 100.02),
               (T + "14:10", 100.0, 100.0, 98.0, 98.5)], spread_bp=10)
    tr = one_trade(df, {0: 1}, Exits(stop_pct=0.01, target_pct=0.02), commission=1.0)
    r0 = engine.with_cost_mult(tr, 0.0)[0]
    r1 = engine.with_cost_mult(tr, 1.0)[0]
    r2 = engine.with_cost_mult(tr, 2.0)[0]
    close(r1, tr.r_net.iat[0], 1e-9)
    close(r2 - r1, r1 - r0, 1e-9)
    assert r0 > r1


@unit
def mt5_clock_follows_new_york_dst():
    s_winter = pd.Timestamp("2024-01-15 16:30")      # server (NY+7) -> 14:30 UTC
    s_summer = pd.Timestamp("2024-07-15 16:30")      # -> 13:30 UTC
    ep = np.array([(s_winter - pd.Timestamp(0)) // pd.Timedelta(seconds=1),
                   (s_summer - pd.Timestamp(0)) // pd.Timedelta(seconds=1)])
    u = dmod.server_to_utc(ep, "NY+7")
    assert u[0] == pd.Timestamp("2024-01-15 14:30") and u[1] == pd.Timestamp("2024-07-15 13:30"), list(u)


@unit
def lookahead_is_caught():
    df = synth(np.random.default_rng(1), years=0.3, drift=0.0)
    st = Strategy(name="_peek", fn=lambda s, p: s["close"].shift(-1) > s["close"], timeframe="M15", params={},
                  exits=Exits(stop_pct=0.005, target_pct=0.01, max_bars=20), weekdays_only=True)
    r = engine.run(st, instruments=["synth"], source="test", venue="raw",
                   data_override={"synth": (df, df, dict(price_type="bid", exec_tf="M15"))})
    assert engine.lookahead_check(st, r), "future-reading strategy was not caught"


@unit
def honest_strategy_passes_lookahead():
    df = synth(np.random.default_rng(2), years=0.3, drift=0.0)
    st = Strategy(name="_ok", fn=lambda s, p: s["close"] > s["close"].rolling(20).mean(), timeframe="M15", params={},
                  exits=Exits(stop_pct=0.005, target_pct=0.01, max_bars=20))
    r = engine.run(st, instruments=["synth"], source="test", venue="raw",
                   data_override={"synth": (df, df, dict(price_type="bid", exec_tf="M15"))})
    assert not engine.lookahead_check(st, r)


@unit
def walk_forward_only_uses_the_past():
    # instrument A is great before 2025 and awful after; B the reverse. A forward-looking
    # selector would pick B for 2025; an honest one picks A (the past winner) for H1 2025.
    rows = []
    for inst, good_first in (("A", True), ("B", False)):
        for d in pd.date_range("2023-01-02", "2025-06-30", freq="B"):
            first = d < pd.Timestamp("2025-01-01")
            r = 1.0 if first == good_first else -1.0
            rows.append(dict(inst=inst, variant=0, entry_time=d, exit_time=d + pd.Timedelta(hours=1), r_net=r))
    tr = pd.DataFrame(rows)

    class M:
        def __init__(self):
            self.t = np.array([np.datetime64("2023-01-02"), np.datetime64("2025-06-30")])
            self.sess = np.ones(2, bool)
    picked, log = engine.walk_forward_select(tr, {"A": M(), "B": M()},
                                             WalkForward(train_months=12, min_train_months=12, trade_months=6,
                                                         top=1, metric="mean_r", min_trades=10))
    h1 = picked[pd.DatetimeIndex(picked.entry_time) >= pd.Timestamp("2025-01-01")]
    assert set(h1.inst) == {"A"}, log


@unit
def prop_zero_edge_twin_matches_zero_edge():
    rng = np.random.default_rng(3)
    n = 800
    real = rng.normal(0, 1, n)
    real -= real.mean()                     # exactly zero edge
    eq = np.cumsum(real)
    daily = pd.DataFrame({"start_bal": np.r_[0, eq[:-1]], "end_bal": eq, "end_eq": eq,
                          "min_eq": np.minimum(np.r_[0, eq[:-1]], eq) - np.abs(rng.normal(0, .3, n)),
                          "trades": 1}, index=pd.bdate_range("2020-01-01", periods=n))
    rules = catalog.PROP_RULES["ftmo_2step"]
    a = prop.simulate(daily, 0.005, rules, paths=800)
    z = prop.simulate(daily, 0.005, rules, paths=800, zero_edge=True)
    assert abs(a["pass_all"] - z["pass_all"]) < 0.08, (a["pass_all"], z["pass_all"])
    good = daily.copy()
    shift = np.cumsum(np.full(n, 0.6))
    for c in ("end_bal", "end_eq", "min_eq"):
        good[c] = daily[c] + shift
    good["start_bal"] = np.r_[0, good["end_bal"].to_numpy()[:-1]]
    g = prop.simulate(good, 0.005, rules, paths=800)
    assert g["pass_all"] > a["pass_all"] + 0.2, (g["pass_all"], a["pass_all"])


@unit
def daily_loss_rule_uses_intraday_low():
    n = 300
    daily = pd.DataFrame({"start_bal": 0.0, "end_bal": 0.0, "end_eq": 0.0, "min_eq": -12.0, "trades": 1},
                         index=pd.bdate_range("2020-01-01", periods=n))
    r = prop.simulate(daily, 0.005, catalog.PROP_RULES["ftmo_2step"], paths=50, shrink=False)
    assert r["fail_phase1"] == 1.0          # -12R x 0.5% = -6% intraday breaches the 5% daily limit


@unit
def mt5_connector_fetches_converts_clock_and_spread():
    import types
    now = pd.Timestamp(dmod.utcnow()).floor("5min")
    utc = pd.date_range(now - pd.Timedelta(days=400), now, freq="5min")
    utc = utc[utc.dayofweek < 5]
    ny = utc.tz_localize("UTC").tz_convert("America/New_York").tz_localize(None)
    server = ny + pd.Timedelta(hours=7)
    ep = ((server - pd.Timestamp(0)) // pd.Timedelta(seconds=1)).to_numpy()
    rates = np.zeros(len(ep), dtype=[("time", "<i8"), ("open", "<f8"), ("high", "<f8"), ("low", "<f8"),
                                     ("close", "<f8"), ("tick_volume", "<u8"), ("spread", "<i4"),
                                     ("real_volume", "<u8")])
    rates["time"], rates["open"], rates["high"], rates["low"], rates["close"] = ep, 100, 101, 99, 100.5
    rates["tick_volume"], rates["spread"] = 10, 25
    NS = types.SimpleNamespace
    fake = types.ModuleType("MetaTrader5")
    for k, v in dict(TIMEFRAME_M1=1, TIMEFRAME_M5=5, TIMEFRAME_M15=15, TIMEFRAME_M30=30, TIMEFRAME_H1=60,
                     TIMEFRAME_H4=240, TIMEFRAME_D1=1440).items():
        setattr(fake, k, v)
    fake.initialize = lambda **kw: True
    fake.shutdown = lambda: None
    fake.last_error = lambda: (0, "ok")
    fake.terminal_info = lambda: NS(maxbars=2**31 - 1, connected=True)
    fake.account_info = lambda: NS(server="FTMO-Demo")
    fake.symbols_get = lambda: [NS(name="XAUUSD")]
    fake.symbol_select = lambda s, on: True
    fake.symbol_info = lambda s: NS(point=0.01, digits=2, trade_contract_size=100, currency_profit="USD",
                                    swap_mode=1, swap_long=-50.0, swap_short=10.0, swap_rollover3days=3,
                                    spread=25, volume_min=0.01, volume_step=0.01, bid=100.0)
    fake.symbol_info_tick = lambda s: NS(bid=100.0, ask=100.25, time=0)

    def crr(sym, tf, lo, hi):
        a = (pd.Timestamp(lo) - pd.Timestamp(0)) // pd.Timedelta(seconds=1) + 3 * 3600
        b = (pd.Timestamp(hi) - pd.Timestamp(0)) // pd.Timedelta(seconds=1) + 3 * 3600
        return rates[(rates["time"] >= a) & (rates["time"] < b)]
    fake.copy_rates_range = crr
    saved = sys.modules.get("MetaTrader5")
    sys.modules["MetaTrader5"] = fake
    try:
        src = dmod.MT5Source()
        df = src.fetch("XAUUSD", "M5")
        sp = src.specs("XAUUSD")
    finally:
        if saved is not None:
            sys.modules["MetaTrader5"] = saved
        else:
            del sys.modules["MetaTrader5"]
    assert len(df) >= len(utc) - 3, (len(df), len(utc))
    assert (df.index == utc[: len(df)]).all(), "UTC conversion wrong"
    close(float(df["spread_bp"].iloc[0]), 25 * 0.01 / 100.5 * 1e4, 1e-6)
    close(sp["swap_long_pct"], -50 * 0.01 / 100.0 * 100, 1e-9)    # points -> % of notional per night
    assert sp["triple_day"] == 2                                     # MT5 3 = Wednesday -> ours 2


@unit
def alpaca_connector_pages_and_falls_back_to_iex():
    import os
    calls = []

    class Resp:
        def __init__(self, code, js=None, text=""):
            self.status_code, self._js, self.text = code, js, text

        def json(self):
            return self._js

    def get(url, params=None, timeout=None):
        calls.append(dict(params))
        if params.get("feed") == "sip":
            return Resp(403, text='{"message":"subscription does not permit querying recent SIP data"}')
        tok = params.get("page_token")
        if not tok:
            return Resp(200, {"bars": {"SPY": [dict(t="2024-01-02T14:30:00Z", o=1, h=2, l=0.5, c=1.5, v=10)]},
                              "next_page_token": "p2"})
        return Resp(200, {"bars": {"SPY": [dict(t="2024-01-02T14:31:00Z", o=1.5, h=2, l=1, c=1.8, v=12)]},
                          "next_page_token": None})
    old = {k: os.environ.get(k) for k in ("ALPACA_API_KEY", "ALPACA_SECRET_KEY")}
    os.environ["ALPACA_API_KEY"], os.environ["ALPACA_SECRET_KEY"] = "k", "s"
    try:
        src = dmod.AlpacaSource()
        src.s.get = get
        start = dmod.utcnow() - pd.Timedelta(days=30)
        df, extra = src.fetch("SPY", "M1", start.to_pydatetime() if hasattr(start, "to_pydatetime") else start)
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
    assert extra["feed"] == "iex"
    assert len(df) == 2 and df.index[0] == pd.Timestamp("2024-01-02 14:30"), df
    assert any(c.get("page_token") == "p2" for c in calls)


@unit
def yahoo_connector_converts_timezones():
    import types
    ny = pd.date_range("2024-07-01 09:30", periods=3, freq="h", tz="America/New_York")
    daily = pd.date_range("2024-07-01", periods=3, freq="D", tz="America/New_York")

    class Tk:
        def __init__(self, sym):
            pass

        def history(self, period=None, interval="1d", start=None, end=None, **kw):
            idx = daily if interval == "1d" else ny
            return pd.DataFrame({"Open": 1.0, "High": 2.0, "Low": 0.5, "Close": 1.5, "Volume": 10}, index=idx)
    fake = types.ModuleType("yfinance")
    fake.Ticker = Tk
    saved = sys.modules.get("yfinance")
    sys.modules["yfinance"] = fake
    try:
        src = dmod.YahooSource()
        h1 = src.fetch("SPY", "H1")
        d1 = src.fetch("SPY", "D1")
    finally:
        if saved is not None:
            sys.modules["yfinance"] = saved
        else:
            del sys.modules["yfinance"]
    assert h1.index[0] == pd.Timestamp("2024-07-01 13:30"), h1.index[0]
    assert d1.index[0] == pd.Timestamp("2024-07-01"), d1.index[0]


@unit
def mt5_swap_points_use_the_trade_price():
    # the 5 Oct bug: MT5 gave no live price, so points were divided by 1.0 (Brent +6%/night).
    c = engine.Costs(spread_bp=0, commission_bp=0, swap_long_pct=-0.007, swap_short_pct=-0.007, triple_day=4,
                     stop_slip_bp=0, tp_gap_fill="open", rollover_ny="17:00",
                     spec=dict(swap_mode=1, swap_long_raw=60.98, swap_short_raw=-275.78, point=0.001,
                               contract_size=100))
    close(c.swap_pct(106.0, 1), 60.98 * 0.001 / 106.0 * 100, 1e-12)     # +0.0575%/night, as seen live
    close(c.swap_pct(106.0, -1), -275.78 * 0.001 / 106.0 * 100, 1e-12)
    close(c.swap_pct(0.05, 1), -0.007, 1e-12)                            # absurd -> venue default
    bt = engine.Costs(0, 0, -0.01, -0.01, 4, 0, "open", "17:00",
                      spec=dict(swap_mode=5, swap_long_raw=-30.0, swap_short_raw=-30.0, point=0.01, contract_size=1))
    close(bt.swap_pct(60000.0, 1), -30 / 360, 1e-12)                     # interest mode: 30%/yr


@unit
def bad_print_repaired_real_crash_kept():
    idx = pd.date_range("2024-01-01", periods=300, freq="h")
    c = 30 + np.cumsum(np.random.default_rng(1).normal(0, 0.02, 300))
    df = pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c + .02, "low": c - .02, "close": c,
                       "volume": 1.0, "spread_bp": 5.0}, index=idx)
    df["high"] = np.maximum(df["high"], df["open"])
    df["low"] = np.minimum(df["low"], df["open"])
    bad = df.copy()
    bad.iloc[150, bad.columns.get_loc("close")] *= 1.05            # +5% print, next bar opens back
    bad.iloc[150, bad.columns.get_loc("high")] = bad["close"].iat[150]
    fixed, n_ohlc, n_bad = dmod.repair(bad, "H1")
    assert n_bad == 1 and abs(fixed["close"].iat[150] - df["open"].iat[151]) < 1e-9, (n_bad,)
    crash = df.copy()
    crash.loc[crash.index[150:], ["open", "high", "low", "close"]] *= 0.90  # -10% that STAYS
    crash.iloc[150, crash.columns.get_loc("open")] = df["close"].iat[149]
    crash.iloc[150, crash.columns.get_loc("high")] = df["close"].iat[149]
    _, _, n_bad2 = dmod.repair(crash, "H1")
    assert n_bad2 == 0, "a real move was 'repaired'"


@unit
def yahoo_ohlc_quirk_repaired_not_rejected():
    idx = pd.bdate_range("2004-01-01", periods=400)
    c = 400 + np.cumsum(np.random.default_rng(2).normal(0, 2, 400))
    df = pd.DataFrame({"open": c, "high": c, "low": c, "close": c + 1.0, "volume": 1.0, "spread_bp": np.nan},
                      index=idx)                                     # O=H=L, close outside: Yahoo 2003-11
    fixed, n_ohlc, _ = dmod.repair(df, "D1")
    assert n_ohlc == 400 and (fixed["high"] >= fixed["close"]).all()
    q = dmod.quality(df, "D1", {})
    assert q["level"] != "BAD" or n_ohlc / len(df) > 0.25


@unit
def short_5m_cache_extended_from_1m_history():
    import shutil, tempfile
    old = dmod.DATA
    tmp = Path(tempfile.mkdtemp())
    dmod.DATA = tmp
    try:
        idx1 = pd.date_range("2020-01-06", "2020-03-31", freq="1min")
        idx1 = idx1[idx1.dayofweek < 5]
        px = 100 + np.cumsum(np.random.default_rng(3).normal(0, .01, len(idx1)))
        m1 = pd.DataFrame({"open": px, "high": px + .01, "low": px - .01, "close": px, "volume": 1.0,
                           "spread_bp": 1.0}, index=idx1)
        dmod.save("mt5", "TST", "M1", m1, price_type="bid")
        dmod.save("mt5", "TST", "M5", dmod.resample(m1[m1.index >= "2020-03-20"], "M5"), price_type="bid")
        sig, exe, meta = dmod.load("x", "mt5", "M5", symbol="TST")
        assert sig.index[0] < pd.Timestamp("2020-01-07"), sig.index[0]     # not cut to 20 Mar
        assert "vault_start" in meta
    finally:
        dmod.DATA = old
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------- the strategy search

def _search_world(days: int = 160, seed: int = 21):
    """A 23h index CFD on 5-minute bid bars (daily 1h break, weekends shut), US-session volatility."""
    rng = np.random.default_rng(seed)
    idx = pd.date_range("2022-01-03", periods=days * 288, freq="5min")
    idx = idx[(idx.dayofweek < 5) & (idx.hour != 21)]
    ny = idx.tz_localize("UTC").tz_convert("America/New_York")
    vol = np.where((ny.hour * 60 + ny.minute >= 570) & (ny.hour < 16), 6e-4, 2e-4)
    r = rng.standard_t(4, len(idx)) * vol / np.sqrt(2)
    c = 4000 * np.exp(np.cumsum(r))
    o = np.r_[c[0], c[:-1]]
    w = np.abs(rng.normal(0, 1, len(idx))) * vol * c
    df = pd.DataFrame({"open": o, "high": np.maximum(o, c) + w, "low": np.minimum(o, c) - w, "close": c,
                       "volume": 1.0, "spread_bp": 1.0}, index=idx)
    return df


def _search_ready():
    import search
    if search.njit is None:
        raise RuntimeError("numba not installed (pip install numba) - the search can't run")
    return search


@unit
def search_kernel_matches_engine():
    """The fast discovery kernel and the full engine give the same trades and R on the same bars."""
    search = _search_ready()
    m5 = _search_world()
    start, end = pd.Timestamp("2022-03-01"), m5.index[-1] + pd.Timedelta(minutes=5)
    for fam, p in (("orb", dict(or_min=30, stop="range", tgt=2)), ("noise", dict(lookback=14, check=30, mult=1.0)),
                   ("sessdrift", dict(window="ny", lookback=120)), ("vwapmr", dict(k=2.0, stop=1.0))):
        xs = search.build_ctx("US500.cash", "index", "M5", m5, {}, {}, "ftmo", min_bars=100)
        (e_i, x_i, dirs, r, spr, why), _ = search.run_family(xs, xs, fam, p)
        keep = xs.t[e_i] >= np.datetime64(start)
        st = search.make_strategy(fam, "M5", p, f"_t_{fam}", ["mt5:US500.cash"])
        sig = m5.copy()
        exe = m5[m5.index >= start].assign(dur_min=5.0)
        token = f"{st.name}|mt5:US500.cash"
        search._SIDE[token] = dict(uni={}, specs={}, block_times=sig.index.values[
            search.gap_block(sig.index, 5)])
        sig.attrs = dict(sym="US500.cash", cls="index", venue="ftmo", trade_from=str(start), token=token)
        if st.flat_map is not None:
            st.flat_map["mt5:US500.cash"] = ("16:00", "America/New_York")
        meta = dict(symbol="US500.cash", price_type="bid", exec_tf="M5", vault_start=None)
        run_ = engine.run(st, instruments=["mt5:US500.cash"], source="mt5", venue="ftmo", params=p,
                          data_override={"mt5:US500.cash": (sig, exe, meta)})
        assert len(run_.trades) == int(keep.sum()) and len(run_.trades) > 10, (fam, len(run_.trades), keep.sum())
        a = pd.DatetimeIndex(xs.t[e_i][keep])
        b = pd.DatetimeIndex(run_.trades["entry_time"])
        assert (a == b).all(), fam
        assert np.abs(r[keep] - run_.trades["r_net"].to_numpy()).max() < 1e-4, fam      # float32 engine arrays


@unit
def search_families_read_no_future_bars():
    search = _search_ready()
    m5 = _search_world(days=200, seed=5)
    start = pd.Timestamp("2022-04-01")
    for fam, F in search.FAMILIES.items():
        if F["kind"] != "intraday":
            continue
        for tf in F["tfs"]:
            p = search.configs(fam)[0]
            st = search.make_strategy(fam, tf, p, f"_l_{fam}_{tf}", ["mt5:US500.cash"])
            sig = m5 if tf == "M5" else dmod.resample(m5, tf)
            sig = sig.copy()
            token = f"{st.name}|mt5:US500.cash"
            search._SIDE[token] = dict(uni={}, specs={}, block_times=sig.index.values[
                search.gap_block(sig.index, dmod.tf_minutes(tf))])
            sig.attrs = dict(sym="US500.cash", cls="index" if fam != "asian" else "fx", venue="ftmo",
                             trade_from=str(start), token=token)
            if st.flat_map is not None:
                st.flat_map["mt5:US500.cash"] = ("16:00", "America/New_York")
            meta = dict(symbol="US500.cash", price_type="bid", exec_tf="M5", vault_start=None)
            run_ = engine.run(st, instruments=["mt5:US500.cash"], source="mt5", venue="ftmo", params=p,
                              data_override={"mt5:US500.cash": (sig, m5[m5.index >= start].assign(dur_min=5.0), meta)})
            look = engine.lookahead_check(st, run_, cuts=15)
            assert not look, f"{fam} {tf}: {look[0]}"


@unit
def prop_lifecycle_cash_is_exact():
    """+1R every day at 0.5% risk on FTMO 2-Step: 10% in 20 days, 5% in 10 more, funded from day 30, paid
    80% of 5% every 10 trading days, fee refunded with the first payout; always-losing = fees only."""
    idx = pd.bdate_range("2023-01-02", periods=300)
    cum = np.arange(1, 301, dtype=float)
    up = pd.DataFrame({"start_bal": cum - 1, "min_eq": cum - 1, "end_eq": cum, "end_bal": cum, "trades": 1},
                      index=idx)
    P = dict(catalog.PROGRAMS["FTMO 2-Step 100K"])
    a = prop.lifecycle(up, 0.005, P, months=12, paths=3, shrink=False)
    # days 0-19 phase 1, 20-29 phase 2, funded from day 30; payouts at funded days 10, 20, ... -> 22 in 252 days
    n_pay = (252 - 30) // 10
    want = n_pay * 0.05 * 0.80 * 100_000 + P["fee"] - P["fee"]
    assert abs(a["net_mean"] - want) < 1e-6, (a["net_mean"], want)
    dn = up.assign(min_eq=-(cum), end_eq=-cum, end_bal=-cum, start_bal=-(cum - 1))
    b = prop.lifecycle(dn, 0.03, P, months=12, paths=3, shrink=False)
    assert b["payouts"] == 0 and abs(b["net_mean"] + b["fees"]) < 1e-6, b


@unit
def search_bh_level_and_density_cut():
    import search
    lvl, k = search.bh_level([0.001, 0.2, 0.5, 0.04], 0.10)
    assert k == 2 and abs(lvl - 0.05) < 1e-12, (lvl, k)                 # 0.001<=0.025, 0.04<=0.05, 0.2>0.075
    lvl0, k0 = search.bh_level([0.3, 0.6], 0.10)
    assert k0 == 0 and abs(lvl0 - 0.05) < 1e-12
    sparse = pd.date_range("2018-01-01", "2020-12-31", freq="B")             # one padded bar a day
    dense = pd.date_range("2021-01-04", "2022-06-30", freq="5min")
    dense = dense[dense.dayofweek < 5]
    cut = search.dense_from(sparse.append(dense))
    assert cut == pd.Timestamp("2021-01-01"), cut


# ----------------------------------------------------------- synthetic world

def synth(rng: np.random.Generator, years: float = 3.0, drift: float = 0.0, hint_prob: float = 0.0,
          hint_bars: int = 40, hint_move: float = 0.0) -> pd.DataFrame:
    """24/5 market, 15-minute bid bars, volatility clustering, fat tails, weekend
    gaps, 1bp spread. Optional planted edge: a 'hint' column; after a hint the
    next hint_bars bars drift up by hint_move in total (an edge a strategy can
    really exploit, of a known size)."""
    idx = pd.date_range("2020-01-06", periods=int(years * 260 * 96), freq="15min")
    idx = idx[idx.dayofweek < 5][: int(years * 260 * 96)]
    n = len(idx)
    sig_bar = 0.16 / np.sqrt(260 * 96)
    z = rng.standard_t(4, n) / np.sqrt(2.0)
    v = np.empty(n)
    v[0] = 1.0
    shocks = rng.normal(0, 0.03, n)
    for t in range(1, n):
        v[t] = max(0.3, min(3.0, v[t - 1] * np.exp(shocks[t]) * 0.999 + 0.001))
    r = z * sig_bar * v + drift / (260 * 96)
    gap = np.r_[False, np.diff(idx.dayofweek) < 0]
    r[gap] += rng.normal(0, sig_bar * 12, gap.sum())
    hint = np.zeros(n, dtype=bool)
    if hint_prob > 0:
        hint = rng.random(n) < hint_prob
        add = np.zeros(n)
        for i in np.flatnonzero(hint):
            add[i + 1: i + 1 + hint_bars] += hint_move / hint_bars
        r = r + add
    c = 100 * np.exp(np.cumsum(r))
    o = np.r_[100.0, c[:-1]] * np.exp(np.where(gap, 0, 0))
    o[gap] = c[gap] / np.exp(r[gap] * 0.3)
    wig = np.abs(rng.normal(0, sig_bar * 0.6, n)) * v
    h = np.maximum(o, c) * np.exp(wig)
    l = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, sig_bar * 0.6, n)) * v)
    df = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": rng.lognormal(5, .5, n),
                       "spread_bp": 1.0, "hint": hint}, index=idx)
    return df


def _cal_strategies():
    ex = Exits(stop_pct=0.005, target_pct=0.010, max_bars=40)

    def rnd(s, p):
        u = (pd.util.hash_array(s.index.asi8.astype(np.int64) + p["seed"]) % 1_000_003) / 1_000_003
        return pd.Series(u < p["prob"], index=s.index)
    engine.REGISTRY["_cal_random"] = Strategy(name="_cal_random", fn=rnd, timeframe="M15",
                                              params=dict(prob=0.005, seed=0), exits=ex, venue="raw",
                                              instruments=["synth"], source="test")
    engine.REGISTRY["_cal_hint"] = Strategy(name="_cal_hint", fn=lambda s, p: s["hint"].astype(bool),
                                            timeframe="M15", params={}, exits=ex, venue="raw",
                                            instruments=["synth"], source="test")
    engine.REGISTRY["_cal_peek"] = Strategy(name="_cal_peek",
                                            fn=lambda s, p: (s["close"].shift(-4) > s["close"] * 1.002),
                                            timeframe="M15", params={}, exits=ex, venue="raw",
                                            instruments=["synth"], source="test")


def calibrate(n: int, seed0: int = 1000) -> pd.DataFrame:
    import lab
    _cal_strategies()
    scen = {
        "noise": dict(strategy="_cal_random", kw=dict(drift=0.0)),
        "drift": dict(strategy="_cal_random", kw=dict(drift=0.25)),
        "edge": dict(strategy="_cal_hint", kw=dict(drift=0.0, hint_prob=0.0035, hint_move=0.0022)),
        "small edge": dict(strategy="_cal_hint", kw=dict(drift=0.0, hint_prob=0.0035, hint_move=0.0011)),
        "peek": dict(strategy="_cal_peek", kw=dict(drift=0.0)),
    }
    rows = []
    for name, sc in scen.items():
        reps = n if name != "peek" else max(5, n // 6)
        t0 = time.time()
        for k in range(reps):
            rng = np.random.default_rng(seed0 + 7919 * k + hash(name) % 1000)
            df = synth(rng, years=3.0, **sc["kw"])
            meta = dict(price_type="bid", exec_tf="M15", symbol="SYN")
            st = engine.REGISTRY[sc["strategy"]]
            if name == "noise" or name == "drift":
                st.params["seed"] = int(rng.integers(1e9))
            res = lab.evaluate(sc["strategy"], ["synth"], "test", "raw", None, True, fast=True, record_it=False,
                               trials_override=(1, 0.0), quiet=True, data_override={"synth": (df, df, meta)},
                               write=False, do_prop=False)
            a = res["assessment"]
            tm = a.core.get("timing") or {}
            rows.append(dict(scenario=name, verdict=a.verdict, sharpe=a.core.get("sharpe"), dsr=a.core.get("dsr"),
                             timing_p=tm.get("p"), trades=a.core.get("trades"), mean_r=a.core.get("mean_r")))
            print(f"  {name:<10} {k + 1:>3}/{reps}  {a.verdict:<26} Sharpe {a.core.get('sharpe', 0):+.2f}  "
                  f"({time.time() - t0:.0f}s)", end="\r", flush=True)
        print()
    return pd.DataFrame(rows)


# --------------------------------------------------------------------- main

def main(quick: bool = False) -> int:
    print("PART 1 - unit tests")
    for u in UNITS:
        u()
    ok = True
    for name, passed, msg in RESULTS:
        print(f"  [{'PASS' if passed else 'FAIL'}] {name}" + (f"  - {msg}" if msg else ""))
        ok &= passed
    if not ok:
        print("\nUnit tests failed - do NOT trust results until fixed.")
        return 1
    n = 30 if quick else 100
    print(f"\nPART 2 - calibration on synthetic markets ({n} per scenario, 3 years of 15-minute bars each)")
    cal = calibrate(n)
    edge_v = cal["verdict"].str.startswith("EDGE")
    rows = []
    for sc, g in cal.groupby("scenario", sort=False):
        e = edge_v[g.index]
        rows.append(dict(scenario=sc, runs=len(g), called_edge=f"{e.mean():.0%}",
                         no_edge=f"{(g.verdict == 'NO EDGE').mean():.0%}",
                         beta=f"{g.verdict.str.startswith('BETA').mean():.0%}",
                         inconclusive=f"{g.verdict.str.startswith('INCONCLUSIVE').mean():.0%}",
                         broken=f"{(g.verdict == 'BROKEN').mean():.0%}",
                         timing_p_below_5pct=f"{(g.timing_p.dropna() < 0.05).mean():.0%}" if g.timing_p.notna().any() else "-",
                         avg_sharpe=round(float(g.sharpe.mean()), 2)))
    tab = pd.DataFrame(rows)
    print(tab.to_string(index=False))
    # the guarantees, with binomial slack for the number of runs
    def lim(p, k):
        return p + 2 * np.sqrt(p * (1 - p) / k)
    g = {s: cal[cal.scenario == s] for s in cal.scenario.unique()}
    checks = [
        ("random entries on noise called an edge", edge_v[g["noise"].index].mean(), lim(0.05, len(g["noise"]))),
        ("random entries on a rising market called an edge", edge_v[g["drift"].index].mean(), lim(0.05, len(g["drift"]))),
        ("a real planted edge called NO EDGE (over-pessimism)", (g["edge"].verdict == "NO EDGE").mean(),
         lim(0.05, len(g["edge"]))),
        ("a SMALL real edge called NO EDGE (over-pessimism)", (g["small edge"].verdict == "NO EDGE").mean(),
         lim(0.05, len(g["small edge"]))),
        ("a real edge called BETA (it beats random timing by construction)",
         g["edge"].verdict.str.contains("BETA").mean(), lim(0.05, len(g["edge"]))),
        ("a future-reading strategy NOT caught", 1 - (g["peek"].verdict == "BROKEN").mean(), 0.0),
    ]
    print()
    for name, val, mx in checks:
        good = val <= mx + 1e-12
        ok &= good
        print(f"  [{'PASS' if good else 'FAIL'}] {name}: {val:.0%} (limit {mx:.0%})")
    power = edge_v[g["edge"].index].mean()
    leans = g["edge"].verdict.isin(["INCONCLUSIVE - LEANS YES"]).mean()
    print(f"  [INFO] the planted edge (avg Sharpe {g['edge'].sharpe.mean():.2f}, ~{g['edge'].trades.mean():.0f} "
          f"trades) was confirmed as EDGE {power:.0%} of the time, 'leans yes' {leans:.0%}")
    ps = edge_v[g["small edge"].index].mean()
    ls = g["small edge"].verdict.isin(["INCONCLUSIVE - LEANS YES"]).mean()
    print(f"  [INFO] the small edge (avg Sharpe {g['small edge'].sharpe.mean():.2f}) was confirmed {ps:.0%}, "
          f"'leans yes' {ls:.0%} - never thrown away is the point; more data or a forward test settles it")
    print(f"  [INFO] random-entry timing test fired on noise {(g['noise'].timing_p < 0.05).mean():.0%} "
          f"of the time (should be about 5%)")
    out = dmod.ROOT / "results" / "selftest.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    cal.to_csv(out, index=False)
    print(f"\n{'ALL GOOD - the tool can be trusted within these error rates.' if ok else 'SELFTEST FAILED.'}"
          f"  (details: {out})")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(quick="--quick" in sys.argv))
