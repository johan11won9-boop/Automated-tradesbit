"""
report.py - the console summary and one self-contained HTML file per run.
"""
from __future__ import annotations

import html
import json
import math
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

ICON = {"PASS": "✓", "WARN": "!", "FAIL": "✗", "INFO": "i", "N/A": "–"}
VERDICT_TONE = {"EDGE - CONCLUSIVE": "good", "EDGE - STRONG": "good", "EDGE - PROBABLE": "warning",
                "INCONCLUSIVE - LEANS YES": "warning", "INCONCLUSIVE - LOOKS LIKE BETA": "neutral", "INCONCLUSIVE - LEANS NO": "neutral", "FRAGILE": "serious", "BETA - NO TIMING EDGE": "serious",
                "NO EDGE": "critical", "BROKEN": "critical", "INSUFFICIENT DATA": "neutral"}


def _f(x, nd=3, sign=False):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "–"
    return f"{x:+.{nd}f}" if sign else f"{x:.{nd}f}"


# ------------------------------------------------------------------ console

def console(title: str, a, prop: Optional[pd.DataFrame], path: Optional[Path]) -> str:
    c = a.core
    L = []
    w = 78
    L.append("=" * w)
    L.append(f" {title}")
    L.append("=" * w)
    L.append(f" VERDICT: {a.verdict}")
    for line in _wrap(a.headline, w - 2):
        L.append(f"  {line}")
    L.append("-" * w)
    for r in a.reasons:
        for k, line in enumerate(_wrap(r, w - 4)):
            L.append(("  • " if k == 0 else "    ") + line)
    if c.get("trade"):
        t = c["trade"]
        e = c["equity"]
        L.append("-" * w)
        L.append(f"  trades {t['trades']:,}  ({t['trades_per_month']:.1f}/month)   win {t['win_rate']:.1%}   "
                 f"PF {_f(t['profit_factor'], 2)}   mean {_f(t['mean_r'], 3, True)}{c['unit']}")
        L.append(f"  Sharpe {_f(c['sharpe'], 2)}   max DD {_f(e['max_dd'], 1)}{c['unit']}   "
                 f"worst month {_f(e['worst_month'], 1, True)}   {c['years']:.1f} years")
    if a.checks:
        L.append("-" * w)
        for ch in a.checks:
            L.append(f"  [{ICON.get(ch.status, '?')}] {ch.status:<4} {ch.name:<22} {ch.value}")
    if prop is not None and len(prop):
        L.append("-" * w)
        L.append("  FTMO 2-Step (pass both phases) vs a zero-edge twin:")
        for r in prop.itertuples(index=False):
            L.append(f"    risk {r.risk:>6}: pass {r[1]:.0%} (twin {r[2]:.0%}), funded year "
                     f"${r[6]:,.0f} (twin ${r[7]:,.0f}), breach {r[9]:.0%}")
    if path:
        L.append("-" * w)
        L.append(f"  full report: {path}")
    L.append("=" * w)
    return "\n".join(L)


def _wrap(s: str, w: int) -> List[str]:
    out, cur = [], ""
    for word in str(s).split():
        if len(cur) + len(word) + 1 > w:
            out.append(cur)
            cur = word
        else:
            cur = f"{cur} {word}".strip()
    if cur:
        out.append(cur)
    return out or [""]


# --------------------------------------------------------------------- SVG

W, H, PAD_L, PAD_R, PAD_T, PAD_B = 720, 260, 56, 16, 14, 28


def _ticks(lo, hi, n=5):
    if not np.isfinite(lo) or not np.isfinite(hi) or hi == lo:
        return [lo]
    raw = (hi - lo) / n
    mag = 10 ** math.floor(math.log10(raw))
    step = min((s * mag for s in (1, 2, 2.5, 5, 10) if s * mag >= raw), default=raw)
    start = math.ceil(lo / step) * step
    return [start + k * step for k in range(int((hi - start) / step) + 1)]


def _fmt_tick(v):
    a = abs(v)
    if a >= 1000:
        return f"{v:,.0f}"
    if a >= 10:
        return f"{v:.0f}"
    if a >= 1:
        return f"{v:.1f}"
    return f"{v:.2f}"


def line_chart(x: pd.DatetimeIndex, series: Dict[str, np.ndarray], label: str, marker: Optional[pd.Timestamp] = None,
               marker_text: str = "", W: int = W, H: int = H) -> str:
    if len(x) < 2:
        return ""
    keys = list(series)
    allv = np.concatenate([np.asarray(v, dtype=float) for v in series.values()])
    lo, hi = float(np.nanmin(allv)), float(np.nanmax(allv))
    lo, hi = min(lo, 0.0), max(hi, 0.0)
    span = (hi - lo) or 1.0
    lo -= span * 0.05
    hi += span * 0.05
    t0, t1 = x[0].value, x[-1].value

    def X(t):
        return PAD_L + (t - t0) / (t1 - t0) * (W - PAD_L - PAD_R)

    def Y(v):
        return PAD_T + (hi - v) / (hi - lo) * (H - PAD_T - PAD_B)
    parts = [f'<svg viewBox="0 0 {W} {H}" class="chart" role="img" aria-label="{html.escape(label)}">']
    for tv in _ticks(lo, hi):
        y = Y(tv)
        parts.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{y:.1f}" y2="{y:.1f}" class="grid"/>')
        parts.append(f'<text x="{PAD_L - 6}" y="{y + 4:.1f}" class="tick" text-anchor="end">{_fmt_tick(tv)}</text>')
    parts.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{Y(0):.1f}" y2="{Y(0):.1f}" class="axis"/>')
    years = pd.date_range(x[0].normalize(), x[-1], freq="YS")
    if len(years) > 12:
        years = years[:: math.ceil(len(years) / 10)]
    for yv in years:
        if yv < x[0]:
            continue
        parts.append(f'<text x="{X(yv.value):.1f}" y="{H - 8}" class="tick" text-anchor="middle">{yv.year}</text>')
    if marker is not None and x[0] <= marker <= x[-1]:
        mx = X(marker.value)
        parts.append(f'<line x1="{mx:.1f}" x2="{mx:.1f}" y1="{PAD_T}" y2="{H - PAD_B}" class="marker"/>')
        parts.append(f'<text x="{mx + 4:.1f}" y="{PAD_T + 10}" class="tick">{html.escape(marker_text)}</text>')
    step = max(1, len(x) // 600)
    xs = x[::step]
    data = {"x": [str(t.date()) for t in xs], "s": {}}
    for k, key in enumerate(keys):
        v = np.asarray(series[key], dtype=float)[::step]
        pts = " ".join(f"{X(t.value):.1f},{Y(val):.1f}" for t, val in zip(xs, v) if np.isfinite(val))
        parts.append(f'<polyline points="{pts}" class="line s{k + 1}"/>')
        data["s"][key] = [None if not np.isfinite(val) else round(float(val), 3) for val in v]
    parts.append(f'<rect x="{PAD_L}" y="{PAD_T}" width="{W - PAD_L - PAD_R}" height="{H - PAD_T - PAD_B}" '
                 f'class="hit" data-line=\'{html.escape(json.dumps(data))}\' data-x0="{PAD_L}" '
                 f'data-x1="{W - PAD_R}"/>')
    parts.append("</svg>")
    legend = "".join(f'<span class="key"><i class="sw s{k + 1}"></i>{html.escape(key)}</span>'
                     for k, key in enumerate(keys)) if len(keys) > 1 else ""
    return f'<figure><figcaption>{html.escape(label)}</figcaption>{"<div class=legend>" + legend + "</div>" if legend else ""}' \
           f'<div class="plot">{"".join(parts)}<div class="tip"></div></div></figure>'


def bar_chart(cats: Sequence[str], vals: Sequence[float], label: str, unit: str = "",
              ref: Optional[float] = None, ref_text: str = "", W: int = W, H: int = H) -> str:
    vals = np.asarray(vals, dtype=float)
    if len(vals) == 0:
        return ""
    lo, hi = min(0.0, float(np.nanmin(vals))), max(0.0, float(np.nanmax(vals)))
    if ref is not None:
        lo, hi = min(lo, ref), max(hi, ref)
    span = (hi - lo) or 1.0
    lo -= span * 0.08
    hi += span * 0.12
    n = len(vals)
    band = (W - PAD_L - PAD_R) / n
    bw = min(24.0, band * 0.6)

    def Y(v):
        return PAD_T + (hi - v) / (hi - lo) * (H - PAD_T - PAD_B)
    p = [f'<svg viewBox="0 0 {W} {H}" class="chart" role="img" aria-label="{html.escape(label)}">']
    for tv in _ticks(lo, hi):
        p.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{Y(tv):.1f}" y2="{Y(tv):.1f}" class="grid"/>')
        p.append(f'<text x="{PAD_L - 6}" y="{Y(tv) + 4:.1f}" class="tick" text-anchor="end">{_fmt_tick(tv)}</text>')
    y0 = Y(0)
    for k, (c, v) in enumerate(zip(cats, vals)):
        cx = PAD_L + band * (k + 0.5)
        if not np.isfinite(v):
            continue
        y1 = Y(v)
        top, h = (y1, y0 - y1) if v >= 0 else (y0, y1 - y0)
        cls = "pos" if v >= 0 else "neg"
        r = min(4, h / 2)
        if v >= 0:
            d = (f"M{cx - bw / 2:.1f},{y0:.1f} V{top + r:.1f} Q{cx - bw / 2:.1f},{top:.1f} {cx - bw / 2 + r:.1f},{top:.1f} "
                 f"H{cx + bw / 2 - r:.1f} Q{cx + bw / 2:.1f},{top:.1f} {cx + bw / 2:.1f},{top + r:.1f} V{y0:.1f} Z")
        else:
            bot = top + h
            d = (f"M{cx - bw / 2:.1f},{y0:.1f} V{bot - r:.1f} Q{cx - bw / 2:.1f},{bot:.1f} {cx - bw / 2 + r:.1f},{bot:.1f} "
                 f"H{cx + bw / 2 - r:.1f} Q{cx + bw / 2:.1f},{bot:.1f} {cx + bw / 2:.1f},{bot - r:.1f} V{y0:.1f} Z")
        p.append(f'<path d="{d}" class="bar {cls}"><title>{html.escape(str(c))}: {v:+.3f}{unit}</title></path>')
        if n <= 16:
            ty = top - 5 if v >= 0 else top + h + 13
            p.append(f'<text x="{cx:.1f}" y="{ty:.1f}" class="val" text-anchor="middle">{v:+.2f}</text>')
        if n <= 24:
            p.append(f'<text x="{cx:.1f}" y="{H - 8}" class="tick" text-anchor="middle">{html.escape(str(c))[:10]}</text>')
    p.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{y0:.1f}" y2="{y0:.1f}" class="axis"/>')
    if ref is not None:
        p.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{Y(ref):.1f}" y2="{Y(ref):.1f}" class="marker"/>')
        p.append(f'<text x="{W - PAD_R}" y="{Y(ref) - 4:.1f}" class="tick" text-anchor="end">{html.escape(ref_text)}</text>')
    p.append("</svg>")
    return f'<figure><figcaption>{html.escape(label)}</figcaption><div class="plot">{"".join(p)}</div></figure>'


def histogram(values: np.ndarray, marker: float, label: str, marker_text: str, W: int = W, H: int = H) -> str:
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if len(v) < 10:
        return ""
    lo, hi = min(v.min(), marker), max(v.max(), marker)
    span = (hi - lo) or 1.0
    lo -= span * 0.05
    hi += span * 0.05
    counts, edges = np.histogram(v, bins=40, range=(lo, hi))
    top = counts.max() * 1.15

    def X(x):
        return PAD_L + (x - lo) / (hi - lo) * (W - PAD_L - PAD_R)

    def Y(c):
        return PAD_T + (top - c) / top * (H - PAD_T - PAD_B)
    p = [f'<svg viewBox="0 0 {W} {H}" class="chart" role="img" aria-label="{html.escape(label)}">']
    for k, c in enumerate(counts):
        x0, x1 = X(edges[k]) + 1, X(edges[k + 1]) - 1
        if c > 0:
            p.append(f'<rect x="{x0:.1f}" y="{Y(c):.1f}" width="{max(0.5, x1 - x0):.1f}" height="{Y(0) - Y(c):.1f}" '
                     f'class="hbar" rx="1"><title>{edges[k]:+.3f} to {edges[k + 1]:+.3f}: {c}</title></rect>')
    for tv in _ticks(lo, hi, 6):
        p.append(f'<text x="{X(tv):.1f}" y="{H - 8}" class="tick" text-anchor="middle">{_fmt_tick(tv)}</text>')
    p.append(f'<line x1="{PAD_L}" x2="{W - PAD_R}" y1="{Y(0):.1f}" y2="{Y(0):.1f}" class="axis"/>')
    mx = X(marker)
    p.append(f'<line x1="{mx:.1f}" x2="{mx:.1f}" y1="{PAD_T}" y2="{Y(0):.1f}" class="marker strong"/>')
    anchor = "end" if mx > W * 0.7 else "start"
    p.append(f'<text x="{mx + (-6 if anchor == "end" else 6):.1f}" y="{PAD_T + 12}" class="val" '
             f'text-anchor="{anchor}">{html.escape(marker_text)}</text>')
    p.append("</svg>")
    return f'<figure><figcaption>{html.escape(label)}</figcaption><div class="plot">{"".join(p)}</div></figure>'


def dot_ci(cats: Sequence[str], mean: Sequence[float], lo: Sequence[float], hi: Sequence[float], label: str,
           unit: str, W: int = W, H: int = H, ref: Optional[float] = None, ref_text: str = "") -> str:
    n = len(cats)
    if n == 0:
        return ""
    allv = np.r_[np.asarray(lo, float), np.asarray(hi, float), np.asarray(mean, float), 0.0,
                 ref if ref is not None and np.isfinite(ref) else 0.0]
    allv = allv[np.isfinite(allv)]
    a, b = allv.min(), allv.max()
    span = (b - a) or 1.0
    a -= span * 0.08
    b += span * 0.08
    rowh = 26
    h = PAD_T + PAD_B + rowh * n
    left = 120

    def X(v):
        return left + (v - a) / (b - a) * (W - left - PAD_R)
    p = [f'<svg viewBox="0 0 {W} {h}" class="chart" role="img" aria-label="{html.escape(label)}">']
    for tv in _ticks(a, b):
        p.append(f'<line x1="{X(tv):.1f}" x2="{X(tv):.1f}" y1="{PAD_T}" y2="{h - PAD_B}" class="grid"/>')
        p.append(f'<text x="{X(tv):.1f}" y="{h - 8}" class="tick" text-anchor="middle">{_fmt_tick(tv)}</text>')
    p.append(f'<line x1="{X(0):.1f}" x2="{X(0):.1f}" y1="{PAD_T}" y2="{h - PAD_B}" class="axis"/>')
    if ref is not None and np.isfinite(ref):
        p.append(f'<line x1="{X(ref):.1f}" x2="{X(ref):.1f}" y1="{PAD_T}" y2="{h - PAD_B}" class="marker strong"/>')
        p.append(f'<text x="{X(ref) + 4:.1f}" y="{PAD_T + 8}" class="val">{html.escape(ref_text)}</text>')
    for k, (c, m, l, u) in enumerate(zip(cats, mean, lo, hi)):
        y = PAD_T + rowh * (k + 0.5)
        p.append(f'<text x="{left - 8}" y="{y + 4:.1f}" class="tick" text-anchor="end">{html.escape(str(c))}</text>')
        if np.isfinite(l) and np.isfinite(u):
            p.append(f'<line x1="{X(l):.1f}" x2="{X(u):.1f}" y1="{y:.1f}" y2="{y:.1f}" class="ci"/>')
        p.append(f'<circle cx="{X(m):.1f}" cy="{y:.1f}" r="5" class="dot"><title>{html.escape(str(c))}: '
                 f'{m:+.3f}{unit} [{l:+.3f}, {u:+.3f}]</title></circle>')
    p.append("</svg>")
    return f'<figure><figcaption>{html.escape(label)}</figcaption><div class="plot">{"".join(p)}</div></figure>'


# -------------------------------------------------------------------- HTML

CSS = """
:root{color-scheme:light;--page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--s1:#2a78d6;--s2:#eb6834;--pos:#2a78d6;--neg:#e34948;--ring:rgba(11,11,11,.10);
--good:#0ca30c;--warning:#fab219;--serious:#ec835a;--critical:#d03b3b;--neutral:#898781;--goodtext:#006300}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;
--ink:#fff;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s2:#d95926;--pos:#3987e5;
--neg:#e66767;--ring:rgba(255,255,255,.10);--goodtext:#0ca30c}}
:root[data-theme="dark"]{color-scheme:dark;--page:#0d0d0d;--surface:#1a1a19;--ink:#fff;--ink2:#c3c2b7;--grid:#2c2c2a;
--axis:#383835;--s1:#3987e5;--s2:#d95926;--pos:#3987e5;--neg:#e66767;--ring:rgba(255,255,255,.10);--goodtext:#0ca30c}
*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);
font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1000px;margin:0 auto;padding:28px 16px 60px}
h1{font-size:24px;margin:0 0 4px}h2{font-size:17px;margin:34px 0 10px}.sub{color:var(--ink2);margin:0 0 18px}
.card{background:var(--surface);border:1px solid var(--ring);border-radius:12px;padding:18px 20px;margin:12px 0}
.verdict{display:flex;gap:16px;align-items:flex-start}.badge{font-weight:700;font-size:20px;white-space:nowrap;
padding:6px 12px;border-radius:8px;border:2px solid currentColor}
.tone-good{color:var(--goodtext)}.tone-warning{color:#a76b00}.tone-serious{color:#b4532c}.tone-critical{color:var(--critical)}
.tone-neutral{color:var(--ink2)}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]) .tone-warning{color:var(--warning)}
:root:not([data-theme="light"]) .tone-serious{color:var(--serious)}}
.headline{font-size:16px;margin:2px 0 8px}.reasons{margin:0;padding-left:18px;color:var(--ink2)}
.stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.stat{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:10px 12px}
.stat .l{font-size:12px;color:var(--ink2)}.stat .v{font-size:20px;font-weight:600}.stat .c{font-size:12px;color:var(--muted)}
table{border-collapse:collapse;width:100%;font-size:13px;font-variant-numeric:tabular-nums}
th,td{padding:5px 8px;border-bottom:1px solid var(--grid);text-align:right;vertical-align:top}
th:first-child,td:first-child{text-align:left}th{color:var(--ink2);font-weight:600}
.scroll{overflow-x:auto}.st{font-weight:600;white-space:nowrap}
.st-PASS{color:var(--goodtext)}.st-WARN{color:#a76b00}.st-FAIL{color:var(--critical)}.st-INFO,.st-N\\/A{color:var(--muted)}
td.l,th.l{text-align:left}
figure{margin:14px 0;background:var(--surface);border:1px solid var(--ring);border-radius:12px;padding:12px 12px 6px}
figcaption{font-size:13px;color:var(--ink2);margin-bottom:4px}.plot{position:relative}
svg.chart{width:100%;height:auto;display:block}
.grid{stroke:var(--grid);stroke-width:1}.axis{stroke:var(--axis);stroke-width:1}
.tick{fill:var(--muted);font-size:11px}.val{fill:var(--ink2);font-size:11px}
.line{fill:none;stroke-width:2;stroke-linejoin:round;stroke-linecap:round}.line.s1{stroke:var(--s1)}.line.s2{stroke:var(--s2)}
.bar.pos{fill:var(--pos)}.bar.neg{fill:var(--neg)}.hbar{fill:var(--s1);opacity:.85}
.marker{stroke:var(--ink2);stroke-width:1;stroke-dasharray:3 3}.marker.strong{stroke:var(--neg);stroke-width:2;stroke-dasharray:none}
.ci{stroke:var(--ink2);stroke-width:2}.dot{fill:var(--s1);stroke:var(--surface);stroke-width:2}
.hit{fill:transparent}.legend{display:flex;gap:14px;font-size:12px;color:var(--ink2);margin:0 0 4px}
.key{display:inline-flex;align-items:center;gap:6px}.sw{display:inline-block;width:14px;height:3px;border-radius:2px}
.sw.s1{background:var(--s1)}.sw.s2{background:var(--s2)}
.tip{position:absolute;pointer-events:none;display:none;background:var(--surface);border:1px solid var(--ring);
border-radius:8px;padding:6px 8px;font-size:12px;box-shadow:0 2px 8px rgba(0,0,0,.12);white-space:nowrap}
.note{font-size:13px;color:var(--ink2)}details{margin:8px 0}summary{cursor:pointer;color:var(--ink2)}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:760px){.two{grid-template-columns:1fr}}
"""

JS = """
document.querySelectorAll('rect.hit').forEach(function(r){
  var d=JSON.parse(r.getAttribute('data-line')), svg=r.ownerSVGElement, tip=svg.parentNode.querySelector('.tip');
  var x0=+r.getAttribute('data-x0'), x1=+r.getAttribute('data-x1'), n=d.x.length;
  var vline=document.createElementNS('http://www.w3.org/2000/svg','line');
  vline.setAttribute('class','axis');vline.style.display='none';svg.appendChild(vline);
  r.addEventListener('mousemove',function(e){
    var pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;var p=pt.matrixTransform(svg.getScreenCTM().inverse());
    var i=Math.max(0,Math.min(n-1,Math.round((p.x-x0)/(x1-x0)*(n-1))));
    var xs=x0+(x1-x0)*i/(n-1);vline.setAttribute('x1',xs);vline.setAttribute('x2',xs);
    vline.setAttribute('y1',r.getAttribute('y'));vline.setAttribute('y2',+r.getAttribute('y')+(+r.getAttribute('height')));
    vline.style.display='';var h='<b>'+d.x[i]+'</b>';
    for(var k in d.s){var v=d.s[k][i];h+='<br>'+k+': '+(v===null?'–':v.toFixed(2));}
    tip.innerHTML=h;tip.style.display='block';var b=svg.getBoundingClientRect();
    var left=(e.clientX-b.left)+12;if(left>b.width-160)left-=180;tip.style.left=left+'px';tip.style.top='8px';});
  r.addEventListener('mouseleave',function(){tip.style.display='none';vline.style.display='none';});
});
"""


def _table(df: Optional[pd.DataFrame], fmt: str = "{:.3f}", index: bool = True) -> str:
    if df is None or len(df) == 0:
        return '<p class="note">–</p>'
    d = df.copy()
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in ([d.index.name or ""] if index else []) + list(d.columns))
    rows = []
    for idx, r in d.iterrows():
        cells = [f"<td>{html.escape(str(idx))}</td>"] if index else []
        for v in r.values:
            if isinstance(v, (bool, np.bool_)):
                cells.append(f"<td>{v}</td>")
            elif isinstance(v, (int, np.integer)):
                cells.append(f"<td>{v:,}</td>")
            elif isinstance(v, (float, np.floating)):
                txt = "–" if not np.isfinite(v) else (f"{int(v):,}" if float(v).is_integer() and abs(v) >= 1
                                                      else fmt.format(v))
                cells.append(f"<td>{txt}</td>")
            else:
                cells.append(f"<td>{html.escape(str(v))}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>'


def _stat(label, value, sub=""):
    return f'<div class="stat"><div class="l">{html.escape(label)}</div><div class="v">{html.escape(value)}</div>' \
           f'<div class="c">{html.escape(sub)}</div></div>'


def write_html(path: Path, title: str, subtitle: str, settings: dict, a, run_, null: Optional[pd.DataFrame],
               prop: Optional[pd.DataFrame], neighbours: Optional[pd.DataFrame], cross: Optional[pd.DataFrame],
               vault_start: Optional[pd.Timestamp]) -> Path:
    c = a.core
    unit = c["unit"]
    tone = VERDICT_TONE.get(a.verdict, "neutral")
    parts = [f"<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport "
             f"content='width=device-width,initial-scale=1'><title>{html.escape(title)}</title><style>{CSS}</style>"
             f"</head><body><main>"]
    parts.append(f"<h1>{html.escape(title)}</h1><p class=sub>{html.escape(subtitle)}</p>")
    reasons = "".join(f"<li>{html.escape(r)}</li>" for r in a.reasons)
    parts.append(f'<div class="card verdict"><div class="badge tone-{tone}">{html.escape(a.verdict)}</div>'
                 f'<div><p class="headline">{html.escape(a.headline)}</p><ul class="reasons">{reasons}</ul></div></div>')
    t = c.get("trade", {})
    e = c.get("equity", {})
    tm = c.get("timing")
    stats = [
        _stat("Sharpe (annual)", _f(c.get("sharpe"), 2), f"95% {_f(c['sharpe_ci'][0], 2)} to {_f(c['sharpe_ci'][1], 2)}"),
        _stat("Deflated Sharpe", f"{c.get('dsr', 0):.1%}", f"{c.get('trials', 1)} variant(s) tried"),
        _stat(f"Mean per trade ({unit})", _f(c.get("mean_r"), 3, True),
              f"95% {_f(c['mean_r_ci'][0], 3, True)} to {_f(c['mean_r_ci'][1], 3, True)}"),
    ]
    if tm:
        stats.append(_stat("Edge vs random entries", _f(tm["edge"], 3, True), f"p = {tm['p']:.3f}"))
    if t:
        stats += [_stat("Trades", f"{t['trades']:,}", f"{t['trades_per_month']:.1f} a month"),
                  _stat("Win rate", f"{t['win_rate']:.1%}", f"payoff {_f(t['payoff'], 2)}"),
                  _stat("Profit factor", _f(t["profit_factor"], 2), f"gross {_f(t['gross_r'], 3, True)}{unit}/trade")]
    if e:
        stats += [_stat(f"Max drawdown ({unit})", _f(e["max_dd"], 1), f"longest {e['longest_dd_days']} days"),
                  _stat("Worst month", _f(e["worst_month"], 1, True), f"{e['positive_months']:.0%} months up")]
    parts.append(f'<div class="stats">{"".join(stats)}</div>')

    # scorecard
    if a.checks:
        rows = "".join(f'<tr><td class=l>{html.escape(ch.name)}</td><td class="l st st-{ch.status}">'
                       f'{ICON.get(ch.status, "?")} {ch.status}</td><td class=l>{html.escape(ch.value)}</td>'
                       f'<td class=l>{html.escape(ch.detail)}</td></tr>' for ch in a.checks)
        parts.append("<h2>Robustness scorecard</h2><div class=card><div class=scroll><table><thead><tr>"
                     "<th class=l>check</th><th class=l>result</th><th class=l>value</th><th class=l>detail</th>"
                     f"</tr></thead><tbody>{rows}</tbody></table></div><p class=note>One WARN never sinks a "
                     "strategy; the verdict allows WARNs and at most one FAIL. INFO lines are context only.</p></div>")

    # charts
    d = a.series.get("daily")
    if d is not None and len(d):
        series = {"strategy": d.cumsum().to_numpy()}
        if null is not None and len(null) and run_.strat.mode == "event" and len(run_.trades):
            nm = null.groupby("of")["r_net"].mean()
            tr = run_.trades.assign(nullr=nm.reindex(run_.trades.index).fillna(0.0).to_numpy())
            ex = pd.DatetimeIndex(tr["exit_time"]).normalize()
            cumn = pd.Series(tr["nullr"].to_numpy(), index=ex).groupby(level=0).sum().reindex(d.index).fillna(0).cumsum()
            series["random entries, same exits"] = cumn.to_numpy()
        parts.append("<h2>Equity</h2>")
        parts.append(line_chart(d.index, series, f"Cumulative P&L ({unit}, 1{unit} per trade)", vault_start,
                                "vault →" if vault_start is not None else ""))
    two = []
    by_y = a.tables.get("by_year")
    if by_y is not None and len(by_y):
        two.append(bar_chart([str(i) for i in by_y.index], by_y["total_r"].to_numpy(), f"P&L by year ({unit})", unit,
                             W=440, H=250))
    if tm and tm.get("null_means") is not None:
        two.append(histogram(tm["null_means"], tm["real"], "Strategy vs 4,000 sets of random entries (mean per trade)",
                             f"strategy {tm['real']:+.3f}", W=440, H=250))
    cc = run_.info.get("cost_curve")
    if cc is not None:
        two.append(bar_chart([f"{m:g}x" for m in cc.index], cc.to_numpy(), f"Mean per trade at higher costs ({unit})",
                             unit, W=440, H=250))
    bi = a.tables.get("by_instrument")
    if bi is not None and len(bi) > 1:
        two.append(dot_ci(list(bi.index), bi["mean_r"].to_numpy(), (bi["mean_r"] - 1.96 * bi["se"]).to_numpy(),
                          (bi["mean_r"] + 1.96 * bi["se"]).to_numpy(), f"Mean per trade by instrument, 95% ({unit})", unit,
                          W=440))
    if neighbours is not None and len(neighbours):
        nb = neighbours["sharpe"].to_numpy()
        two.append(dot_ci([f"{r.param} = {r.value}" for r in neighbours.itertuples()], nb, nb, nb,
                          "Parameter neighbours - Sharpe (red line = this config)", "", W=440,
                          ref=c.get("sharpe"), ref_text="this"))
    if two:
        parts.append('<div class="two">' + "".join(two) + "</div>")

    # prop
    if prop is not None and len(prop):
        parts.append("<h2>FTMO 2-Step challenge</h2><div class=card>")
        pdisp = prop.copy()
        for col in ("pass both", "zero-edge twin", "fail phase 1", "yrs with $0", "funded breach"):
            pdisp[col] = [f"{v:.0%}" for v in pdisp[col]]
        pdisp["edge adds"] = [f"{v:+.0%}" for v in prop["edge adds"]]
        for col in ("funded yr income", "twin income"):
            pdisp[col] = [f"${v:,.0f}" for v in pdisp[col]]
        pdisp["days to pass"] = ["–" if not np.isfinite(v) else f"{v:.0f}" for v in prop["days to pass"]]
        parts.append(_table(pdisp.set_index("risk").rename_axis("risk / trade")))
        parts.append("<p class=note>Zero-edge twin = the same days with the average profit removed. Prop rules alone "
                     "pass some coin flips; the edge is the difference. Income is per $100k funded, after the split, "
                     "monthly payouts, balance reset to initial.</p></div>")

    # tables
    parts.append("<h2>Details</h2>")
    if t:
        tdf = pd.DataFrame({k: [v] for k, v in t.items() if not isinstance(v, dict)}).T.rename(columns={0: "value"})
        edf = pd.DataFrame({k: [v] for k, v in e.items()}).T.rename(columns={0: "value"})
        parts.append('<div class="two"><div class=card><b>Trades</b>' + _table(tdf) + "</div><div class=card><b>Equity "
                     f"({unit})</b>" + _table(edf) + "</div></div>")
    for key, label in (("by_year", "By year"), ("by_instrument", "By instrument"), ("monthly", f"Monthly P&L ({unit})"),
                       ("by_exit", "By exit type"), ("by_direction", "By direction"), ("by_weekday", "By weekday of entry"),
                       ("by_hour_utc", "By hour of entry (UTC)"), ("walk_forward", "Walk-forward picks")):
        if key in a.tables and len(a.tables[key]):
            parts.append(f"<details {'open' if key in ('by_year', 'by_instrument') else ''}><summary>{label}</summary>"
                         f"<div class=card>{_table(a.tables[key], '{:.2f}' if key == 'monthly' else '{:.3f}')}</div></details>")
    reg = run_.info.get("regimes")
    if reg is not None:
        parts.append(f"<details><summary>By market regime at entry</summary><div class=card>{_table(reg)}</div></details>")
    if neighbours is not None and len(neighbours):
        parts.append(f"<details><summary>Parameter neighbours</summary><div class=card>"
                     f"{_table(neighbours.set_index('param'))}</div></details>")
    if cross is not None and len(cross):
        parts.append(f"<details><summary>Other data sources</summary><div class=card>"
                     f"{_table(cross.set_index('source'))}</div></details>")
    sett = pd.DataFrame({"setting": list(settings.keys()), "value": [str(v) for v in settings.values()]}).set_index("setting")
    parts.append(f"<details><summary>Run settings and data used</summary><div class=card>{_table(sett)}"
                 f"{_table(pd.DataFrame(run_.info.get('data', {})).T)}</div></details>")
    if run_.info.get("assumed"):
        items = "".join(f"<li>{html.escape(x)}</li>" for x in run_.info["assumed"])
        parts.append(f"<details><summary>Cost assumptions ({len(run_.info['assumed'])})</summary><div class=card>"
                     f"<ul>{items}</ul></div></details>")
    parts.append("<p class=note>How the verdict works: lab/README.md. Thresholds are fixed in catalog.RULES.</p>")
    parts.append(f"<script>{JS}</script></main></body></html>")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(parts), encoding="utf-8")
    return path
