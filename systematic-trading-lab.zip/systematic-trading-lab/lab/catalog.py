"""
catalog.py - every fixed number the lab uses, in one place.

  INSTRUMENTS  what each market is called on each data source
  VENUES       what trading it costs (spread, commission, swap, slippage)
  PROP_RULES   prop-firm challenge rules for the challenge simulator
  RULES        the verdict thresholds - PRE-REGISTERED. Change them only before
               looking at a result, never after, or the verdict means nothing.

Edit freely, but keep RULES fixed once you start testing a strategy family.
"""
from __future__ import annotations

# --------------------------------------------------------------- instruments
# cls: metal / energy / agri / index / fx / crypto / stock - used for default costs,
# swap, and the "one position per correlated group" cap (group).
# For each source the first symbol that exists in the cache is used; the rest are
# alternates (e.g. Yahoo futures GC=F goes back decades, the GLD ETF is cleaner).
INSTRUMENTS = {
    # metals
    "gold":     dict(cls="metal", group="gold", mt5=["XAUUSD"], yahoo=["GC=F", "GLD"], alpaca=["GLD"]),
    "silver":   dict(cls="metal", group="silver", mt5=["XAGUSD"], yahoo=["SI=F", "SLV"], alpaca=["SLV"]),
    "platinum": dict(cls="metal", group="platinum", mt5=["XPTUSD"], yahoo=["PL=F", "PPLT"], alpaca=["PPLT"]),
    # energy
    "wti":      dict(cls="energy", group="oil", mt5=["USOIL.cash"], yahoo=["CL=F", "USO"], alpaca=["USO"]),
    "brent":    dict(cls="energy", group="oil", mt5=["UKOIL.cash"], yahoo=["BZ=F", "BNO"], alpaca=["BNO"]),
    "natgas":   dict(cls="energy", group="natgas", mt5=["NATGAS.cash"], yahoo=["NG=F", "UNG"], alpaca=["UNG"]),
    # agriculture
    "corn":     dict(cls="agri", group="grains", mt5=["CORN.c"], yahoo=["ZC=F", "CORN"], alpaca=["CORN"]),
    "wheat":    dict(cls="agri", group="grains", mt5=["WHEAT.c"], yahoo=["ZW=F", "WEAT"], alpaca=["WEAT"]),
    "soybean":  dict(cls="agri", group="grains", mt5=["SOYBEAN.c"], yahoo=["ZS=F", "SOYB"], alpaca=["SOYB"]),
    # indices
    "us500":    dict(cls="index", group="us_equity", mt5=["US500.cash"], yahoo=["^GSPC", "ES=F", "SPY"], alpaca=["SPY"]),
    "us100":    dict(cls="index", group="us_equity", mt5=["US100.cash"], yahoo=["^NDX", "NQ=F", "QQQ"], alpaca=["QQQ"]),
    "us30":     dict(cls="index", group="us_equity", mt5=["US30.cash"], yahoo=["^DJI", "YM=F", "DIA"], alpaca=["DIA"]),
    "us2000":   dict(cls="index", group="us_equity", mt5=["US2000.cash"], yahoo=["^RUT", "RTY=F", "IWM"], alpaca=["IWM"]),
    "ger40":    dict(cls="index", group="eu_equity", mt5=["GER40.cash"], yahoo=["^GDAXI"], alpaca=[]),
    "uk100":    dict(cls="index", group="eu_equity", mt5=["UK100.cash"], yahoo=["^FTSE"], alpaca=[]),
    "eu50":     dict(cls="index", group="eu_equity", mt5=["EU50.cash"], yahoo=["^STOXX50E"], alpaca=[]),
    "jp225":    dict(cls="index", group="asia_equity", mt5=["JP225.cash"], yahoo=["^N225"], alpaca=[]),
    "hk50":     dict(cls="index", group="asia_equity", mt5=["HK50.cash"], yahoo=["^HSI"], alpaca=[]),
    # fx
    "eurusd":   dict(cls="fx", group="usd", mt5=["EURUSD"], yahoo=["EURUSD=X"], alpaca=[]),
    "gbpusd":   dict(cls="fx", group="usd", mt5=["GBPUSD"], yahoo=["GBPUSD=X"], alpaca=[]),
    "usdjpy":   dict(cls="fx", group="jpy", mt5=["USDJPY"], yahoo=["JPY=X"], alpaca=[]),
    "audusd":   dict(cls="fx", group="usd", mt5=["AUDUSD"], yahoo=["AUDUSD=X"], alpaca=[]),
    "usdcad":   dict(cls="fx", group="usd", mt5=["USDCAD"], yahoo=["CAD=X"], alpaca=[]),
    "usdchf":   dict(cls="fx", group="usd", mt5=["USDCHF"], yahoo=["CHF=X"], alpaca=[]),
    "nzdusd":   dict(cls="fx", group="usd", mt5=["NZDUSD"], yahoo=["NZDUSD=X"], alpaca=[]),
    "eurjpy":   dict(cls="fx", group="jpy", mt5=["EURJPY"], yahoo=["EURJPY=X"], alpaca=[]),
    "gbpjpy":   dict(cls="fx", group="jpy", mt5=["GBPJPY"], yahoo=["GBPJPY=X"], alpaca=[]),
    # crypto
    "btc":      dict(cls="crypto", group="crypto", mt5=["BTCUSD"], yahoo=["BTC-USD"], alpaca=["BTC/USD"]),
    "eth":      dict(cls="crypto", group="crypto", mt5=["ETHUSD"], yahoo=["ETH-USD"], alpaca=["ETH/USD"]),
    # stocks (FTMO offers stock CFDs under the plain ticker)
    "aapl":     dict(cls="stock", group="aapl", mt5=["AAPL"], yahoo=["AAPL"], alpaca=["AAPL"]),
    "msft":     dict(cls="stock", group="msft", mt5=["MSFT"], yahoo=["MSFT"], alpaca=["MSFT"]),
    "nvda":     dict(cls="stock", group="nvda", mt5=["NVDA"], yahoo=["NVDA"], alpaca=["NVDA"]),
    "amzn":     dict(cls="stock", group="amzn", mt5=["AMZN"], yahoo=["AMZN"], alpaca=["AMZN"]),
    "googl":    dict(cls="stock", group="googl", mt5=["GOOG", "GOOGL"], yahoo=["GOOGL"], alpaca=["GOOGL"]),
    "meta":     dict(cls="stock", group="meta", mt5=["META"], yahoo=["META"], alpaca=["META"]),
    "tsla":     dict(cls="stock", group="tsla", mt5=["TSLA"], yahoo=["TSLA"], alpaca=["TSLA"]),
}

SOURCES = ("mt5", "alpaca", "yahoo")


def instrument_of(source: str, symbol: str):
    """Reverse lookup: which catalog instrument a source symbol belongs to."""
    for name, d in INSTRUMENTS.items():
        if symbol in d.get(source, []):
            return name
    return None


_FX = {"USD", "EUR", "GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "SEK", "NOK", "DKK", "PLN", "HUF", "CZK", "TRY",
       "ZAR", "MXN", "SGD", "HKD", "CNH", "ILS", "THB", "RUB"}


def classify_mt5(path: str, name: str) -> str:
    """Asset class of an MT5 symbol from its folder path and name."""
    p, n = (path or "").lower(), name.upper()
    base = n.split(".")[0]
    if base[:3] in ("XAU", "XAG", "XPT", "XPD") or "metal" in p:
        return "metal"
    if "crypto" in p or base.endswith(("BTC", "ETH")) or base[:3] in ("BTC", "ETH", "LTC", "XRP", "SOL", "ADA",
                                                                       "DOG", "BNB", "DOT", "AVA", "LNK", "XMR"):
        return "crypto"
    if any(k in p for k in ("energ", "oil")) or base in ("USOIL", "UKOIL", "NATGAS", "HEATOIL", "GASOIL"):
        return "energy"
    if any(k in p for k in ("agri", "soft", "grain")) or base in ("CORN", "WHEAT", "SOYBEAN", "COFFEE", "COCOA",
                                                                    "SUGAR", "COTTON", "OJ"):
        return "agri"
    if any(k in p for k in ("indic", "index", "indices")) or n.endswith(".CASH") or base in ("US500", "US100", "US30",
                                                                                          "GER40", "UK100", "JP225"):
        return "index"
    if any(k in p for k in ("forex", "fx", "currenc")) or (len(base) == 6 and base[:3] in _FX and base[3:] in _FX):
        return "fx"
    if any(k in p for k in ("stock", "share", "equit", "cfd")):
        return "stock"
    return "other"


def _universe() -> dict:
    import json
    from pathlib import Path
    f = Path(__file__).resolve().parent / "data" / "mt5" / "universe.json"
    try:
        return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except ValueError:
        return {}


def cls_of(name: str) -> str:
    if name in INSTRUMENTS:
        return INSTRUMENTS[name].get("cls", "other")
    if ":" in name:
        src, sym = name.split(":", 1)
        if src == "mt5":
            u = _universe().get(sym)
            return u["cls"] if u else classify_mt5("", sym)
        return classify_mt5("", sym)
    return "other"


def group_of(name: str) -> str:
    if name in INSTRUMENTS:
        return INSTRUMENTS[name].get("group", name)
    sym = name.split(":", 1)[-1].split(".")[0].upper()
    if sym in ("USOIL", "UKOIL"):
        return "oil"
    return sym


# --------------------------------------------------------------------- venues
# Costs a strategy is charged. Units:
#   spread_bp          round-trip bid/ask spread in basis points. Used only when the
#                      data has no spread of its own (MT5 bars carry the real spread
#                      per bar and that is used instead).
#   commission_bp      per side, basis points of notional
#   swap_long/short    % of notional per night (negative = you pay). Real MT5 values
#                      are read by `fetch --source mt5` into data/mt5/specs.json and
#                      replace these defaults for that symbol.
#   triple_day         weekday the triple swap is charged (0=Mon ... 4=Fri)
#   stop_slip_bp       extra slippage on stop fills on top of bid/ask (gaps are
#                      already modelled exactly; this is for ordinary stops)
# Defaults marked ASSUMED are reasonable guesses; the report lists every assumed
# number it used so nothing hides.
_ftmo_swap = {   # %/night. ASSUMED unless MT5 specs exist. Gold long measured live 1 Oct 2026.
    "metal":  (-0.0188, -0.0040),
    "energy": (-0.0070, -0.0070),
    "agri":   (-0.0070, -0.0070),
    "index":  (-0.0180, -0.0040),
    "fx":     (-0.0030, -0.0030),
    "crypto": (-0.0550, -0.0550),
    "stock":  (-0.0180, -0.0060),
    "other":  (-0.0100, -0.0100),
}
VENUES = {
    "ftmo": dict(
        note="FTMO CFDs (MT5). Spread from MT5 bars when available.",
        by_class={
            "metal":  dict(spread_bp=2.0, commission_bp=0.07, triple_day=2),
            "energy": dict(spread_bp=7.5, commission_bp=0.0, triple_day=4),
            "agri":   dict(spread_bp=17.0, commission_bp=0.0, triple_day=4),
            "index":  dict(spread_bp=1.0, commission_bp=0.0, triple_day=4),
            "fx":     dict(spread_bp=0.8, commission_bp=0.25, triple_day=2),
            "crypto": dict(spread_bp=4.0, commission_bp=3.25, triple_day=4),
            "stock":  dict(spread_bp=3.0, commission_bp=0.20, triple_day=4),
            "other":  dict(spread_bp=5.0, commission_bp=0.0, triple_day=2),
        },
        swap=_ftmo_swap,
        stop_slip_bp=0.0,
        tp_gap_fill="open",      # MT5 market execution: a gap through the target fills at the open
        rollover_ny="17:00",     # FTMO server midnight = 17:00 New York
    ),
    "alpaca": dict(
        note="Alpaca cash account: no commission, no swap, ETF/stock spreads.",
        by_class={c: dict(spread_bp=2.0, commission_bp=0.0, triple_day=4) for c in _ftmo_swap},
        swap={c: (0.0, -0.0010) for c in _ftmo_swap},   # shorting: ASSUMED borrow ~0.36%/yr
        stop_slip_bp=1.0,
        tp_gap_fill="open",
        rollover_ny="16:00",
    ),
    "raw": dict(
        note="ZERO COSTS - diagnostic only. Never decide on this venue.",
        by_class={c: dict(spread_bp=0.0, commission_bp=0.0, triple_day=2) for c in _ftmo_swap},
        swap={c: (0.0, 0.0) for c in _ftmo_swap},
        stop_slip_bp=0.0,
        tp_gap_fill="open",
        rollover_ny="17:00",
    ),
}
# Instrument-specific overrides (measured). Merged over the class defaults.
VENUE_OVERRIDES = {
    "ftmo": {
        # round-trip spread measured on FTMO 24 Sep 2026 (median session spread)
        "gold": dict(spread_bp=0.9), "silver": dict(spread_bp=6.5), "wti": dict(spread_bp=8.1),
        "brent": dict(spread_bp=7.0), "btc": dict(spread_bp=0.1), "eth": dict(spread_bp=2.4),
        "soybean": dict(spread_bp=15.6), "wheat": dict(spread_bp=18.0), "corn": dict(spread_bp=18.0),
        "platinum": dict(spread_bp=31.0), "natgas": dict(spread_bp=209.0),
    },
}

# ----------------------------------------------------------------- prop rules
PROP_RULES = {
    "ftmo_2step": dict(
        phases=[dict(name="Challenge", target=0.10), dict(name="Verification", target=0.05)],
        daily_loss=0.05,          # of initial balance, from the balance at midnight Prague
        max_loss=0.10,            # static, of initial balance
        min_trading_days=4,
        max_days=None,            # FTMO has no time limit; the sim caps a phase at 2 years
        split=0.80,
        day_tz="Europe/Prague",
    ),
    "ftmo_1step": dict(
        phases=[dict(name="Challenge", target=0.10)],
        daily_loss=0.03, max_loss=0.10, trailing=True,
        min_trading_days=4, max_days=None, split=0.90, day_tz="Europe/Prague",
    ),
}

# ------------------------------------------------- prop programs (lifecycle)
# Every program that allows a FULLY automated bot on the evaluation AND the funded account, as
# researched 6 Oct 2026 from the firms' own help pages ([OFF]) or, where those wouldn't load,
# third-party reviews ([3P]) - confirm [3P] prices at checkout. All amounts are fractions of the
# account size except fees (USD; EUR at 1.10). Fields:
#   fee / monthly / activation   evaluation price, subscription per 21 trading days while evaluating,
#                                one-off at funding; refund: fee back with the first payout
#   phases                       profit targets; min_days / min_profit_days (day >= profit_day_min)
#   daily / daily_base / daily_soft   daily loss limit; measured from 'balance' (midnight balance) or
#                                'max' (higher of balance and equity at the reset); soft = the day is
#                                closed at the limit but the account survives
#   max_loss / dd                'static', 'eod' (trails the highest end-of-day balance), 'eod_reset'
#                                (FTMO 1-Step: trails, and restarts after a payout); lock: the trailing
#                                floor stops at initial + lock
#   best_day                     consistency: best day <= x of the profit (eval: of the target)
#   payout                       ('every', n trading days, first after) or ('windays', n days >= win_min)
#   share / cap / min_pay        part of the profit that can be withdrawn, cap per payout, minimum
#   split                        trader's share;  max_alloc: total account size one person may run
#   cls                          'cfd' (MT5) or 'futures' (CME via NinjaTrader/Tradovate/TradingView)
#   scaling                      FTMO [OFF, 15 Sep 2026]: every 4 months (84 trading days) with >= 10% net profit
#                                and >= 2 payouts, the account grows 25% and the split becomes 90%, up to $2M
#                                across all FTMO accounts. Other firms' plans aren't modelled (steps unverified).
PROGRAMS = {
    "FTMO 2-Step 100K": dict(scaling=dict(every=84, min_profit=0.10, min_payouts=2, step=0.25, split=0.90, cap_total=2_000_000), swing_ok=True, cls="cfd", size=100_000, fee=594, refund=True, phases=[0.10, 0.05], min_days=4,
                             daily=0.05, daily_base="balance", max_loss=0.10, dd="static", split=0.80,
                             payout=("every", 10, 10), share=1.0, min_pay=20, max_alloc=400_000,
                             src="[OFF] rules; fee EUR540 [3P]", note="Standard: flat before weekends, +-2 min "
                             "news blackout on funded; Swing type: neither (1:30 leverage)"),
    "FTMO 1-Step 100K": dict(scaling=dict(every=84, min_profit=0.10, min_payouts=2, step=0.25, split=0.90, cap_total=2_000_000), swing_ok=False, cls="cfd", size=100_000, fee=549, refund=False, phases=[0.10], min_days=0,
                             daily=0.03, daily_base="balance", max_loss=0.10, dd="eod_reset", best_day=0.50,
                             split=0.90, payout=("every", 10, 10), share=1.0, min_pay=20, max_alloc=400_000,
                             src="[OFF]", note="best day <= 50% of profit, evaluation and funded"),
    "The5ers High Stakes 100K": dict(swing_ok=True, cls="cfd", size=100_000, fee=491, refund=True, phases=[0.10, 0.05],
                                     min_profit_days=3, profit_day_min=0.005, daily=0.05, daily_base="max",
                                     max_loss=0.10, dd="static", split=0.80, payout=("every", 10, 10), share=1.0,
                                     min_pay=150, max_alloc=300_000, src="[OFF] rules; fee [3P]",
                                     note="own source code only; +-2 min news blackout on funded"),
    "E8 One 100K": dict(swing_ok=True, cls="cfd", size=100_000, fee=342, refund=False, phases=[0.06], min_days=0, daily=0.03,
                        daily_base="balance", max_loss=0.04, dd="eod", lock=0.0, best_day=0.40, split=0.80,
                        payout=("every", 5, 3), share=1.0, min_pay=1_500, max_alloc=500_000,
                        src="[OFF] (default 4% drawdown option, sale fee)",
                        note="one strategy per user; <=50% of trades under 1 min; +-5 min news on funded"),
    "FundingPips 2-Step 100K": dict(swing_ok=False, cls="cfd", size=100_000, fee=529, refund=False, phases=[0.08, 0.05],
                                    min_days=3, daily=0.05, daily_base="max", max_loss=0.10, dd="static",
                                    split=0.80, payout=("every", 10, 10), share=1.0, min_pay=1_000,
                                    max_alloc=400_000, src="[OFF]",
                                    note="own EA with source proof; funded flat nightly (fine for intraday); "
                                         "+-5 min news on funded"),
    "Blue Guardian 2-Step 100K": dict(swing_ok=True, cls="cfd", size=100_000, fee=520, refund=False, phases=[0.08, 0.04],
                                      min_profit_days=3, profit_day_min=0.005, daily=0.04, daily_base="max",
                                      max_loss=0.08, dd="static", split=0.85, payout=("every", 10, 10), share=1.0,
                                      min_pay=100, max_alloc=400_000, src="[OFF] rules; fee estimated [3P]",
                                      note="2-min minimum hold; funded trades auto-closed at 2% floating loss"),
    # ---- futures (CME), bots allowed on funded accounts; flat by ~4:45 pm ET every day
    "Tradeify Select Flex 50K": dict(swing_ok=False, cls="futures", size=50_000, fee=111, refund=False, phases=[0.06],
                                     min_days=3, best_day=0.40, daily=None, max_loss=0.04, dd="eod", lock=0.002,
                                     split=0.90, payout=("windays", 5, 0.003), share=1.0, cap=2_500, min_pay=250,
                                     max_alloc=250_000, src="[OFF] (sale fee)",
                                     note="sole owner of the bot; >=50% of profit from trades held >10 s"),
    "Lucid Flex 50K": dict(swing_ok=False, cls="futures", size=50_000, fee=146, refund=False, phases=[0.06], min_days=0,
                           best_day=0.50, daily=None, max_loss=0.04, dd="eod", lock=0.002, split=0.90,
                           payout=("windays", 5, 0.003), share=0.50, cap=2_000, min_pay=500, max_alloc=250_000,
                           src="[OFF] payouts; fee [3P]", note="no HFT"),
    "MFFU Rapid 50K": dict(swing_ok=False, cls="futures", size=50_000, fee=157, refund=False, phases=[0.06], min_days=2,
                           best_day=0.50, daily=None, max_loss=0.04, dd="eod", lock=0.002, split=0.90,
                           payout=("every", 1, 1), share=1.0, buffer=0.042, min_pay=500, max_alloc=250_000,
                           src="[OFF]", note="funded drawdown trails intraday (modelled end-of-day: optimistic); "
                                             "no tier-1 news on funded; SI/NG banned"),
    "FTMO Futures Pro 50K": dict(swing_ok=False, cls="futures", size=50_000, fee=0, monthly=139, refund=False, phases=[0.06],
                                 min_days=0, best_day=0.50, daily=0.02, daily_base="balance", max_loss=0.06,
                                 dd="eod", lock=0.0, split=0.90, payout=("windays", 5, 0.004), share=1.0,
                                 cap=5_000, min_pay=20, max_alloc=150_000, src="[OFF]",
                                 note="flat by 4:10 pm ET; up to 3 funded accounts"),
    "Topstep XFA 50K": dict(swing_ok=False, cls="futures", size=50_000, fee=0, monthly=49, activation=149, refund=False,
                            phases=[0.06], min_days=0, best_day=0.55, daily=None, max_loss=0.04, dd="eod",
                            lock=0.0, split=0.90, payout=("windays", 5, 0.003), share=0.50, cap=5_000,
                            min_pay=20, max_alloc=250_000, src="[OFF]",
                            note="bots only on Express Funded (not Live); orders must come from your own "
                                 "computer - VPS/VPN banned"),
}

# CME futures that trade the same market as an FTMO CFD (what a futures prop firm account would trade).
FUTURES_TWIN = {
    "US500": "ES / MES", "US100": "NQ / MNQ", "US30": "YM / MYM", "US2000": "RTY / M2K", "USOIL": "CL / MCL",
    "NATGAS": "NG / QG", "XAUUSD": "GC / MGC", "XAGUSD": "SI / SIL", "XPTUSD": "PL", "XCUUSD": "HG / MHG",
    "COPPER": "HG / MHG", "EURUSD": "6E / M6E", "GBPUSD": "6B / M6B", "AUDUSD": "6A / M6A", "NZDUSD": "6N",
    "USDJPY": "6J (inverse)", "USDCAD": "6C (inverse)", "USDCHF": "6S (inverse)", "BTCUSD": "MBT", "ETHUSD": "MET",
    "CORN": "ZC", "WHEAT": "ZW", "SOYBEAN": "ZS", "JP225": "NKD / MNK",
}


def futures_twin(symbol: str):
    return FUTURES_TWIN.get(symbol.split(":")[-1].split(".")[0].upper())


# ----------------------------------------------------- verdict rules (FIXED)
# Pre-registered. The verdict is a weight of evidence, not a single test:
# one soft check going WARN never kills a strategy.
RULES = dict(
    alpha=0.05,              # significance after deflating for every variant tried (DSR >= 0.95)
    timing_alpha=0.05,       # must beat matched random entries at this level to be called timing edge
    sharpe_min=0.30,         # annual Sharpe below which an edge is not worth trading.
                             #   NO EDGE needs the WHOLE 95% interval below this - "didn't reach
                             #   significance" alone is never a fail, it is INCONCLUSIVE.
    min_trades=100,          # below this: INSUFFICIENT DATA (shows how many more are needed)
    good_trades=300,
    min_days=250,            # trading days of history
    max_soft_fails=1,        # robustness FAILs tolerated for "EDGE - probable"
    max_warns_conclusive=2,  # WARNs tolerated for "EDGE - conclusive"
    null_draws=20,           # random entries simulated per real trade
    bootstrap=4000,          # bootstrap resamples
    block_days=5,            # mean block length (trading days) for the stationary bootstrap
    vault_months=12,         # the newest 12 months of EVERY dataset are held back until --final
                             # (one date for the whole lab, fixed on first run in data/vault.json)
    power=0.80,              # for "how much more data you need"
)
